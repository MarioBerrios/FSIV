# Calibración de la cámara con OpenCV.
