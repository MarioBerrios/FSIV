# Color balance

Equilibrado del color.
