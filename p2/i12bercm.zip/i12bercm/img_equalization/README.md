# Ecualización de la imagen digital.

La descripción de la práctica la puedes consultar (aquí.)[https://docs.google.com/document/d/1EV0HS83b1_2rRRJpFPN8xua6pLg2NhhRFjzqQVi8ICA/edit?usp=sharing]
