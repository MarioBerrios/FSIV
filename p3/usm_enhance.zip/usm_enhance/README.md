# Realce usando máscara de desenfoque (Unsharp Mask).
