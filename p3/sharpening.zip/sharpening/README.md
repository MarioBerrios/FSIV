# Enhance an image using a sharpening filter.
