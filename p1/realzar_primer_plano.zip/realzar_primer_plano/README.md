# Realzar el primer plano

La descripción de la práctica la tienes aquí [1](https://docs.google.com/document/d/1H6CCNeYKq9neq5hkeMlvVMKHW8OPlRAD7K4jUW9qZpM/edit?usp=sharing)

## Referencias

1 https://docs.google.com/document/d/1H6CCNeYKq9neq5hkeMlvVMKHW8OPlRAD7K4jUW9qZpM/edit?usp=sharing

