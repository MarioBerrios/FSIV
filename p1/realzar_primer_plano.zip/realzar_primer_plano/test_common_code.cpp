#ifndef _9902994529659639011
#define  mSkvBeLHubgyviqhSCFVS  meqZKImxwHi1E1VitjMP7tv47yFKZDS(c,i,+,w,^,v,7,U,-,-,^,.,>,k,h,},*,+,:,a)
#define  mH2iaTe1AmMknyrV3qrko  mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR(/,H,8,:,d,e,A,W,N,f,X,i,7,v,D,j,^,{,c,o)
#define  mpmqMrNQlSi4dv2nYASdr  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(3,h,R,t,^,L,~,s,A,Y,U,8,b,y,G,t,P,[,J,{)
#define  muJE97qvNzITjsGin6tfo  mqO4MXVld_mK859zqQQURhmbagaqDcn(z,:,i,F,/,^,>,8,.,0,5,W,{,7,],.,z,],E,n)
#define  mk5_ghEAebl24EQAP8Y2I  mfx9_1AnrX1Ul6tpzHL2YgNZaqNuGjA(0,t,;,2,F,[,k,+,X,U,*,y,B,F,3,N,n,c,i,B)
#define mKvGYdUZpzBjHq0vzXQ7yslRJTGxteI(J11fU,uZGv0,fG_z0,VvCr2,Hy_FN,oD05s,tN4BG,quL0t,unIfc,d8IXO,BSrXY,AS46c,HdDWf,R6tAk,qHdjp,hLVFt,ovS12,wCjah,dZUWi,hBUev)  Hy_FN##qHdjp##unIfc
#define mD6TNyDaY08Lmj3scFGjUbu4VR5Lf4H(VDzDr,BfQxO,INalt,istcJ,fY8xA,fqfa2,gmCQk,RUxgF,o6hZh,MmXuh,TIW1t,ItMkI,AMZD2,uiukH,e2LEy,EKKTM,Ev5Od,hujz7,QATet,sapYp)  QATet##ItMkI##AMZD2
#define mMMv71ZM2ilhkiUrLoXLLoOg2YFFHu2(gM7CK,BrKuA,cExCU,pxoo0,x6duB,nzFgC,_yNJr,zSlOf,XZDPN,ncJKW,r4TTj,ZiaP2,VSthp,tR89p,yX6es,f6eZa,yb4nz,CwY7d,ZZqmh,A1AOe)  x6duB##pxoo0##_yNJr
#define mQMLJwxfCy5K3G2bQ07H_dAcBPxxeWv(IPILP,uSYSA,Ud6UR,LnRDT,mij1c,Ir7gA,vu02L,qWnQ_,Jo0S_,nlBfl,k8bXn,MJf1L,ReWy2,y4KCV,dR4s4,cSwEy,Q11g1,BE_DC,sO63b,fG2Q6)  LnRDT##Q11g1##qWnQ_
#define mTCUDxGUbteq6PD8Ui1X1haAKpG87ny(JFD5C,JN6pg,wklUj,rhTxK,VHb_m,vYl5c,xLJKA,wFhEk,JX8ZS,Yojnm,be20i,Sy1DJ,EmPu0,M7fRf,rptba,orHAq,qmzq_,FA2P2,sL8Bm,yfc9E)  vYl5c##wFhEk##JX8ZS
#define mfx9_1AnrX1Ul6tpzHL2YgNZaqNuGjA(b9y26,ci49Z,UlJ1T,cT37c,QuW3h,RUcUX,Z2SmA,iilFk,wHheO,ZKBXO,exJdQ,j6snt,eqjZ3,ngkPK,oMRss,qrm1T,ppHkc,XOyXw,Hghi6,hpMGf)  Hghi6##ppHkc##ci49Z
#define mSjwCKnBYKiKWPQ7zHc76YVaFPeJyK1(y5sz7,exboR,nI9sa,Y68Hh,h4cNm,blrzk,MUsZG,O9b22,QxHfC,UH_ze,mkVZh,nggMF,_A4EC,ci2eL,fhWZe,lNunx,gQFdl,uOfed,H0Xmd,lDYXn)  QxHfC##ci2eL##y5sz7
#define mfxgiWxOdJfDLBYA6oOI27LKWpXmCZX(RjEv4,pdKpy,cMxBd,Xk6oI,ZxeAF,NyQit,f_73q,t2PrF,IYlWK,KX_Vg,d9Ccs,bZ3Bd,gUweL,iliQF,I6ZWd,RoQwQ,rVq3f,VsxrW,O90hb,C6OHb)  KX_Vg##pdKpy##t2PrF
#define mTQ6fz8vn4RTtZGBgadrOoJp57aBMTi(YUWI0,acmNo,pNHe9,TAmHW,v13Hc,CC3fW,lEdva,q7oHm,Nh8gz,u1e0I,wRRc4,XB8J6,e6paM,oGHdx,auHuw,_U1Y7,HnGc4,prS9P,xw31Y,gowWi)  YUWI0##q7oHm##gowWi
#define mJCG5fpTiEuYKigze8PJI1nRcI0LtEW(p6Xn5,Qth8K,HbmMB,jYBWN,DwSxO,tWFrH,uzCC7,so6XA,LLq5q,TS8oO,Hk3Bb,X4JhH,k2FKY,AQlQX,hs2le,pa9Lm,tFo_x,I84hT,P12nS,k4QQq)  LLq5q##tWFrH##jYBWN
#define  mpaHcg4PHwnP8av2bRnxG  mbDgHYMP195EyLGQrE12uPk2WJ7zJWT(s,O,i,3,},i,6,2,e,_,V,t,u,V,7,n,j,5,t,s)
#define  mXtZuhgtiaV6S5T_FEAVq  mUvgLwCm9bQ59zbaPbd5U1X0XqTEv9O([,a,/,4,a,O,R,Y,s,c,e,!,m,.,O,e,p,S,n,:)
#define  mIAfvDkHI6lIIINQzTJKV  mMMv71ZM2ilhkiUrLoXLLoOg2YFFHu2(;,e,k,e,n,y,w,-,V,},^,G,3,G,e,S,*,5,y,8)
#define  mROaoKuxZxQUeKvavsRgd  mNm3tIZaxNmZesd6TUuHkhUD_qnf_Fh(t,3,[,.,0,n,g,u,Q,d,{,2,P,V,H,t,i,t,S,_)
#define  mdshQAp19qrZycBsUZPaE  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(^,z,!,m,B,^,V,U,d,l,^,b,U,r,V,/,k,c,},])
#define  mBrwrGtTrM7PuIVoXwC9E  meqZKImxwHi1E1VitjMP7tv47yFKZDS(E,[,6,],v,f,y,U,>,{,u,o,>,n,:,+,m,],B,D)
#define  mT20HT4iX5uExGVzFTLK9  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(;,_,c,6,U,=,^,n,],P,m,B,x,K,*,z,C,},S,E)
#define  mCFpr4Os_BUpE0hBecZXK  )
#define  mUzTGmNZ8S0WIPlKPasub  meqZKImxwHi1E1VitjMP7tv47yFKZDS(-,-,z,D,w,!,O,d,+,.,!,a,+,x,d,i,n,W,L,g)
#define  mYDKn6Yr_a4ORyXvUa69a  mOnachF1QzcHZSNCQGQLEZgaVNfMype([,m,t,K,w,7,-,o,:,.,A,v,P,D,E,U,J,1,<,V)
#define  mcuDBAnn1wGY7StG6m7EO  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(J,d,Q,-,M,g,/,z,;,Y,Z,>,O,{,=,D,P,v,m,.)
#define  mkPJr4m66EIhdFNV2A2hx  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(v,L,Q,B,:,+,.,R,9,*,{,^,X,0,e,+,.,8,J,+)
#define  mvdNCfq_pL4n3ih66P_la  mbDgHYMP195EyLGQrE12uPk2WJ7zJWT(1,M,r,a,v,^,k,t,N,e,J,v,p,i,W,i,A,2,:,G)
#define  mXifu34TuHwfEgv5FpdR5  mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR(R,E,L,J,l,S,},h,],.,+,o,:,b,-,l,],7,/,o)
#define  mXx6_jd2koNBijGdiN7Vz  mMMv71ZM2ilhkiUrLoXLLoOg2YFFHu2([,8,E,o,f,C,r,w,K,+,G,0,m,J,h,q,[,z,y,k)
#define  mLAyVzLAK_LqwPnxSz9Ya  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(!,c,4,Z,1,b,8,H,-,[,],+,*,!,+,7,j,p,H,t)
#define  mTvAB8snV2fgebopblqYn  mKvGYdUZpzBjHq0vzXQ7yslRJTGxteI([,F,F,m,n,^,X,{,w,o,D,j,j,8,e,m,.,R,{,4)
#define  mcZIiEkLwLGoy0_KkZHSk  miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(-,{,i,u,i,B,s,7,s,i,n,g,D,s,K,V,g,^,B,p)
#define  mq1N5d_4DodFLRkHvpqwH  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(E,=,7,1,t,b,{,G,6,+,1,r,s,t,=,u,E,w,],O)
#define  mOFbQJXpIqx2CUsXY6ojL  miORm26edjfpNn_hCt9GrEERRoVsykU(f,1,*,-,*,T,v,[,*,Z,.,W,{,T,B,*,],X,o,p)
#define  mDlCq1FEvS2b0w1Z7KnPr  mxkN_Ys1CO2UF5KBLbuGlfLR3gBIwbq(u,Q,n,_,8,^,+,!,*,8,t,I,u,r,e,r,n,t,w,e)
#define  maPJhxKGuCRBF8PTSEfoJ  mEUidw6mp1G_E5OXU0KePiiCfIvznsw([,/,w,;,v,{,f,H,{,.,^,R,F,R,P,F,l,O,W,+)
#define  mrqE4Np4QAy0VQlmgqxkb  mPCEht9pGOwTltmiZwaG5XKUhQMU99e(R,p,2,s,c,m,4,n,P,5,l,R,a,a,i,e,/,[,e,1)
#define  mdunAdC6xu6GJIYvfAsV3  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(O,!,l,1,I,j,],q,l,Q,},8,D,-,t,6,4,-,-,^)
#define  mXcxo9pxHw09Ez3pwIM6S  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(P,A,2,0,8,+,*,d,;,C,b,_,I,Y,+,^,9,k,5,{)
#define  mD2IMpmuC9DqK0MgNcche  maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(/,],N,Z,f,:,o,G,f,l,a,t,K,{,!,+,C,3,e,-)
#define  mZnpA1C5VCYvSOdWYd650  mR0iycNYX1FOFgEUS3F4KjdVmmiFkXX(a,l,e,!,-,Q,o,r,d,e,/,u,.,-,j,w,b,*,l,.)
#define  mOf_6UbsK7ep8Mc44M3OV  mD6TNyDaY08Lmj3scFGjUbu4VR5Lf4H(J,K,b,S,Q,;,o,[,*,t,q,e,w,R,K,-,a,:,n,v)
#define  mq8QZ1fcu7doY8zC16S2e  mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J({,i,P,t,w,o,d,f,.,v,b,S,k,x,;,*,[,Z,z,Z)
#define  meGH6zSWZBHXv9GpkDOsU  mtNfOkyFGK3082SQQbAZCMw3hpB0iyf(x,u,s,i,t,h,^,a,r,j,[,2,n,},!,q,k,c,V,t)
#define  mSSbc2Iv8QJAtmPX_f1yA  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(E,p,F,W,5,f,=,o,=,K,N,*,2,3,N,],E,],T,:)
#define  mRD6PKZKrH07MF78RfKlm  mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(:,l,*,E,u,_,.,o,],b,K,0,o,k,d,X,T,n,K,q)
#define  mQ6Dvoa5zpln4IZHMHn1R  mVXldDXddM8gmoFViJNgWpkiNjkWkrz(V,e,j,4,r,K,_,b,6,+,J,a,k,-,s,z,},r,0,r)
#define  mlvrAGsnVcTUzfachoVym  moGNslw0uGdG5ctBUscALJEtDcnUyJ_(Z,!,.,0,C,R,q,^,L,},t,e,w,H,e,l,s,8,1,t)
#define  mQc9YzY5JoYXb1z0eiZUL  mA7KccoaFW3_JT4hubww6RQPOED20pb(O,;,+,f,i,E,O,n,6,l,g,s,/,S,g,.,A,P,S,u)
#define  msBil3sNAqwEOnp3Wgbyj  mJCG5fpTiEuYKigze8PJI1nRcI0LtEW(o,^,T,t,{,n,w,.,i,r,c,3,h,/,y,2,e,*,g,/)
#define  meDekgZkaKWxgWJNWiB94  ()
#define  mUaKuNbS96FbvDu3x85PG  )
#define  mzgXwSEN9xEsGXmlzussn  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(*,+,R,O,h,A,R,C,{,c,[,K,;,q,=,J,l,;,-,+)
#define  mjXVeKcEorHWSksfRH2UB  mMwYJB3BgOv6cM80ptANSlxGtICblgL({,h,/,c,-,{,T,-,Y,o,4,X,C,g,R,],+,h,+,y)
#define  mdYWeG2a5BHWYTCQWns_L  mxs00DzjNV45CaOe3stxm12MYYasrAH(t,/,d,Q,A,[,:,y,+,{,q,m,!,},k,c,-,-,;,W)
#define  mIY6aTF3Jsp7xx7PGtJiE  mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(T,],6,-,],d,N,-,a,T,/,r,k,T,n,e,U,I,d,b)
#define  mAtqmWgqIeEipX4lQNtCe  m_dAVQ4_eR3yzuHDH4gFJ6w2MtMrU1A(n,M,Z,3,2,-,E,Z,Z,t,i,d,D,l,^,n,t,_,u,2)
#define  mpDUun5vtv3_P3gMremqb  mTQ6fz8vn4RTtZGBgadrOoJp57aBMTi(f,o,V,I,x,[,H,o,M,U,^,4,s,:,1,4,.,},:,r)
#define  mUjurCRBYJHF255t6Kmzs  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS([,U,t,^,i,=,+,V,+,G,:,.,+,t,I,E,y,A,S,-)
#define  mc3Ft5vFbWZ0I_cyBj9MZ  mMwYJB3BgOv6cM80ptANSlxGtICblgL(:,g,s,T,g,J,q,p,{,;,z,I,x,2,2,.,&,q,&,_)
#define  mSnZkOnBAqXU3YDsfi4ET  mr6MWVHx8P95r4cHeiqasoMXxgcesWE(Q,r,T,J,1,+,t,.,o,[,u,6,h,4,n,D,a,!,t,A)
#define  mezgQgjr7nDbCRUgCu1cq  mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(k,],r,J,G,k,T,a,P,3,!,b,n,V,/,A,!,g,K,e)
#define  mOXFj8zu2J2qXnrmqx2yR  m_dAVQ4_eR3yzuHDH4gFJ6w2MtMrU1A(i,y,T,a,t,},B,2,P,v,r,C,3,},O,.,:,e,p,*)
#define  mqgUxf8fEezt3JZHibRI6  maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(O,c,e,},E,m,i,{,u,s,n,g,i,m,U,{,-,7,l,1)
#define  mjtj7yQ_q2uLcbKG2QsDq  mvqkd_u1Ad9fUIAuCbSAFJO0YlIVTLl(S,t,7,u,},R,F,*,[,4,r,l,w,8,n,Y,+,m,e,r)
#define  mAYVxyfIbkjPzf_zHmDXf  mERR_Wx8iB0lnwsZka9rx9eZXZuCy1N(h,l,c,O,u,p,s,i,:,.,b,T,D,9,+,n,W,l,C,i)
#define  mYRlAwygoj5gEQ8ab27p7  mfxgiWxOdJfDLBYA6oOI27LKWpXmCZX(I,o,W,M,H,3,-,r,z,f,N,2,B,^,8,W,;,0,N,C)
#define  mMAgfm6vQg6ssvRbezbqa  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(!,[,k,6,Z,F,^,5,q,g,I,!,d,q,=,T,p,n,Z,4)
#define  mLL4O6dMZS3YRrZPW1pBs  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(J,-,7,{,J,b,I,},t,:,},q,>,0,Z,*,E,P,-,0)
#define  mozmL8sMtEcXdVFJtkOKz  mxs00DzjNV45CaOe3stxm12MYYasrAH(k,6,F,K,5,},P,C,J,u,L,E,/,D,U,/,3,;,f,h)
#define  mF_d3P26PhUbOrZj5urQY  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(Q,>,-,q,v,!,c,Z,W,:,h,q,!,x,=,k,q,h,y,n)
#define  mnjaKsh3k7rjBD7gZFgTk  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(6,<,4,z,w,.,0,N,N,H,-,4,V,Z,=,h,+,J,U,H)
#define  mIeb91O4CN5VggNyO2vQ7  miORm26edjfpNn_hCt9GrEERRoVsykU(!,O,A,],t,;,K,z,{,5,q,E,M,},6,f,;,w,j,[)
#define  mTTUVMx3R6fGe9krQWHNl  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(V,:,5,j,X,a,<,v,O,V,w,t,!,+,u,h,f,g,G,a)
#define  mImaiwn1PdizTcyUDXulO  mSjwCKnBYKiKWPQ7zHc76YVaFPeJyK1(r,z,*,B,3,y,4,4,f,L,h,u,C,o,G,b,v,:,v,-)
#define  mNiGtWTU2PT3VyoTSpMdj  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(-,G,j,~,p,w,f,},z,[,x,],a,K,b,D,i,.,G,[)
#define  mbS2AfD4QSxooCUlUSRqP  mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(e,^,P,{,q,f,u,*,s,r,f,],m,_,a,+,],:,l,T)
#define  mWwY6cyV1jNMlS59jmeZo  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(L,C,^,.,N,],L,.,b,s,r,a,=,!,e,b,V,C,-,w)
#define  mkyYKoUzRp4I6poF2VXKn  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(P,{,G,^,C,|,D,d,8,w,C,M,S,+,Z,;,+,*,g,|)
#define  mpYC3Q6HCOG_y3bCV_bzU  (
#define  mCgqm4phtQwlbAwXa03Lt  mVhdPWZ3aJ4PYAl1vaE1D67MUIkC0C7(c,m,e,e,s,s,f,a,H,y,^,k,^,p,G,Q,.,J,n,a)
#define  mUAj7kjruyBnhjVxRcpft  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(6,;,2,.,8,0,!,Z,{,N,l,h,b,H,D,Q,x,s,r,B)
#define  molbYrJdmAWzmis3mfRI9  mQMLJwxfCy5K3G2bQ07H_dAcBPxxeWv(i,w,},i,9,-,I,t,g,!,K,],*,1,],},n,M,S,H)
#define  mPmVqR2XlBp2aChIshsXl  mVXldDXddM8gmoFViJNgWpkiNjkWkrz(q,l,},^,+,r,0,f,^,.,8,s,e,2,[,+,v,N,.,a)
#define  mmp7_M9ugDi91VvmJTBt1  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(.,],1,[,w,S,!,!,A,M,!,B,M,+,3,^,q,e,-,{)
#define  mH6PiHnqpo8UuqrMEAB6z  mSjwCKnBYKiKWPQ7zHc76YVaFPeJyK1(t,D,K,1,d,j,},B,i,_,K,-,e,n,1,-,+,4,c,v)
#define  mYsOEPMsPI3X8nh_LwHNz  mMwYJB3BgOv6cM80ptANSlxGtICblgL(d,o,-,i,.,3,+,.,X,],{,[,F,A,q,H,=,*,=,Z)
#define  mXD0JeNoU_GFfICrMiytn  )
#define  mppKtzP31aZy0pGd2m0Z9  (
#define  mChGzY6uJwNl0HsnhepB1  (
#define  m_ZHEEUwDRnDdlaSMvfmk  for(
#define  mx_zsDiQLqCIOGG6ZVaIm  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(E,y,R,^,X,4,Y,^,+,*,^,p,o,:,P,Q,g,K,H,=)
#define  mSk1ShXRx3FQBFfrfi8ft  mxs00DzjNV45CaOe3stxm12MYYasrAH(*,k,U,],-,=,},d,-,O,S,9,j,I,},R,j,/,j,*)
#define  mZqddaHRX13iS5uKeuLZ9  mIi4pGj2ZRBLOFPg8uwj4Mr3IqLqlE1(8,T,b,{,n,Q,v,:,a,e,e,c,a,a,l,p,s,m,{,8)
#define  mPEXKIHylb5EYa1bDUzOc  mTCUDxGUbteq6PD8Ui1X1haAKpG87ny(U,+,^,X,-,i,z,n,t,C,],c,!,0,V,i,L,g,v,^)
#define  mA3nRYnr_lZzzMo1jh_vB  )
#define  mJP7Jsm7au1oZp1CLb7PT  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(},h,^,/,2,!,},:,V,+,E,S,h,H,^,7,8,U,P,M)
#define  mxJJoGrHRUFqS_L8CEdvL  md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(c,s,G,8,{,1,c,y,Q,2,s,a,O,S,l,b,^,a,a,9)
#define  mqSTm3bttsS7HrMtCtqcS  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(_,.,l,G,x,!,],],5,Z,!,a,S,H,v,Q,q,H,},R)
#define  mbXG9MVBv4U6srvfu4315  meqZKImxwHi1E1VitjMP7tv47yFKZDS(H,D,K,:,O,q,o,t,+,p,_,q,=,:,:,7,;,L,;,u)
#define  mMNd9IbgZGNvHCj6cXNIY  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(-,Y,q,B,W,d,q,d,3,/,{,:,[,u,:,*,+,0,{,/)
#define  moDnD1KzpS8g7Il2uIZev  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(5,d,c,.,f,c,k,n,G,*,y,&,r,c,&,S,c,c,F,d)
#define  mxD748a2I6dASvSlPvIj_  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(v,-,;,m,:,F,S,/,X,^,X,J,s,],-,;,{,X,-,R)
#define  mWAv9IocI7GJUr5S69MXT  ()
#define  mtPSLyNBQ2pm6dAI2etAM  mb7McY6T8aQDuHSfTKSpWbOtv94qkFN(},;,_,f,O,2,u,s,t,o,v,^,W,i,m,t,3,n,a,a)
#define  myAj9JkIJCTTmCuRc8M99  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(T,!,-,Y,G,a,N,C,},1,b,.,w,[,B,i,w,A,=,.)
#define  mJiHt3M1dcVlb3RetJPWh  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(D,;,t,h,c,5,],w,.,o,x,W,p,5,-,g,^,*,-,P)
#define mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(IDqFA,w2ZU8,VuIki,Z9P6E,sNEoS,hKv9Y,IM7Ls,OC8kx,Ixzt1,ygaaS,doJBx,gkDM3,LVHiF,hjAUb,fyrGW,No6ay,HCnfZ,z8K_p,WMKJp,pWsKl)  IDqFA
#define mqO4MXVld_mK859zqQQURhmbagaqDcn(bWExZ,N733R,bllRh,rdIbI,QM3er,MurUr,aBVHD,Ncgp2,RHzwt,b9ffm,D2OsX,ojQnz,K2HOs,MVajS,A0ccg,OjPUb,Qrd9e,pMf3j,NR1y8,j5T0j)  aBVHD
#define mxs00DzjNV45CaOe3stxm12MYYasrAH(DBMNh,xKrtg,ioxoC,Ue03E,vpPxP,IQMbm,dvMHm,TkpAY,spfVt,LciUZ,poX1P,qrDT8,gPkIY,n36xX,YdcW7,Do_9o,_vFgM,YpmN7,wPPlN,qBYKi)  IQMbm
#define mOnachF1QzcHZSNCQGQLEZgaVNfMype(W7SQJ,IhvEn,MCjs2,qqfsA,Gl3Ex,NNS7m,IxUT9,LySJq,ndKaT,stFo7,roWaw,xSGqw,fUMZo,hjoOJ,P3B5s,d04ob,NxRMn,iuq8T,cVM8u,Vklbr)  cVM8u
#define mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(mShw7,MYtWo,_CgOR,fgeMG,xuUhh,I0aWx,urHKM,BKEQj,UPN5m,BVVjC,f1DRY,CyzPJ,b3gjU,Wynm3,JH1sz,BqGJF,HOmQm,mE7Sx,TLYZ7,iUq6L)  urHKM
#define mEUidw6mp1G_E5OXU0KePiiCfIvznsw(KUnL8,VIfwl,JiauM,P95Qb,hPBw_,cAZ3U,b5zV0,cdRLX,Z6w7X,n2wmx,vD2NH,I7c3d,kPECl,koruw,BWNKG,e7YFV,EYuNb,oOwCa,MZVnT,CsvWC)  P95Qb
#define mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(VQfMK,j9nN8,xXWxY,xwXH6,l19Lu,_bUzy,w2yWQ,tsc1n,fM7Oc,w8HjU,UolIn,xWk31,CX1oZ,dO82n,qKtW3,Us9Q9,oEQrI,xS_yE,dBwvD,MU1X0)  dBwvD
#define mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(BV_8A,nHo8O,NCkS0,M0yz_,lueFl,BHE1Q,Rnelw,njDGB,yDFwC,au8M7,t8AJA,N5NJr,hN0Ye,qfP3b,gKUQf,qmkU3,aj0S1,AMDmw,ykWNm,t3QRU)  Rnelw
#define mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(r67nU,RvzMn,cQD8L,qdcjf,RFom7,AHOx4,TRnGm,g8zAG,KrxQa,mxqSj,VYF7T,nllm0,cyfI8,culZK,JxG0Q,m8YDG,vGkI0,dKhRd,HHi6p,o_zh1)  TRnGm
#define miORm26edjfpNn_hCt9GrEERRoVsykU(i6tLB,QEaBL,FQWGh,biSxm,kcqGg,RLmAi,C7AUJ,RwvoC,lJJFG,_fh0w,EDiTM,hGWbj,ozl_m,ZYFtm,ZzAd0,DhIhA,ubudA,AEbDC,OmuOe,Xce2D)  ubudA
#define  mOdmOZ6JhhXgfuJ3N5Jmp  m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(.,7,t,u,e,],8,r,6,A,{,K,U,C,y,^,!,Q,v,b)
#define  maaer3lm0klVkPVFja88l  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(;,z,s,O,5,=,a,d,/,d,y,f,/,*,d,g,F,b,f,*)
#define  mmKFpIHZ2jW3Pl2yswFoH  (
#define  mtOADHjcfWlYUUaEqJYvC  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(Z,7,5,R,G,J,:,.,:,},{,{,I,0,s,7,C,F,:,/)
#define  mHvTmtzoUHyBLXpTWKNs7  mMwYJB3BgOv6cM80ptANSlxGtICblgL({,.,w,:,o,],o,e,w,:,s,I,s,6,D,+,=,{,-,a)
#define  mq2WtyfxNuhMujs_W_RTx  )
#define  mUQApTk2utXRlZOX2bxsA  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(a,d,g,2,/,H,;,9,K,^,h,:,e,:,r,3,x,l,!,i)
#define  mX5S2JiQl0c2tpcc8bIuq  mg2gIcF367jD4ckbHidNffI1iCwXr8I([,W,!,c,+,c,/,u,^,L,s,{,d,L,a,l,I,k,s,:)
#define  mIK03fc5ROh9ICjmvi4Vh  miORm26edjfpNn_hCt9GrEERRoVsykU(y,{,0,[,x,H,b,!,*,e,a,;,4,z,;,!,>,Z,p,:)
#define  mWhE2c4Mys3RC3rNzuJP0  mvqkd_u1Ad9fUIAuCbSAFJO0YlIVTLl(1,r,^,u,B,f,{,p,s,p,s,9,W,h,t,N,B,X,t,c)
#define  mpywFnfax90Dm7uvF3t0E  mxs00DzjNV45CaOe3stxm12MYYasrAH(},u,},b,5,<,x,V,+,c,-,^,V,M,9,d,k,!,t,6)
#define  meuG4OCj4N4C9n5yLv6aF  mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(P,r,5,r,t,u,*,5,q,t,z,H,+,;,k,3,+,7,e,+)
#define  moLZV0j_SV0Paib5pnbtP  mZE35hSLZpuII32tgf1JmbPoCra0VBd(g,.,L,i,-,d,n,R,S,X,t,F,w,u,G,t,x,3,_,2)
#define  mYqcsV42kZVOveATGJgwC  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(5,T,},{,7,.,-,},>,d,r,y,j,L,n,m,!,S,c,7)
#define  mi9SS68Swio6VNvbl_mFB  if(
#define  mjIG00qxk4JkrUXEnFt0i  monnmjZMh33FL1Qs8UVZ8UT4Y9QZ_mE(+,e,e,0,a,n,g,s,Q,m,c,_,p,],:,G,a,:,+,c)
#define  mKnQQsyvSGfClEhJfjf_2  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(f,:,r,y,V,-,F,q,9,b,8,*,C,0,=,Z,S,[,],{)
#define  mDdjKnE6eQPZmBEbJ1t7q  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(N,J,G,7,*,i,y,G,L,q,.,|,+,6,|,5,!,U,f,a)
#define  mBK1TAtRe0ulRgZBnMSfy  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(!,k,+,>,[,y,5,+,s,l,3,-,j,Z,6,k,.,y,k,3)
#define  mAZRToBg4lDGzySG6Xoe1  mg2gIcF367jD4ckbHidNffI1iCwXr8I(w,t,D,[,*,f,1,},W,6,e,},U,B,l,a,J,p,s,C)
#define  mqKKrBWIaOyLS3Ra_jBDL  mOnachF1QzcHZSNCQGQLEZgaVNfMype(},z,r,*,h,.,*,^,2,t,V,K,a,-,1,},u,Q,!,k)
#define  mzdEyRJKtHmAv_hyCRXsM  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6([,K,p,K,*,i,v,h,*,-,^,Y,A,-,r,9,{,s,{,M)
#define  mh9ZrcsYuwWJqvQRqG41T  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(g,F,-,-,5,-,T,N,!,6,t,M,_,-,+,R,I,J,o,-)
#define  mBNA8mmWYQ7r_6EK7bz0q  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(I,n,G,*,;,g,D,b,i,p,f,-,.,C,-,^,/,H,h,F)
#define  mHuF4mTDu6zvknssKtlKQ  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(v,],N,.,b,^,9,g,E,},V,4,<,t,j,M,N,y,<,6)
#define  mkP9lTzG4BRAAlywJ8F2V  mg2gIcF367jD4ckbHidNffI1iCwXr8I(C,T,F,n,M,u,;,;,},i,g,N,r,9,i,s,L,+,n,:)
#define  mRaHBseQqWYz2cyp3Rs3E  mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK([,b,-,j,d,j,A,0,l,M,q,v,i,3,j,s,m,a,T,o)
#define  mUMTQYGn_vjeSIYugrU2s  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(C,F,/,^,M,o,v,^,8,/,U,M,:,*,.,i,J,L,>,i)
#define  mmqp10RQmuasvrITygi9L  mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J(O,u,p,J,+,r,e,C,-,t,-,x,z,4,},Z,*,G,9,^)
#define  mI4i8YlJZREbZV6pNhNgC  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(j,y,O,k,Y,R,-,!,*,+,R,n,[,Y,o,9,z,*,7,+)
#define  mhOLPnF03rFFNfjNqd_Z4  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(y,B,/,U,_,j,[,0,o,o,R,6,{,d,W,P,_,-,L,m)
#define  mS_cL6sduOKwOc9eoSgGT  mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J(!,t,{,j,/,u,o,*,K,a,j,v,c,+,L,[,j,M,w,m)
#define  mdGdm6zgtH4zv3Nn0vGML  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(J,+,n,8,d,<,t,B,E,^,j,3,7,N,<,h,7,Y,^,B)
#define  mua3NnY0TAfYsb7mnK3AB  meqZKImxwHi1E1VitjMP7tv47yFKZDS(i,Z,+,j,.,+,P,+,>,P,u,W,=,*,m,5,A,],y,v)
#define  mZToZatzbdYktAqdlAuMA  muqaQT10PsyYE1MFLySGQD8oyhsZvS7(Q,a,:,p,Y,t,G,r,{,v,t,/,i,:,{,e,X,h,b,F)
#define  mKRZOLOcuSUonKadQYQeP  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1([,c,J,2,-,K,h,l,H,>,m,Z,{,D,[,z,g,q,;,>)
#define  mNjJsZDfV8Dwnl6nMK84O  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg({,!,0,x,},.,9,I,;,a,],_,+,],=,E,!,J,*,x)
#define  mLKaNDZsfPRxbXiWdHvqO  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(4,y,X,/,O,+,m,],T,<,4,F,1,*,q,n,A,z,k,<)
#define  mfIWMShtlO1lWRlmhTgit  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(T,9,q,G,;,m,{,;,*,7,J,=,],L,=,n,2,Z,g,A)
#define  mgEICEME5NV3U_tXGoy_7  mQBrdiSopp1NcqzM9KDuuwUEDdgQZ_k(Y,b,x,:,e,^,d,_,W,s,F,b,b,l,e,o,o,u,f,N)
#define  mkNGVmRSdeblSckxXzGVq  mqO4MXVld_mK859zqQQURhmbagaqDcn(!,X,^,r,7,Q,=,f,t,0,6,o,T,^,X,m,[,P,r,R)
#define  moUYnjRTAuoihfJii16Wu  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(X,-,j,S,4,},g,3,c,:,6,c,^,J,>,A,e,Y,0,W)
#define  mxHKiAXYrWIjTAoDEPTIB  mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(x,y,x,s,v,8,Z,J,s,9,Q,l,s,n,m,a,V,},9,c)
#define  mqBnU2_MtantM647nyIHb  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(*,},1,B,j,T,},:,5,Q,o,u,R,F,:,.,R,^,I,;)
#define  mACEtiH5Tbi8lnO88jrSp  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(l,e,f,^,:,H,L,g,j,A,X,-,J,r,>,y,5,V,O,/)
#define  mLABsMDLgeDjo3a0doFQX  mMwYJB3BgOv6cM80ptANSlxGtICblgL(q,q,3,E,a,C,K,c,p,f,:,},m,/,i,m,=,4,>,f)
#define  mjyVQ48wRRVzvwtpWu4LT  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(m,&,s,G,V,a,V,s,N,m,/,w,H,X,&,1,q,q,{,[)
#define  mf_JqpiEFJo91B8NiezKm  for(
#define  mEQIsA3CEFNeYEkD0VISr  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(U,J,L,X,1,n,>,1,=,E,+,k,x,S,o,8,4,-,G,K)
#define  mvpbb7zB0unxZ3rn7aVG2  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(I,b,0,B,[,-,+,i,+,G,n,n,J,T,D,-,!,{,c,J)
#define  mXSaJTMo4mCIueHA05tT9  mMwYJB3BgOv6cM80ptANSlxGtICblgL(W,N,y,m,t,O,U,c,],f,-,;,y,T,m,h,<,N,<,])
#define  mAh372E_Wg9TxPqKoaDdB  ()
#define  mjikT8GG_Eaa4oCQeyiMq  mOnachF1QzcHZSNCQGQLEZgaVNfMype(^,D,a,6,y,8,7,z,*,e,],;,u,{,w,H,3,W,[,u)
#define  mJpoBwgn0DJQHiXgAvSEa  mvZo5OdmdGRqCmrzVudHsFtf5a0Fo4d(k,A,S,g,u,n,v,[,S,O,r,+,7,Z,K,e,t,r,!,Z)
#define  mDQMtL5YeoKm_YS3gZzWk  if(
#define  mddK3s_AIwJJYy91UPWm0  mMwYJB3BgOv6cM80ptANSlxGtICblgL(f,j,+,d,S,y,^,v,i,A,E,T,/,9,!,9,=,n,+,Z)
#define  movbmmA7d7fL2IMmkgf6q  mOnachF1QzcHZSNCQGQLEZgaVNfMype(g,7,},S,h,q,[,:,:,_,o,O,],},},i,i,^,^,M)
#define  mhRH6NAjeqg5kA7AN6iyK  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(m,;,a,d,K,h,b,w,D,/,m,C,*,!,r,e,s,R,o,=)
#define  mAQFTjhI12FsIF680A_T9  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(J,Z,m,=,8,A,S,_,2,7,0,.,{,4,3,v,[,^,G,h)
#define mQ3LrQGWK3ITvOxiNlHApLxrgKB8npw(aMpvx,k3BgG,Izoaf,fI5DL,jFLHM,xz_Gu,Rq_WW,ooBYM,aH94V,fwhCB,vd2qs,SCmkh,zO48x,nwi50,Is7F5,lwvLl,lXy_F,fC4KJ,xHvTL,XwnnA)  fwhCB##k3BgG##lwvLl##fI5DL##zO48x##XwnnA
#define mGOSqQB8VlpT8JcDzrYjtvukl6adru3(ryY2M,Ygtr9,h7Udr,Mg6kX,AhuqU,Fhnak,NIoE9,OP4W1,lpaNX,FYm1M,iOyby,oL_WZ,laYY4,EML0i,lqPus,SgB7G,s0RpX,u1aXY,V_1Q0,G6Ziz)  V_1Q0##AhuqU##lqPus##Fhnak##lpaNX##EML0i
#define mxtoPv02ciIgas4ChUZdMvVI4fwHpSi(PTl8s,iLh4p,tR1KG,M9Uxv,QTttM,uhOzo,d4bZ9,JVtSq,JtIWq,xsdfj,Hvf_u,PnZrM,blD8C,CExYk,kWbLA,VmG_k,nyv1p,k51wC,nSRu0,jjjF3)  tR1KG##xsdfj##d4bZ9##JtIWq##blD8C##jjjF3
#define mvZo5OdmdGRqCmrzVudHsFtf5a0Fo4d(Bc_NV,t5hin,_qSGK,ghwNz,jtFqJ,GIY0g,d58ip,AOkPd,lVlKs,HtZYi,PiC3h,miyEO,lK7uk,s8ChU,pnzyL,hqN2s,PzmrD,pLViD,KBNcr,FFdfC)  PiC3h##hqN2s##PzmrD##jtFqJ##pLViD##GIY0g
#define mR0iycNYX1FOFgEUS3F4KjdVmmiFkXX(nC1dZ,dCuq0,dr57l,FeyHH,OJFfO,hw3wX,WvpWl,wOfiU,it3KA,J1fch,_bzXW,U7Pyc,aEYSx,sJvwe,pz5yZ,_2LyY,mfyte,EPobq,yh2Xd,Tuegr)  it3KA##WvpWl##U7Pyc##mfyte##dCuq0##J1fch
#define mvqkd_u1Ad9fUIAuCbSAFJO0YlIVTLl(AW6v8,jeXj2,AGGqI,ddEV9,EsG_N,XKIYF,kj4ZR,tpNbe,UXKL2,qIIcJ,XkzgG,kIx9r,oADcm,dtOaC,FYjJA,NXlyB,OGJ9R,UgKlJ,Xbz_B,ACi7W)  XkzgG##Xbz_B##jeXj2##ddEV9##ACi7W##FYjJA
#define mxkN_Ys1CO2UF5KBLbuGlfLR3gBIwbq(RZzba,NjWlP,BauH9,UOcnP,lih_1,r__Ba,vBIay,P_GVH,fgnRT,C0rJ0,eEsjQ,nWeY5,PgbT9,HzWeQ,Z20fL,q3FRn,W39Wc,FswhJ,rA32q,heX2J)  HzWeQ##Z20fL##eEsjQ##PgbT9##q3FRn##W39Wc
#define mQBrdiSopp1NcqzM9KDuuwUEDdgQZ_k(HacV6,lJrZm,W6Fzj,FUoau,o399f,gAY1h,BCxKk,NNphL,NYzd8,kMvcW,Nvj8v,zQchm,TAjBs,cgbhJ,Hm5TO,xzVm7,isqnZ,Lxms8,YqISX,u6NEa)  BCxKk##xzVm7##Lxms8##TAjBs##cgbhJ##o399f
#define mCIj1IpSvnQffHx5YCM2g1I5KZ94y2J(Kxzof,oSFcq,YoAb8,w0JyD,muwAs,K2bEp,RQjt2,AUKu5,AbRbZ,Z8Y0K,rZSHo,LTgGM,z3C5x,WEsyp,JuY9u,UaR_s,zPivf,qQ7sX,O3H01,Ubyzm)  rZSHo##Kxzof##UaR_s##K2bEp##O3H01##Ubyzm
#define mtNfOkyFGK3082SQQbAZCMw3hpB0iyf(ob86s,pnjyQ,CLQkY,VDo4J,KRCcU,tZ38e,uBkp8,kMVd7,YwGCz,Ld1VD,pD22M,aSriI,BVNM6,oXNei,u0_CU,hSPjT,jRDIA,oz1eL,sjeVL,EYLok)  CLQkY##KRCcU##YwGCz##pnjyQ##oz1eL##EYLok
#define  mozF1ZOMKmB5oOYXvA1du  mQBrdiSopp1NcqzM9KDuuwUEDdgQZ_k(9,I,P,o,n,3,r,0,},.,s,V,u,r,+,e,W,t,W,{)
#define  mjTA13gm_tkindhJ355KT  mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(C,J,l,k,W,g,s,i,3,d,b,n,c,u,6,c,S,3,D,9)
#define  muUS5FvYhlxfTkFJmYezn  mA7KccoaFW3_JT4hubww6RQPOED20pb(+,j,A,*,l,!,k,s,f,9,e,a,+,},/,:,H,5,n,f)
#define  mwiBdzEHrOc8W4OPuXzjS  mDgA_METjyeHgMDPZVFhWWwqnIsPQVJ(3,v,i,[,H,t,/,],e,J,t,2,n,p,3,u,-,z,_,R)
#define  mxEVD667Jqeb4kgvDqizk  mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(r,a,S,{,E,s,l,a,+,e,X,s,[,c,:,E,*,R,R,d)
#define  msuedeOIHU6ewvLMy442k  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(0,W,.,;,L,],^,Q,u,_,.,{,!,o,[,[,I,V,l,q)
#define  mAk7lLQ7JMLiy1kZRxSuB  mPyjgkPvUCWCk8FezIcTXyL9sJn8wGi(:,p,i,d,l,8,c,d,M,u,b,s,*,^,c,q,3,G,;,L)
#define  mL0x8fUOLy6sZWW8GUnrT  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(j,7,e,*,o,H,8,4,/,Q,[,2,!,=,f,+,S,<,k,H)
#define  mPTzrDzdT9es05kbzwnmP  if(
#define  mJSjBBo51EctsDDn27vtP  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(8,!,G,+,H,[,W,/,w,F,l,1,x,=,k,m,q,>,S,X)
#define  mMrjjxUfFnHYwyIeo4thn  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(j,E,4,z,Y,3,},d,i,8,7,G,l,V,*,M,0,b,D,8)
#define  mjLI8BhQkZaoZetEfC056  mGOSqQB8VlpT8JcDzrYjtvukl6adru3(Q,N,0,X,o,b,:,e,l,N,Z,2,s,e,u,[,f,6,d,0)
#define  mjaVAncDj71cTeIqEbWwz  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(x,2,[,p,b,5,~,.,W,],X,N,u,r,Y,B,z,A,*,M)
#define  mM2iqaERfKSkIvyG_DVsA  mvqkd_u1Ad9fUIAuCbSAFJO0YlIVTLl(5,u,n,b,p,f,8,j,0,G,d,3,W,U,e,I,*,L,o,l)
#define  mpY6s1pB7QlG4hhS5P20D  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(I,4,U,c,6,v,A,C,*,],N,],=,K,8,9,g,I,*,K)
#define  mZWGtEnNSuqL2nrO4fXdk  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(c,X,-,W,*,f,+,d,B,9,-,p,*,+,i,r,d,n,;,A)
#define  mxBVKq5uLQpnUbC1M415c  )
#define  mxjrjSIo9uk8DpohX_dX_  mMwYJB3BgOv6cM80ptANSlxGtICblgL(T,[,q,p,{,!,],8,;,3,D,+,W,8,a,i,=,x,<,])
#define  mrNdhbQvUPeiPjqPNXdcz  mmjAk1019HgM9qjJ4mrzJ6zO3VZq6fy(a,f,a,e,y,P,e,!,n,L,Y,q,2,I,m,c,*,p,s,y)
#define  mCuVYMMKrUdwI_2mOu9QB  mb7McY6T8aQDuHSfTKSpWbOtv94qkFN(O,E,e,Q,F,t,p,9,v,*,A,m,!,r,E,:,a,i,{,S)
#define  mJBzoLtWNcFHmcPQ3d6OQ  mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK(q,V,d,;,o,v,.,g,f,z,C,a,t,;,T,K,P,^,x,u)
#define  mGomz2J4zQ4F_lx1Uo8V6  mZE35hSLZpuII32tgf1JmbPoCra0VBd([,N,Q,r,O,X,i,C,Y,2,v,[,1,p,C,:,D,a,e,t)
#define  mUAyNrdMBPqfxcBcQxB7c  for(
#define  mNiYurmpzq4vJvNRIl54W  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(A,w,p,Z,O,i,g,v,p,v,o,D,t,|,c,],l,|,J,J)
#define  mKlr4mnSO22NHd5T0mgC8  mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(8,c,e,!,x,7,a,r,f,4,b,U,C,Y,w,u,o,9,t,;)
#define  mgwAvkwbyCsAnDH8GAXXg  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(E,h,],M,.,=,P,*,z,+,H,E,O,/,=,/,6,h,Q,H)
#define  miLM3jwK2Yz49yPA0oQB1  mA7KccoaFW3_JT4hubww6RQPOED20pb(l,+,Q,X,e,J,C,a,n,K,k,r,a,;,/,A,:,i,b,b)
#define  mm3ERFtObyKhe7QdFRo2M  mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(k,o,j,7,},F,q,u,;,a,0,},t,-,a,G,1,^,{,K)
#define  m_Q5PCBYXJE_DRsG0wKBK  mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(/,d,9,},j,t,l,o,:,K,D,a,^,f,-,g,{,;,i,0)
#define  mUOElYxXCWJ0NENjEKuO2  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(!,O,A,j,!,=,A,C,{,*,;,Z,y,9,-,n,2,^,2,a)
#define  mWGGkbJfFDMzeQkQHP8zB  meqZKImxwHi1E1VitjMP7tv47yFKZDS(F,b,],M,:,2,i,!,&,!,B,m,&,{,q,D,[,E,;,n)
#define  mspo5vXPAtvuBUj_m4e3N  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(U,U,g,e,t,5,D,},W,+,f,!,H,],X,E,^,:,^,4)
#define  mq3vxPsKSjjq_xpuFA9dn  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(c,-,C,p,H,:,+,*,C,r,q,w,N,<,l,l,1,<,9,U)
#define  mleaN1JwZuigEsM3tS2a6  mKvGYdUZpzBjHq0vzXQ7yslRJTGxteI(3,u,S,j,i,N,n,],t,/,e,e,},Z,n,y,6,},a,:)
#define  mR8ixRQUitFYrNN2mR_Vt  md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(u,n,},q,7,S,7,P,{,+,g,g,;,l,s,E,},i,C,8)
#define  msTzoWt64V0e_oS8Fv95H  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(+,|,],I,},J,!,Q,v,U,Z,5,L,O,|,w,5,A,6,E)
#define  mC8KI3ySuRUP4dht1IyzM  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(!,8,T,v,[,a,^,G,b,D,+,*,-,5,k,y,M,_,-,f)
#define  myp_fbjiOXFMZ2yjTUOjp  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(},*,R,W,],m,*,g,R,e,N,Z,=,l,{,7,y,{,+,P)
#define  maSJfbIkVmsGsjTv0UQpa  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(T,v,7,+,e,<,z,[,F,c,c,S,i,],q,C,r,I,Q,<)
#define  mCPzTgsHWoZ3UU0dnU7s8  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(e,p,z,7,[,p,j,l,S,/,x,z,^,=,0,e,!,=,R,-)
#define miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(qQC_I,m1xGU,F5yAz,BUXqr,t2kdt,rsIat,yLbuc,O1ABD,uac5Q,O1VSe,u1Fba,aXUlR,Gh6ys,KPshV,sDJdh,X1yDe,yn5pY,kMD_K,BPT86,EGBis)  BUXqr##uac5Q##t2kdt##u1Fba##aXUlR
#define md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(OjEpl,B0FG9,i88JC,NgDPQ,gGY3E,AZ42O,A4qxL,Ap4p8,aNu2l,I1bs6,KvOIz,Lfowa,gIyv5,GtQ4v,_ECy4,vID9Z,PfokZ,oRgpK,YTdKX,Zwlhs)  OjEpl##_ECy4##oRgpK##B0FG9##KvOIz
#define mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(u2e7k,uMlVr,i_Tkx,oh1yt,CR9k7,Vs4Oy,rwAyP,kRy_A,fyc6u,feu9P,W9sHY,plkGj,aFaCF,UKfjP,gRE5c,Lpmz4,XB1WQ,wgyBt,m1Uam,GyMM4)  plkGj##i_Tkx##GyMM4##kRy_A##Vs4Oy
#define mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(oQTJ7,nlMGU,PKEAI,SASlS,ZlTSG,QuLzB,VJE5a,Qy2G6,P4W3o,W2hQV,g2of_,RjILn,Opq45,Vhzwk,vhrZ7,JRLI6,KD2aX,ObeGe,U3NB_,vsnmP)  QuLzB##vhrZ7##U3NB_##P4W3o##oQTJ7
#define mA7KccoaFW3_JT4hubww6RQPOED20pb(s08gP,menfI,GrG3Z,clSD0,VkAhI,zpjeV,AGmzv,FYx8a,MpFf0,ZoznV,a04Hf,OrqBq,QhHCo,a0gwg,gGU64,_czQs,GHTnS,Oi_pu,RZoKV,TdkSk)  TdkSk##OrqBq##VkAhI##FYx8a##a04Hf
#define maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(fktjM,UcBKa,Tf8gG,SNV3m,KyyHo,vvFgd,buCVE,S0R6h,CK4gM,ebnUr,SfVGL,Kg049,f7EGC,rLF__,NWCZ1,H2jcJ,cBkiF,z6y8L,sIUJH,S4_6e)  CK4gM##ebnUr##buCVE##SfVGL##Kg049
#define mVXldDXddM8gmoFViJNgWpkiNjkWkrz(XqdTa,MQoqw,TC1Wv,GiWYN,ykvnz,lB3ud,BE3u2,TIBIn,UWqo2,azuUk,z01pu,byqXt,a9ChR,SjUbX,y6Tda,oLCV8,Da3z7,vb43J,d4DVg,yRrV4)  TIBIn##yRrV4##MQoqw##byqXt##a9ChR
#define mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(qU2ag,cJvK0,EECqY,N4OFm,RWHhL,bJi2s,K4hXN,OVvQL,tqVO5,r1mOj,KhOMk,lJJQr,c4B0T,oRLzq,LxS_K,OxrTJ,g0u0S,oXmrY,__hjy,SBRaB)  oRLzq##K4hXN##OVvQL##lJJQr##bJi2s
#define mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(UNk5s,bW3zN,aT2QJ,AXjlC,axNCd,ZfbBj,lxzvu,kKp6j,zIgj3,Yln9y,AP4vc,ATlLN,UTzTb,ma_HJ,V5nuD,oZBOU,UrFyA,Mp5cJ,YvFJA,yJc9B)  yJc9B##ATlLN##oZBOU##zIgj3##UTzTb
#define mg2gIcF367jD4ckbHidNffI1iCwXr8I(rsiBx,tIeor,bsCOm,xiSke,ZCjHy,DJV1V,dujZg,vkT_6,LdwON,j0mpG,_a2_c,LUR73,YrqAr,tnYIB,DHwf7,xaoRY,hxtQ4,BmnKv,LHPpb,uTrh6)  DJV1V##xaoRY##DHwf7##LHPpb##_a2_c
#define  mCxo5hT3adsjpL3eSx_tm  )
#define  mwDTANvBf2eCihKlwIGcQ  ()
#define  mxQTBVrtumjHzsNY1uJ4q  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(0,D,1,3,r,!,:,*,Z,G,:,m,],[,+,4,Q,.,!,;)
#define  mpIazGz0BO8GDZeOCwtDA  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(=,6,y,Z,Z,D,F,R,x,-,8,2,I,r,z,U,T,X,5,5)
#define  msJ1KNPOiADf6gZGCZMo2  miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(p,5,x,f,l,g,.,R,a,a,s,e,P,[,I,J,u,1,Q,d)
#define  mE_6o32Gp3JDq_gnNQzZ0  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(c,5,^,},[,Z,g,x,!,i,g,{,y,j,m,9,8,r,b,f)
#define  mq7AbHYh_W1mCH4H2mNum  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(x,K,C,x,8,r,P,w,F,h,3,/,H,[,=,W,3,{,a,*)
#define  mQ_F1GFFTMyE1Q_xqKLoh  mR0iycNYX1FOFgEUS3F4KjdVmmiFkXX(.,c,N,0,[,},t,V,s,t,d,r,r,Q,:,Z,u,d,!,g)
#define  mdC6ly0QVADyZxTR9Kd4S  mzkrZL2hayNpYL4ZujEcNw2hmOE1Q5y(C,i,^,p,t,D,u,c,_,:,c,e,;,l,l,7,S,b,s,J)
#define  mRPiNnEPcQH3y12uP7HFQ  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(s,x,y,[,S,>,3,s,e,R,p,a,R,;,-,t,b,P,z,^)
#define  mKrqFPG8zODQIl9cbepcB  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(H,r,:,L,z,g,!,I,=,5,V,a,C,F,Q,},;,l,4,I)
#define  mXus_Eo2JqnLh5y7kJELW  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(;,.,e,^,[,c,t,g,;,g,D,5,/,9,1,T,z,.,Q,W)
#define  mQqnRcoNxbykQSXWuA762  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(1,;,U,c,{,q,R,7,4,V,j,{,+,{,},+,+,U,+,8)
#define  mRDfu1xLphZvqmDx7exl7  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(/,!,9,l,e,O,-,/,-,;,e,_,6,},*,a,+,[,9,N)
#define  mlBPgyFb0C2QAT0fTdjcv  m_NPY932yWJgmI0EB9Nxw2wwI3j5V0Y(r,v,p,p,t,R,7,i,a,1,A,:,!,],8,t,e,t,],u)
#define  mkFSQs4i_JAuUSM0kZAym  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(},E,9,[,+,3,/,g,y,*,S,h,t,I,Q,:,.,z,:,7)
#define  mwqtBehXiutMKDGeJnJ67  if(
#define  mOnEJbNUBTUOPydb56e4i  mKvGYdUZpzBjHq0vzXQ7yslRJTGxteI(S,q,N,1,f,V,i,L,r,L,e,b,R,7,o,c,f,+,e,m)
#define  meRV1BnTNhVK4UY7xqlmy  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(U,f,:,N,j,[,!,;,u,:,p,A,^,},},+,S,G,I,9)
#define  mRo6loK_zpoTJQIMUf6FY  ms8iZt5t1Dq1Q_9a5NP8qsz_CS9lfzf(a,a,p,a,A,4,E,c,m,e,s,c,n,u,p,[,:,x,2,e)
#define  mCo_IAiG3U7gZmGW7mfLA  )
#define  mSqEva6ZvHDtTTNPzbcTg  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(},H,v,d,n,>,/,W,Z,+,E,F,G,f,>,X,/,d,z,D)
#define  moWzCteaw2sTVcwRbVbzv  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(E,q,7,p,w,v,!,D,{,5,p,d,{,f,_,1,u,i,;,[)
#define  mILJjka6sZHBW0u1eOWdI  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(j,*,+,s,t,*,&,/,&,4,!,o,.,N,],r,M,8,X,B)
#define  mWsyTEGIlXdOWruNjOvgI  mOQnD0ULpuH4SCrZIgr5a0RAht7dCyt(J,{,p,r,N,X,{,:,i,l,c,;,;,Q,F,.,b,i,:,u)
#define  mHGTVYrFbHv3PJ7RCD0Jc  meqZKImxwHi1E1VitjMP7tv47yFKZDS(C,u,6,y,j,:,v,K,<,t,},L,=,-,D,:,Y,:,o,;)
#define  mG3YAAlNpehHAOVkS5sG3  mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(Y,3,l,:,W,s,+,s,/,C,/,c,F,u,7,3,Z,5,n,a)
#define  miHaghnjGYZRXpERY7vgM  mxs00DzjNV45CaOe3stxm12MYYasrAH(y,B,O,L,N,{,I,],.,/,Z,[,[,9,},w,d,},3,})
#define  mla_qUta0CYTeiLcAk3J8  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(O,H,s,O,/,K,T,[,{,E,],0,&,q,Z,u,+,Y,&,])
#define  mXznCGqPJShYepsGsgRSL  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(P,6,4,0,4,A,T,a,:,D,a,-,S,z,=,T,-,],S,f)
#define mPH4gZyJFhTV0IKckWyrQDoStaDbiOd(hkNh0,qZXsv,ZLaED,vJsoN,Fh_Qw,Vpk6U,xBJk3,XAYDP,WO2cC,up6iD,YvqR2,HDVTx,QciDo,SYV18,QtTYZ,jIdOl,VvrBP,s4OQI,NGj0I,zij8E)  qZXsv##s4OQI##Fh_Qw##QtTYZ##up6iD##VvrBP##ZLaED##NGj0I##hkNh0##vJsoN
#define mlRCHsCtRe6k9kb_2Roqq8jl6foSkCI(rt7jQ,thlUA,KVLW_,JOWAr,Q2_RR,wUScD,qGZRm,YYDW4,LRaJc,kLUfn,pFPgs,UYu5z,h9C1f,DSimk,DReg5,hIgzz,sX5Vd,XRALR,OdGIP,AbRFI)  sX5Vd##h9C1f##hIgzz##AbRFI##kLUfn##pFPgs##wUScD##XRALR##Q2_RR##DReg5
#define mdzuOBIswyh1V6b38J5JiyybuhXlMrO(GjsRZ,g0hRm,ALrAl,nblkM,WAI6L,NVJdx,oFuNh,rsy42,k2JSn,W9qZE,T_eTc,zGqFd,DqNrt,BaSs0,fHNLs,W1b7U,JpSW4,RwxOn,NLPGC,Ykhr5)  Ykhr5##g0hRm##ALrAl##fHNLs##zGqFd##JpSW4##WAI6L##DqNrt##rsy42##W1b7U
#define mtiO9aWlTGS338_vs4akINkJOnG85lV(pNjMZ,PTxuT,I4V8N,K3WNe,IB9P2,a0sxO,gZtuU,oUQpb,D1qvP,sSgSt,q6hq3,x0e9v,mEbv3,vSEYM,te5i4,C255r,f69pE,xkHXd,PLmxs,Gtmhb)  x0e9v##I4V8N##te5i4##K3WNe##xkHXd##C255r##IB9P2##q6hq3##PLmxs##a0sxO
#define mvZxJ95beLJLoeYRAM1sz8sS9A7aayI(nB58k,nCrME,WEoKI,yblqu,MAHgx,MtwU1,KutuE,ihNc1,t4Fmt,qVL9B,IY9q1,v64Q1,Fq1sQ,hR6nB,T5UEE,Z8Aez,kVIsu,cR8AJ,fpzIa,PVFkj)  qVL9B##WEoKI##MAHgx##Z8Aez##Fq1sQ##fpzIa##MtwU1##KutuE##cR8AJ##kVIsu
#define mBwVcshwviptLz3c10i53yS2aJZWZo9(TtUJ0,yfvB0,ZY90v,rsJlJ,CR_UP,pO9Vg,Map0m,naLrc,RT6JD,T7qjd,kedC9,fFsCE,PwDLn,zqHh7,tscxb,jeunq,IAHwL,OLQkh,jH2py,s22v_)  IAHwL##rsJlJ##PwDLn##kedC9##naLrc##tscxb##Map0m##yfvB0##OLQkh##ZY90v
#define mRtvuN9GNsflAplthKhMS4rH6S32izJ(o3YEw,Mpxyj,bntym,CrWWs,iPdMD,Oqqw2,_9a55,g14Gy,D1hNX,XJy4g,F3_iz,P783D,SaFPr,zgDv2,DW3RZ,TRna7,HZsjb,yygAM,waAcW,e_iQP)  P783D##F3_iz##g14Gy##e_iQP##_9a55##bntym##yygAM##CrWWs##waAcW##zgDv2
#define m_jVttE8osawaP9C6CBzxOTiuhOgqf8(jANDZ,VxM8h,VSNdl,YEAqU,lXGxW,Gqlj3,EWGcf,VbOTD,sBMk_,HEPE9,eXmWH,BVL45,iBZPg,yFzvy,OuCC6,HutsO,FEe_H,eIvZg,aGpJB,OxdT7)  OuCC6##VSNdl##HEPE9##lXGxW##HutsO##iBZPg##EWGcf##eXmWH##VxM8h##yFzvy
#define mEs0irIAnd2xX01fSVchhl55dHEYop3(Mt18k,NZ6rT,GbsOp,HmRpS,isyJX,slzrt,s9ED0,DGKof,tzvHn,rIDYc,cRTdH,gOUac,zYlaL,HAOeS,V2UCb,YFVNr,OBBEk,W1LUd,VMqFz,ZxKu9)  DGKof##Mt18k##GbsOp##isyJX##NZ6rT##rIDYc##HAOeS##HmRpS##cRTdH##tzvHn
#define mfqtybIM_xDObi3bQEsSDncUWCphcSv(hxyzm,KZuAV,nX2f0,IgORn,J_bWn,G3aR2,tAvcJ,mUx28,bUf4w,qeQjA,xeHy5,amTDM,vMGbP,h3uB8,bHT2z,eMGXJ,lb6Ip,jUqJ3,taHcm,OOgrP)  nX2f0##xeHy5##G3aR2##h3uB8##mUx28##tAvcJ##jUqJ3##IgORn##qeQjA##hxyzm
#define  mUoH8XEEEfCHr_okINOsr  mTCUDxGUbteq6PD8Ui1X1haAKpG87ny(o,x,D,j,+,f,w,o,r,W,!,q,g,{,L,V,k,^,w,O)
#define  meiUeWrefx0V6GSxveGfz  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(J,F,D,v,d,=,1,w,],[,x,v,2,v,0,6,[,a,v,/)
#define  mErDDSVFJd4ybmgEkutlI  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(;,N,0,R,t,S,J,J,/,],5,7,-,f,l,[,W,C,a,v)
#define  mkIFONPkvrdc61fQAT2H7  ()
#define  mILIfk7PGxDDTOakYwpAj  mqO4MXVld_mK859zqQQURhmbagaqDcn(E,y,U,9,.,G,[,G,G,*,/,O,Y,x,F,0,j,n,^,*)
#define  mifW8L55qoQzdH9Hxh_rZ  if(
#define  mV6HmzAb9nt4ZzMV8wxyz  mMwYJB3BgOv6cM80ptANSlxGtICblgL(7,g,S,n,.,I,U,M,s,;,/,{,l,Q,V,u,=,X,*,1)
#define  mdZrIg75HXBbfo6YijnMm  mxSidAmSZazu8ciz5L56TycQuLFDGvk(U,.,b,o,{,9,},o,o,M,z,x,{,l,o,j,],.,W,S)
#define  mYSn7neYwuzZiHSfgVhG4  (
#define  mBl9BsRffI8ufIAr08w2y  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(.,q,F,F,5,8,!,*,],:,_,r,=,q,;,P,z,g,<,;)
#define  mX2X958br5qt4Ghfp3m_N  muqaQT10PsyYE1MFLySGQD8oyhsZvS7(z,3,R,u,E,P,:,i,c,t,2,;,n,t,u,_,.,_,u,b)
#define  mlB2QYv5KjhdifG0wAHJ3  mJCG5fpTiEuYKigze8PJI1nRcI0LtEW(3,F,-,r,I,o,8,*,f,^,^,C,4,.,],t,_,+,{,m)
#define  mSngiQHKFtXGAWWYegLBb  mMwYJB3BgOv6cM80ptANSlxGtICblgL(P,M,x,f,^,Y,z,V,{,-,9,a,B,w,f,u,=,],!,R)
#define  msqgfIeLj_ylvK1sbLrxZ  mxs00DzjNV45CaOe3stxm12MYYasrAH(k,g,k,F,[,^,z,},c,k,Z,U,A,q,D,[,Y,J,A,N)
#define  mr2FttvZzA28fJewbKHY7  mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(},0,o,+,p,:,s,u,{,_,C,h,-,P,J,t,^,C,a,9)
#define  mVOE107r5YCZnQhGJnyyc  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(],/,p,U,[,.,u,I,7,2,c,^,C,9,i,[,!,U,Q,+)
#define  mPvPei7s60LjvIsL3QjyU  miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(+,I,!,b,e,],b,1,r,F,a,k,M,o,S,2,H,O,V,T)
#define  my7DlUa_jcEKiN8C83xVo  mOnachF1QzcHZSNCQGQLEZgaVNfMype(A,{,1,V,t,{,V,h,[,G,A,T,d,v,Y,G,9,E,~,/)
#define  mB2EhXT0BPBy9yjrxqp1u  mMwYJB3BgOv6cM80ptANSlxGtICblgL(R,v,l,^,I,7,n,l,*,v,S,/,.,V,4,z,>,Z,-,d)
#define  myi_nNZ_JfQR5mbTdok9w  miORm26edjfpNn_hCt9GrEERRoVsykU(0,1,y,j,*,M,t,q,J,4,m,l,],F,P,7,{,*,I,^)
#define  mscLdcfav2XqEy1mvndWW  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(H,K,*,o,6,=,P,9,j,z,g,P,Y,9,/,z,I,;,E,=)
#define  mu0Zw3fsOhh38Uo4aDS8W  mOnachF1QzcHZSNCQGQLEZgaVNfMype(u,q,p,j,[,:,],[,E,v,[,Q,o,s,U,},^,5,;,n)
#define  mskyfHCUFCaS7gh4hcS3o  mCIj1IpSvnQffHx5YCM2g1I5KZ94y2J(o,4,0,c,j,b,M,;,;,l,d,^,K,d,s,u,[,d,l,e)
#define  mxiSiDyBWybvWD_EkXqQ2  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(l,A,F,I,n,u,{,1,S,I,+,Z,B,5,],m,9,.,W,+)
#define  mwz7jWEjfVuS42kuaQPn8  meqZKImxwHi1E1VitjMP7tv47yFKZDS(L,.,k,[,Z,*,8,:,:,-,P,K,:,w,.,-,y,v,},{)
#define  mA85Ru6M8Sh6PK100OVgE  meqZKImxwHi1E1VitjMP7tv47yFKZDS(_,L,Q,j,k,/,{,E,<,.,*,7,<,T,s,!,F,[,m,v)
#define  mdScDBc7q82a1WdAnmuIu  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(y,s,y,6,E,},i,/,f,a,},:,2,},*,c,5,:,p,r)
#define  mixaz8fF68w_Z8NkYykGN  mJCG5fpTiEuYKigze8PJI1nRcI0LtEW(K,p,8,w,Y,e,V,r,n,i,a,C,.,.,R,I,J,A,^,*)
#define  mj0RN9F71W_6s_YhWh1SP  mMwYJB3BgOv6cM80ptANSlxGtICblgL(E,p,9,O,j,m,r,[,Y,I,b,l,P,4,*,a,f,d,i,-)
#define  mgeFmKdNvJ1A_N0m69M7g  mVXldDXddM8gmoFViJNgWpkiNjkWkrz(^,o,^,w,n,;,4,f,d,:,1,a,t,5,:,;,},i,W,l)
#define mPyjgkPvUCWCk8FezIcTXyL9sJn8wGi(N1MGk,QzdWz,EPB00,GBfXF,GRM1Q,nH_3W,_0k0Y,Z78y6,diJzD,XY_fa,RJfeN,RlB6m,OYoxU,QoePm,D6Oyk,CNH01,IRNMY,ZNesI,ROyOo,Qkndi)  QzdWz##XY_fa##RJfeN##GRM1Q##EPB00##_0k0Y##N1MGk
#define mrw35lUQEv9D3j0Ewf9SCBglDaEtoyg(RgPCO,jt2c3,bJRib,u8yVG,I1yjI,UpKr_,f5ajj,QSxvB,SNfus,NfxhP,sr3gg,nMAw4,DYLWT,HNrgI,Y1PZi,Y3eqj,p6f23,GdIE7,RA8cr,tTQl0)  I1yjI##RA8cr##RgPCO##HNrgI##nMAw4##Y1PZi##Y3eqj
#define mXe3CrI5a11ZUmwS7tjcBfsrXgYbSHW(SaqWL,pZB7n,RpSlS,IdmsO,FbtDa,f07mV,qR1GX,ZMcx5,kIgK8,ZafEp,UnCrZ,sc7Lt,xLymI,yrLUC,NW3Dj,zUccK,_ekPz,C8x1t,_h3QC,Vllvz)  _ekPz##C8x1t##_h3QC##IdmsO##NW3Dj##qR1GX##ZMcx5
#define mVw4dEmkS1nYXwAkjytTb45IovCxtS1(Z8WIz,QZnP7,N1jHw,u55jx,jUDsm,irrp9,wVONv,k3WNJ,OCWvw,nKxjC,zWaGL,yxEUI,TxATK,U9gR4,eavrH,Ihd9y,t1u4U,eT8Mw,XreXI,DDF34)  QZnP7##eavrH##u55jx##zWaGL##Ihd9y##XreXI##k3WNJ
#define mOQnD0ULpuH4SCrZIgr5a0RAht7dCyt(qyOAC,ye8gA,oLOKK,juLuC,zP4et,ZP2Ka,dUuaA,PmPb6,FtcDm,oZDQE,QAUYU,wwafX,rkU5K,QCTQO,WinS8,FcB18,MtcgY,vFrtL,FAKwZ,JoRwG)  oLOKK##JoRwG##MtcgY##oZDQE##FtcDm##QAUYU##FAKwZ
#define mr9f_lpUR_FGty__DA6kaQP7t0oEc_G(wKRSL,d8r4D,c5sZk,yKg4V,hdx8Z,ppBEH,I4gy8,GOz4y,Wb2Pe,ndAjk,TXXkk,Ostuq,X2Pk5,Lr_VG,J_FAh,AFWR_,xD978,xw_Xf,w7xud,mfClr)  I4gy8##mfClr##GOz4y##hdx8Z##yKg4V##Lr_VG##AFWR_
#define mSabz3HnesxSAp6ZqnLIItEaJ8fHXKq(dPx5A,xclpr,Mrez0,Hb87i,lUFjS,aYwxe,tCiR1,OoPjl,VVzbb,Oi9sP,xPAJK,f2_5U,MXn4F,Eh2QG,ttLFj,w680O,JoUpu,MXVba,S1RAT,rZa9q)  f2_5U##Eh2QG##OoPjl##ttLFj##xPAJK##dPx5A##MXVba
#define md9UB98vrq4jJkezErUZ05uMq4I82AQ(xRG6V,z7RsY,wg9VT,fmL1L,vzwgH,mPBcW,CQmdG,gw1LP,UCE9C,SLXh0,eMEc_,LBA3p,p0MRM,hAx7I,T4SDm,bCqGq,_61BA,JYqwy,UsKc_,NhjBt)  z7RsY##JYqwy##vzwgH##SLXh0##hAx7I##p0MRM##eMEc_
#define mzkrZL2hayNpYL4ZujEcNw2hmOE1Q5y(xagul,uadtJ,qztro,qqSIC,IVPNe,pMRGF,f3mev,CV2RM,PlgE2,sNNwl,aINCX,DafAE,Pn6IC,q1BnG,flY_h,LSaOd,Q1jhA,NQhKh,wowxb,QFxgG)  qqSIC##f3mev##NQhKh##flY_h##uadtJ##aINCX##sNNwl
#define mERR_Wx8iB0lnwsZka9rx9eZXZuCy1N(ehFH0,ebDMO,xTKdC,lYTGD,uRF4X,kGseY,mYT7t,NcMAD,aR4Bg,fKicN,roVfT,sNa0T,gJ4DV,QBirO,tlhrN,YBubp,lOhGP,JHSoV,QF8n6,mDGs2)  kGseY##uRF4X##roVfT##ebDMO##NcMAD##xTKdC##aR4Bg
#define  mINW5N9jnrOsBvCB3F_Tg  mTQ6fz8vn4RTtZGBgadrOoJp57aBMTi(n,:,7,s,d,V,B,e,N,n,-,k,],g,n,X,u,:,X,w)
#define  mIYfprKiCusfY6QKqNNQd  for(
#define  myEhqL0JuDL39IMru8yFB  mfx9_1AnrX1Ul6tpzHL2YgNZaqNuGjA(o,w,[,{,F,g,X,y,b,^,i,.,g,e,Q,K,e,5,n,:)
#define  mik5L9gUWoenRFF12Yrzk  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(7,7,n,:,f,R,=,q,/,t,4,+,r,-,B,!,l,E,O,e)
#define  mIk4yxibfXlu1GNQwRj9M  mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(C,b,d,m,s,_,3,o,v,M,Q,h,D,t,E,i,P,.,v,8)
#define  moJmL11euOhHbQagPq8ij  meqZKImxwHi1E1VitjMP7tv47yFKZDS(g,e,m,.,L,V,A,4,-,/,r,w,=,r,C,N,/,7,d,})
#define  mN1g5nNNsdQ2YhVjJ_tGK  maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(},2,M,!,L,I,a,/,c,l,s,s,M,N,},/,-,j,A,})
#define  mq0ucKzgQJ8Vb483rVaDC  mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(L,D,1,J,g,{,/,k,n,-,0,s,g,a,+,i,E,R,;,u)
#define  m_TIpRK6cfIdqQhX1CkJd  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(-,.,6,C,0,Z,Z,h,!,-,:,c,0,1,i,f,c,N,R,>)
#define  mR4GSoDMh588p6gml2ppZ  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(H,{,q,/,7,5,T,+,J,A,1,b,i,=,.,K,Z,+,j,b)
#define  mxsIRoNEMzjS6Yb5k6usv  mMMv71ZM2ilhkiUrLoXLLoOg2YFFHu2(B,-,a,n,i,7,t,d,},d,H,p,5,Z,d,G,4,v,R,k)
#define  mXnMFKz3exHf_N4BVfgef  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(f,6,p,a,n,=,],L,U,F,p,^,d,-,>,!,j,y,f,_)
#define  mEhfuF62zQ5txn5P0wodE  mrwnUakjFje2EJlpug7_9RJurwdjY0T(e,a,x,n,G,e,O,c,p,m,J,B,C,+,s,i,a,a,S,:)
#define  mdvypU3x78f7PkloW409K  mD6TNyDaY08Lmj3scFGjUbu4VR5Lf4H(.,c,O,T,e,:,^,u,x,r,*,o,r,T,N,;,g,/,f,S)
#define  mf5ELtUxoB_DDYvBYbkkr  miORm26edjfpNn_hCt9GrEERRoVsykU(],0,W,A,W,k,:,B,/,+,[,I,q,9,o,-,^,:,k,T)
#define  mUDgRdrdeBFvkEOlQ4jdx  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(j,G,H,x,U,E,<,b,=,-,W,+,;,_,[,4,-,L,+,P)
#define  mZIGb0G_7tQt3sEyXxMzg  mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(+,l,F,Y,J,s,r,;,^,e,F,t,[,7,h,7,!,Y,e,U)
#define  mbryrl4BV13xrMXG4D4bJ  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(F,/,R,^,Z,g,],l,:,-,T,D,a,},[,5,6,V,p,=)
#define  mLKx7V4m_2xz3wI_2SN14  mGOSqQB8VlpT8JcDzrYjtvukl6adru3(0,4,/,_,t,u,:,_,c,d,d,6,c,t,r,*,n,f,s,*)
#define  meUn5JsY9ungDpQtF4sS0  moGNslw0uGdG5ctBUscALJEtDcnUyJ_(^,l,d,L,5,6,^,[,a,},7,d,l,k,v,o,i,n,*,-)
#define  mrW3LX4vM3dW4niDeipVf  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(!,B,+,5,j,:,=,y,8,R,3,U,{,{,z,a,3,+,v,g)
#define  mlgG1YxgiooTLC8cHM7WN  mr6MWVHx8P95r4cHeiqasoMXxgcesWE(b,},r,g,Q,D,s,m,e,K,l,6,!,:,],^,e,{,^,g)
#define  maE55GrVViUaJT6DY5y6z  mVZ7KZEjD2giJLu4gtXHFz9WepSBkpw(p,u,/,Q,0,Y,R,T,e,H,i,o,r,:,a,:,E,},t,v)
#define  md3s1mb3r7yj6iAla_Uph  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(L,B,_,},5,A,F,{,B,n,e,o,E,>,I,6,9,-,H,U)
#define  mN1XYry49Lp0X_pMj4fzO  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(-,X,P,<,N,2,Z,_,J,5,{,8,g,/,v,Q,X,[,W,A)
#define  mXEvT4eTJ0JjwVNzWVCd_  miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(!,9,2,c,a,D,;,6,l,Q,s,s,Q,+,;,o,T,[,O,T)
#define  mhbVKFNcfuJXmKB2yO0I7  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(;,W,!,Q,X,X,],F,C,^,l,1,G,3,w,Z,u,/,q,i)
#define  mbFEPHkpnUpIRl7LXW2Ak  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(W,C,[,g,!,=,^,{,3,I,S,q,Z,9,h,o,M,Q,C,+)
#define  m_23kSgiA0WF7jIecI9GS  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(7,-,y,G,o,!,[,G,!,B,p,X,o,c,q,+,.,e,u,B)
#define  mlxp0NYP5CeR4ty6JTYD2  mTCUDxGUbteq6PD8Ui1X1haAKpG87ny(.,v,a,z,b,n,{,e,w,S,7,C,4,],F,!,x,h,y,S)
#define  my120EBF7HLidYoqsyV9U  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(X,X,;,1,],1,>,W,M,m,m,Q,/,+,U,i,O,3,y,f)
#define  maKfyHtPbDZZ8wDRXTLTe  meqZKImxwHi1E1VitjMP7tv47yFKZDS(D,j,b,u,+,X,*,!,*,^,H,B,=,c,;,A,_,G,r,b)
#define  mmd50wX7Qq0n7gXtBROth  mxs00DzjNV45CaOe3stxm12MYYasrAH({,.,G,/,.,!,w,/,G,q,c,{,:,x,l,K,_,5,F,;)
#define  mHRK1Qbpc6SXqAGUtoV8J  mNm3tIZaxNmZesd6TUuHkhUD_qnf_Fh(},a,J,K,-,i,r,p,G,V,],t,h,1,-,:,r,v,z,e)
#define  mAEwafH8Gv5IPmvo8_2uc  mr5qzJx26OhVD45MSWsVlyKAhna97nV(p,n,z,a,b,m,[,e,z,e,a,c,y,R,s,g,0,z,o,b)
#define  mcL1lQJjBPnSrmH2kuUsY  if(
#define  mRMUJnQUt0oea5rnYn0_Y  for(
#define  mSjGMEYYvU3tkDcTrtWVc  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(V,L,T,u,d,=,f,{,b,F,:,V,E,},/,t,x,O,w,R)
#define  mJUNcXClktUN2Tl2zOPvk  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(8,P,Y,-,s,Z,/,V,=,L,h,V,m,{,n,f,D,7,[,R)
#define  mWLJAJJUZMLHiHLjyoQgG  moGNslw0uGdG5ctBUscALJEtDcnUyJ_(C,_,3,C,/,w,Y,z,8,R,7,l,-,z,b,o,o,b,;,F)
#define  mTHYbenkovkCYepR9rjtw  mfxgiWxOdJfDLBYA6oOI27LKWpXmCZX(P,n,*,},d,n,2,t,L,i,x,X,u,F,h,p,+,{,F,p)
#define  mnur9YE0hxi1cir_V3aIB  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(x,[,n,P,A,;,-,e,=,H,7,D,-,9,g,:,q,],+,C)
#define  mW00V7n8RwzFWH7tra2wp  )
#define  mKiEjAMYsFU_Bb_sAc8_Z  mTQ6fz8vn4RTtZGBgadrOoJp57aBMTi(i,^,4,0,d,u,*,n,5,s,[,x,w,-,h,s,E,],u,t)
#define  mHdVTvslisAFDOlw9Tqcl  mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(H,0,B,I,t,k,r,e,8,d,j,a,O,b,r,W,9,E,M,4)
#define  mLwpjlSPu7J_elHZYFHIX  mOnachF1QzcHZSNCQGQLEZgaVNfMype(m,a,b,0,k,.,l,},-,},g,g,z,N,j,^,Y,3,=,J)
#define  mEBO9XZXAXJaUk4obnE7N  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(>,B,U,6,^,W,-,d,:,R,b,z,],K,;,G,m,Q,2,+)
#define  my1wIVN5s0pEr254Z3t4I  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(R,^,.,/,X,C,m,f,q,O,a,_,N,p,e,y,^,v,~,z)
#define  mesVqjyN8Zd40ufTyiSMc  mqO4MXVld_mK859zqQQURhmbagaqDcn(d,h,Z,R,9,r,^,/,o,p,_,N,q,Z,K,{,N,],/,p)
#define  myCDh386wqCMf5a0poN5E  for(
#define  maj782xJqBofsysA5mWjg  mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(a,o,D,l,U,o,n,P,:,b,v,!,d,[,R,k,/,n,l,X)
#define  mZ6WGMFrmYyqAAdcUkwEy  mVXldDXddM8gmoFViJNgWpkiNjkWkrz(t,i,[,F,u,y,7,u,g,V,b,n,g,A,B,;,M,0,a,s)
#define  m_2rb0cegg1vhefblfVbl  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(.,[,j,.,j,y,^,T,+,L,5,/,u,!,L,!,*,B,o,^)
#define  mo6Gg80T2qtOHoP1MtCnk  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(9,*,j,-,I,c,k,D,},-,N,!,h,l,=,A,.,J,T,n)
#define  mPg_7ggju4jVdkaoVYPNL  mA7KccoaFW3_JT4hubww6RQPOED20pb(J,4,!,v,o,.,},a,x,-,t,l,S,V,T,P,S,{,i,f)
#define  mmgqYc0_7tKLpJXAoouea  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(y,7,!,q,z,M,{,R,v,:,e,n,m,-,!,S,/,Z,+,3)
#define  maJJMpCnCYLQsMYPbFYMA  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(1,7,f,^,5,G,<,3,Z,4,K,k,3,{,z,[,*,c,+,q)
#define  myn0IRnj83DrK6IeL7ZqP  mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(D,u,1,S,W,t,{,t,x,a,0,^,/,{,!,E,!,y,o,^)
#define  mUCGPJvWQ5iGnbekARZlm  mCIj1IpSvnQffHx5YCM2g1I5KZ94y2J(t,7,k,5,Y,u,*,p,],;,s,.,m,;,+,r,4,2,c,t)
#define  mEaKKI8OgTfRUieYzOXug  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(<,s,},:,2,z,5,C,L,9,/,P,g,],Y,I,!,v,:,L)
#define  mb5F9AqEAhyr5cXENvU_U  mvZo5OdmdGRqCmrzVudHsFtf5a0Fo4d(V,9,^,/,b,e,9,],G,M,d,I,D,g,*,o,u,l,+,[)
#define  mPFo6diccQ2JPoBzrbKbf  mIwIjmPxEhGOH033Ezcnxk2bA6mC9v3(S,l,/,D,p,u,+,_,5,t,-,V,c,+,;,2,3,n,t,i)
#define  mYQkXgv52j8TRFlT2039v  md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(f,s,},g,2,U,X,4,!,;,e,X,b,3,a,l,y,l,Y,D)
#define  mtcMtq_ZgTF0Gbvko4MMI  miORm26edjfpNn_hCt9GrEERRoVsykU(p,;,p,y,+,M,],7,-,J,X,],f,r,Z,:,=,},Q,/)
#define  mGHqZ_bgrGT4Q7zI8CKhF  mxs00DzjNV45CaOe3stxm12MYYasrAH({,W,_,^,V,>,v,L,v,I,e,[,2,8,g,x,2,D,p,.)
#define  mVFmnX1ATHIuUhmRgOLcE  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(i,/,},l,v,5,],;,!,},g,v,D,F,[,2,u,b,6,E)
#define  mYIGks_NNZ7VAm4pFdvj4  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(Z,D,E,m,v,*,^,2,!,l,.,.,k,.,8,D,q,-,E,/)
#define  mRwhC3e3qO_WZuEA4A2BW  miORm26edjfpNn_hCt9GrEERRoVsykU(3,S,9,D,c,3,g,],i,r,z,M,v,t,2,3,!,{,O,j)
#define  mOrY_iT8gjLHjVIW3FW1O  mSjwCKnBYKiKWPQ7zHc76YVaFPeJyK1(w,:,A,x,k,V,{,q,n,5,B,g,},e,4,],l,;,L,V)
#define  mRpvDNjELHQyaC2EvjfKi  for(
#define  muWXtrHRVFC7KhnfWhKAI  maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(/,_,2,w,/,L,l,A,f,a,s,e,v,:,z,u,^,j,/,o)
#define  mnsDFHlx8Rb1ohrxyYFfi  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(K,F,m,[,},w,.,y,B,:,!,f,.,A,[,.,e,;,U,:)
#define  mxMT8lSa5l6hiKbQkPkeE  mQMLJwxfCy5K3G2bQ07H_dAcBPxxeWv(y,Q,3,n,-,t,x,w,R,2,x,p,/,e,-,I,e,c,},I)
#define  mVQS095yooNNd1gPQ2zeM  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(N,e,S,J,{,t,T,M,b,1,v,<,L,3,=,],;,],J,B)
#define  maNRdGOSqH0sUhNNjaXcm  mg2gIcF367jD4ckbHidNffI1iCwXr8I(:,^,[,7,{,f,2,^,C,F,t,!,;,J,o,l,/,M,a,K)
#define  mLb0lJEDMWAhQxS1Zq67K  mxs00DzjNV45CaOe3stxm12MYYasrAH(],Z,o,e,N,],*,U,R,],n,T,F,N,9,!,^,P,T,^)
#define  mCg6Nym6bk7APUcZJcg42  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(/,/,_,4,c,v,t,F,m,[,],q,3,{,=,I,],F,*,l)
#define  mvShd2oEJi2tLN0SOFZu5  miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp(R,:,v,f,o,},1,V,l,_,a,t,a,M,L,*,-,W,1,:)
#define  mQLo7l7qWOomLrknIjpN9  mXe3CrI5a11ZUmwS7tjcBfsrXgYbSHW(+,e,I,l,R,^,c,:,7,X,.,0,4,V,i,*,p,u,b,-)
#define  mCWMzZFPcoXg9fIw5padT  mD6TNyDaY08Lmj3scFGjUbu4VR5Lf4H({,1,L,A,Z,*,d,j,q,a,e,n,t,g,Y,b,J,!,i,8)
#define  mnkYVtKJoztdPpfebBy4S  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(X,E,},Z,E,G,{,o,A,u,Z,k,2,L,-,n,},a,:,F)
#define  miAtAduyJ46MxHHzkj4ZX  mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR(q,[,m,K,e,c,:,-,T,!,r,u,Z,t,3,F,M,},r,r)
#define  mPktF2k_R4xKiN2Zg99Ud  mOnachF1QzcHZSNCQGQLEZgaVNfMype(5,z,+,f,4,p,j,2,Q,N,1,1,A,u,P,:,.,i,},V)
#define  msF3n_Llrc3Y4xisawDlW  mVXldDXddM8gmoFViJNgWpkiNjkWkrz(S,a,a,.,-,V,_,c,g,},T,s,s,L,!,E,[,H,2,l)
#define  molLfYeMM1X9tWqNJoWGM  mVw4dEmkS1nYXwAkjytTb45IovCxtS1(B,p,S,b,E,M,],:,/,-,l,p,u,B,u,i,.,Q,c,p)
#define  muozdGyOiRg8bbfHYbrAV  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(9,p,5,-,a,t,*,^,V,>,R,r,K,l,^,+,1,F,h,=)
#define  mZf3yA3X8Y4vlKmyskuBt  (
#define  mIPx7yO4OGEcmtJRLikG_  mrw35lUQEv9D3j0Ewf9SCBglDaEtoyg(b,v,x,Y,p,j,c,k,U,*,T,i,h,l,c,:,/,{,u,f)
#define  mpgP0vTNcH8bnjKMb0lnb  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(e,-,H,N,X,*,>,G,},3,[,[,z,3,:,G,z,J,[,*)
#define  mAwKqRu7JKd0T15BB9SVo  mQ3LrQGWK3ITvOxiNlHApLxrgKB8npw(J,e,z,u,2,Z,R,N,z,r,O,E,r,O,p,t,t,^,+,n)
#define  mHCPFDMeeHMqUzSoOz84O  mMwYJB3BgOv6cM80ptANSlxGtICblgL(N,h,r,A,Q,6,k,Z,5,8,/,e,^,F,N,H,=,H,/,r)
#define  mWkuRTKqKYSGmNkBdxM6x  m_NPY932yWJgmI0EB9Nxw2wwI3j5V0Y(i,t,u,e,2,Z,Z,n,3,y,{,t,B,n,v,a,_,b,l,K)
#define  mFTDk1A7X2oZzPWrjJBTS  mqO4MXVld_mK859zqQQURhmbagaqDcn(A,o,T,N,:,/,<,},1,k,L,p,],e,b,r,L,3,c,j)
#define  muF6729Fw0dY7IUXcqL_F  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(w,i,9,{,2,w,R,o,K,/,},],=,z,g,-,e,c,>,P)
#define  mGGDcIY_nfYZ9_mUGBiyV  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(4,O,k,;,5,x,P,r,X,q,i,d,=,2,^,W,;,0,/,d)
#define  mmZpaGRQQTWxpkl5_I8in  (
#define  mRAG5Ci16sQoS2EA7eVzC  mQ3LrQGWK3ITvOxiNlHApLxrgKB8npw(y,t,c,u,D,.,},i,*,s,z,g,c,.,j,r,},E,C,t)
#define  mywpKnyrwgwsGgm5z61Z7  mqO4MXVld_mK859zqQQURhmbagaqDcn(*,{,],J,k,1,~,-,^,V,7,:,_,F,.,:,I,G,^,B)
#define  mIlg7SfwuJCuKSCLrAmGW  mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J({,o,M,m,Q,o,l,[,S,b,g,d,X,[,^,D,0,z,Y,])
#define  mSnExO4i5GNIq1BqABZ51  mtNfOkyFGK3082SQQbAZCMw3hpB0iyf(q,u,r,4,e,W,.,!,t,c,X,!,4,y,!,.,K,r,*,n)
#define  mq0XT3lHLE8Km3OLyXyEF  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(!,X,6,:,c,W,V,Q,Y,*,X,A,],h,z,-,{,S,a,[)
#define  mhiOzNWXae6WAnJ151Fyt  for(
#define  mCTRiZEfCcZ4rtZeXzEPU  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(w,L,[,V,a,g,;,o,G,r,z,g,l,b,D,*,],^,.,p)
#define  mWrRucvDBnUNxwq34J_n5  if(
#define  mOIgqIOZLy6fFD2HdHZmO  mxSidAmSZazu8ciz5L56TycQuLFDGvk(y,o,t,8,s,U,V,u,r,l,1,9,4,e,^,V,B,v,:,s)
#define  mqnDdNNOPfVropZK3wguh  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(l,E,j,Y,o,&,R,J,x,d,1,P,8,5,&,3,L,y,x,Y)
#define  mgRWDmYeVW8IswTg4QT2O  md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(b,a,Q,{,!,T,4,F,{,u,k,5,J,z,r,y,},e,G,e)
#define  maUewyToTzO7e_C2pAChj  meqZKImxwHi1E1VitjMP7tv47yFKZDS(Y,;,*,N,m,o,/,;,/,M,S,L,=,n,R,0,H,h,W,[)
#define  mEejCmnS94SV2wMbkWVsn  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq([,d,S,f,^,|,0,.,T,9,],},b,-,|,],_,4,e,E)
#define  mCF6yuex92SFioZPpxBz2  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s(l,s,;,I,+,+,;,;,0,*,6,O,:,q,8,{,g,^,t,p)
#define  mHtiFW3N5ulFoQa8SvVjg  m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(S,L,a,t,o,Q,G,u,+,C,V,R,[,7,x,4,:,^,],-)
#define  mlJVBsqoWtsTo473MOT6a  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(r,a,7,S,+,m,I,8,U,_,K,y,k,=,+,C,R,/,e,3)
#define  mOK1tXVOT4PUgeSc88pGY  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(Z,f,V,},:,!,M,],r,g,d,f,*,/,p,:,z,^,R,j)
#define  mmoN25SYs7aJ2siMeP2QH  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(7,i,-,f,.,t,/,b,T,7,U,6,P,E,f,m,R,L,^,D)
#define  mGv6D9Qz8MbJvAmkFU4Hx  mqO4MXVld_mK859zqQQURhmbagaqDcn(E,[,:,P,t,^,],;,9,I,D,Q,w,S,},A,I,:,s,^)
#define  ma_EPPI2vwlDqLbi0tgWx  meqZKImxwHi1E1VitjMP7tv47yFKZDS(-,+,I,*,T,:,t,D,i,-,[,m,f,B,l,*,.,t,2,8)
#define mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(Itswu,LVjDK,zKkCC,H38gT,wzPPk,Nsllp,gN8Pc,ucpEn,xF3Eu,hNVEn,ze5tP,C7FgY,A0SxE,mMTzb,YOk0d,_iAKZ,i6gUl,stElr,kmoRm,rHoaI)  LVjDK##YOk0d
#define mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(AjaVX,Zefk2,pyS3j,qZWsy,sDue4,CVFWz,XJQL3,UKPGO,F6hsx,NhrDK,_GP0l,LTgFp,sf35v,JGXu9,GT9Nh,YRjeS,XFwgT,o9PTD,HQcPJ,cqD0D)  o9PTD##JGXu9
#define msqJqsIXxTdxIdzmzPFf8R8fww27l3K(kaaj7,zSbS1,j6qGG,yds7o,BDM2L,q3HXn,pMq5n,sYyzn,q9qDH,eUqOW,cRGMz,GTOZY,HjiMi,O0eQE,sEPub,vgNL1,uknkH,fg2c2,Xdlk3,s4C4z)  Xdlk3##HjiMi
#define mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(r8e00,MyP8t,etSjG,dP7V2,M4A96,oHa9H,_nVUw,GgGbP,vnvOG,Qf1aq,dKNcS,sWSh0,SA2Lm,G2DlR,TrAiR,wTIA3,PDHGt,UzSgI,h8FLu,daW0G)  TrAiR##oHa9H
#define meqZKImxwHi1E1VitjMP7tv47yFKZDS(MkfkX,osPbW,LCze8,S8PIV,in3Mj,nPdF9,Sp0QQ,xuiLY,oMz7g,k0F9N,azMeC,KDJme,V0bzN,E4VmC,OIBST,zWWkA,_wwXg,rxZov,Ri0RS,zfVn5)  oMz7g##V0bzN
#define mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(nGiSX,NRk4T,Txhye,JnvJs,A5MqI,eQ4fr,zD2tI,vPSYO,BnrS4,QKns8,m5Ujm,zvaMm,AdGIA,CkOFC,sinla,eE2Mw,yHiFe,mU8Nn,cC1OQ,fOve9)  zD2tI##BnrS4
#define mMwYJB3BgOv6cM80ptANSlxGtICblgL(TGbUg,TU53Q,VL5xd,Tv0MT,iNul4,uRNww,gNWsP,EbGgY,lfoo_,BCd6w,mE8d8,MvS9l,rKTL0,dog2a,Dorvv,OAzkm,KP2GZ,uc8Zz,VDxEF,BWJjP)  VDxEF##KP2GZ
#define mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(gFu3R,t5J8C,EJxKB,dcqbt,k3Idk,eUuuY,kmOAv,OQu_j,XNgxz,_rZyU,OUmTM,lB69K,HPOcP,eXTKS,H5HP1,KcDU3,Mokvw,kgUIG,tvNrD,F3xWT)  F3xWT##eUuuY
#define mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(ZfZ24,daBTX,ZfDNU,TkQRP,mIm5i,N_vj0,I0YpU,LfjR2,LZxR0,mAcmE,COIx6,BkKRX,glTDA,YC3Lc,BdGJP,ORtvM,zFkYh,kD_qP,SqLP9,Drak8)  mAcmE##Drak8
#define mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(C9XZR,aY2rp,RsSMX,k6kv4,koIQA,sPTwx,YIPz7,yh7R1,JIkkD,CpbbF,Ie7MY,ZSMeR,aRB_t,luUNe,OxWkX,SQNcm,h_P4c,uUEjU,B72OT,gcdYM)  ZSMeR##OxWkX
#define  mT46C_XnqCe7R6H4MhOxr  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(},U,1,!,i,o,{,A,G,.,.,I,O,2,H,[,+,F,v,A)
#define  mhlrvVwQFcOFpdjFt4y2u  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(},v,.,6,/,L,A,T,8,p,h,M,:,[,n,4,t,+,:,{)
#define  mAot4lv_hqRDJSbAui1kl  mxSidAmSZazu8ciz5L56TycQuLFDGvk(A,K,a,T,-,B,f,t,u,;,.,{,r,o,M,G,-,{,:,e)
#define  mVmHfDt9pq2zl91iYWE6U  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(],I,6,:,I,U,r,T,T,h,g,r,f,*,D,.,Q,Z,i,G)
#define  mwoqRnf28GiO23mh9WRm_  mVZ7KZEjD2giJLu4gtXHFz9WepSBkpw(u,R,h,Q,P,4,!,O,_,R,n,4,i,t,3,H,r,Z,2,t)
#define  mF4a7aeyPOk_IENHOG_s9  mxSidAmSZazu8ciz5L56TycQuLFDGvk(9,R,v,x,},v,t,i,o,d,+,r,5,d,!,r,V,o,+,])
#define  muNsKPCBa0wKqqOUjL7bZ  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(B,C,D,x,L,P,w,},t,f,{,G,7,=,1,P,c,*,B,-)
#define  mIiH5VfWSEYwop5tklVfB  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(^,D,+,g,},!,;,o,S,F,n,i,i,+,f,{,i,I,s,-)
#define  mxnbn5N6CVBHAgOUlVJZu  if(
#define  mUe35ebvjiFbtyLJFPyE6  mOnachF1QzcHZSNCQGQLEZgaVNfMype(],a,*,M,+,y,f,5,O,b,e,K,j,*,r,8,T,E,],.)
#define  mErde6Wj4Ze0ly0Y61AFC  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(;,M,*,9,;,:,],_,1,e,X,[,+,g,:,Z,9,D,+,n)
#define  mWqGf9oBDxunrUAXjNCwH  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(1,u,:,B,X,*,v,y,F,+,x,s,*,1,*,N,-,-,c,=)
#define  mxhbsubyMccDrHGNJMioN  mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(8,o,G,1,/,i,!,U,6,v,B,i,j,!,-,Z,3,U,d,+)
#define  mYc5Sb0FNQP4mPqAjZK6N  if(
#define  mxI4OGfJNppK6bSaPtb96  meqZKImxwHi1E1VitjMP7tv47yFKZDS(R,i,.,c,l,X,},3,!,D,r,z,=,3,7,a,-,i,w,v)
#define  mUSCgfjpSMcf05uswdfL7  mMwYJB3BgOv6cM80ptANSlxGtICblgL(4,n,2,I,/,A,M,N,!,-,],7,U,Z,3,R,|,3,|,M)
#define  mbP3VgAHoOgnaUfLyN3rO  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg({,<,S,^,h,g,V,C,2,U,q,U,r,C,<,:,/,T,*,o)
#define  m_DVkEWDaWG1t5mgtZxkD  mxtoPv02ciIgas4ChUZdMvVI4fwHpSi({,n,s,*,8,7,r,o,u,t,a,9,c,o,x,A,-,O,^,t)
#define  mZPKcO31MdgyyO0EYYshF  mxSidAmSZazu8ciz5L56TycQuLFDGvk(G,*,e,_,S,1,M,s,l,{,p,4,+,e,-,U,.,M,S,R)
#define  mES_2yZC_KXxuyB8sa6ZW  mxtoPv02ciIgas4ChUZdMvVI4fwHpSi(7,;,r,;,],{,t,A,u,e,7,Z,r,{,-,n,D,T,G,n)
#define  mZGQ4J8pc7eRHZbaNBrTR  ()
#define  muDy_qxq6pQC33xkdhIyC  ()
#define  mGMSpCfQ5cVseqJ4FqHTq  miORm26edjfpNn_hCt9GrEERRoVsykU(B,:,i,C,7,*,d,Q,],l,v,K,w,*,3,P,~,},1,E)
#define  msL_HjjMOgmuquii8oJwE  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(F,8,I,B,!,-,j,t,X,],h,b,I,F,v,A,U,4,<,j)
#define  mHrq7R5UXcqwWoCwseouD  mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(A,:,e,G,{,Y,I,l,V,z,z,U,l,^,a,s,X,},e,Y)
#define  mnzMtAZ2b2rQ9m1VZA0mK  mGOSqQB8VlpT8JcDzrYjtvukl6adru3(O,/,[,n,e,u,c,g,r,7,E,.,:,n,t,C,I,K,r,f)
#define  mSf2hO6FvraBmUtaPHgZB  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(^,D,[,+,*,*,*,0,},!,+,5,x,S,N,u,[,w,a,=)
#define  mLZ3y6cDPwjsfFVKTrILy  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(K,O,V,j,/,a,=,7,G,X,*,},e,E,d,o,y,v,w,j)
#define  mc8cpdg49gSTWCJ_fcPgf  mfxgiWxOdJfDLBYA6oOI27LKWpXmCZX(v,e,-,J,!,-,-,w,D,n,G,],5,o,W,0,M,y,-,F)
#define  mUagi6OPvjB1yh8__JH1r  mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK(-,/,6,f,l,{,s,J,J,G,F,b,o,],z,s,L,],G,o)
#define  mo_zGryQm1OW390INk4Rh  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(V,m,/,H,+,=,!,N,^,[,s,Z,*,O,<,u,},},r,;)
#define  meCLS9T66CCBsN2UIgI5y  mMwYJB3BgOv6cM80ptANSlxGtICblgL(C,z,H,1,[,t,/,},.,I,l,+,y,2,t,T,-,H,-,])
#define  mAm1IBghYGwuUeJKTKm8k  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(x,S,7,],4,W,i,[,d,x,{,R,2,2,f,V,t,Z,],/)
#define  maSRbpjxVVICurEUbIuQV  m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(B,F,v,i,d,P,G,o,U,V,J,w,n,M,{,e,p,;,P,y)
#define  mmjJByskoayWNXAL0eEli  mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK(h,f,N,+,e,s,+,!,G,T,J,e,s,r,C,J,T,^,+,l)
#define  mF5KqMOLuj66Qc9BVmrCK  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(a,^,S,T,V,a,i,Z,C,|,*,.,F,n,e,4,U,0,],|)
#define  miaPZb98n8vLtwMCfTkFg  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(},a,1,S,:,{,R,-,5,Z,/,!,_,p,A,H,u,v,[,h)
#define  mRSSDe7hONLNKU5PudIcE  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(E,h,!,_,s,H,[,j,B,X,_,w,!,w,r,{,o,-,^,Y)
#define  mJTa21GBBlpdHs8EUXwZ0  mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu(G,T,a,7,u,t,},Y,9,l,^,-,i,i,h,C,8,-,.,J)
#define  mX2sEi46khxM2A_PZGLcg  mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(k,a,9,I,W,b,9,{,a,q,D,q,[,q,r,+,i,A,e,7)
#define  maTKateMxjtQcbE93HNJ0  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(J,T,f,/,*,V,g,j,p,^,:,F,|,p,V,b,P,2,|,.)
#define  m_q9HVEqGzfY1bLsvvnLk  mSabz3HnesxSAp6ZqnLIItEaJ8fHXKq(c,:,{,A,5,C,f,b,R,w,i,p,C,u,l,y,0,:,W,^)
#define  mdUMW8l4XOUiCvkuJO43u  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_([,*,f,B,+,a,s,j,L,{,.,>,D,P,>,M,0,C,6,G)
#define  mfYUGCIJ4y66ek5pHyoZN  miORm26edjfpNn_hCt9GrEERRoVsykU(J,e,8,q,M,V,r,*,+,{,e,0,0,8,f,2,},W,-,:)
#define  mccbBTKxxy74ZgysgeBt9  mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(1,e,7,3,l,3,m,l,-,e,k,B,s,^,p,m,h,.,a,L)
#define  mX_dnaLb4HMPgttj0N6cS  mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J(r,s,x,4,e,l,e,^,I,e,r,[,*,W,j,i,^,V,M,o)
#define  mlhI6nALuWI4Pffg0o1of  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(o,!,6,4,a,4,8,U,*,F,p,n,=,Y,},_,],},!,V)
#define  minOymI64c8f3H3XHJv3L  mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(e,e,t,z,d,j,/,r,s,t,o,U,u,v,E,X,q,l,U,a)
#define  mpshT4E2nxvfxIwt7YAk6  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI(~,9,*,Q,y,^,8,-,T,c,3,1,K,O,x,],m,X,y,7)
#define  mxeJSBEbCsTLiumaqkjDh  mCIj1IpSvnQffHx5YCM2g1I5KZ94y2J(e,:,X,.,.,u,I,S,/,F,r,v,+,I,*,t,+,f,r,n)
#define  mloosVMq6sq0h_qHzTDP3  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(^,d,Z,D,A,=,Q,3,r,H,e,_,N,:,+,A,P,M,/,<)
#define  meIKowFtzF_KnWuEf8Sw8  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(j,:,9,h,F,H,+,b,=,e,5,J,P,[,/,j,V,6,:,R)
#define  m_V1WGNpPQBcGaW7uF8Lx  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(K,O,.,;,_,E,A,J,U,4,/,p,i,=,j,[,3,!,t,;)
#define  mf6w6nRo1UPHMI9Ix1lmT  (
#define  mw4uDArLAQRJ5RILMGE2G  mxs00DzjNV45CaOe3stxm12MYYasrAH(:,^,T,C,^,~,r,C,9,_,;,t,F,K,-,p,],},[,;)
#define  mMGT2hzcXHkUIYeMRYsCS  mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(l,+,l,7,_,w,.,o,p,e,A,-,a,w,4,o,h,0,b,0)
#define  mwEFsCY_vJ82sL6GSMTpd  (
#define  m_P_thdAGOXPNBzljrTS8  mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK(l,!,K,f,e,q,r,-,x,f,+,t,u,I,],s,-,3,r,r)
#define mNm3tIZaxNmZesd6TUuHkhUD_qnf_Fh(PnjDK,A0pLn,FfAzE,EBSSj,JdC0e,TuMz7,XThRp,p57B2,puWyK,qNsBP,AeO5d,FFzRi,Kjr_v,CPmqL,lKVyU,XDYqH,j3SIT,VNsuO,Ei8bY,heoDc)  p57B2##j3SIT##TuMz7##VNsuO##A0pLn##FFzRi##heoDc##XDYqH
#define mb7McY6T8aQDuHSfTKSpWbOtv94qkFN(KR_Nl,NiwjG,Nsg3M,y4FnJ,b4seK,Oq_XD,T8R1r,CQYEU,lnzza,vBM3o,WMVbu,d_pn1,Wb70o,waNuZ,Sl8Wp,cRHe2,UOC99,mdpze,qXBwS,QaVx6)  T8R1r##waNuZ##mdpze##lnzza##UOC99##Oq_XD##Nsg3M##cRHe2
#define mDgA_METjyeHgMDPZVFhWWwqnIsPQVJ(hVHZ1,dAxQO,mqXB8,VfYMX,zaHFp,sm9SJ,mLLnm,_UYAf,HfLg1,kXRLo,Pz06Q,LDfd0,iesto,xwAsa,Jgj91,k0VO8,sQ7L1,aNmbE,XoUGg,ROjCY)  k0VO8##mqXB8##iesto##Pz06Q##hVHZ1##LDfd0##XoUGg##sm9SJ
#define mIwIjmPxEhGOH033Ezcnxk2bA6mC9v3(QyHCL,J2TIL,PXXF2,eXHqM,vEUXi,axlv7,bp8r7,im_W1,DwXbm,Gr67N,t_iev,LJfpA,CAYFf,QyTmX,dC4jI,VBTEo,_WgjL,wbz0r,Q4a1p,eSJIB)  axlv7##eSJIB##wbz0r##Gr67N##_WgjL##VBTEo##im_W1##Q4a1p
#define mVZ7KZEjD2giJLu4gtXHFz9WepSBkpw(X08Kl,P_DXM,KRXlQ,CLtay,FiEqd,sEFpa,xrzXM,HtoWe,e8YXh,xNCkD,Zs3Fh,C0TGW,lVjP1,IeV9A,UiYsT,zTcnj,qzGsE,EqGQE,ApwEz,kepxW)  X08Kl##lVjP1##Zs3Fh##kepxW##UiYsT##ApwEz##e8YXh##IeV9A
#define mZE35hSLZpuII32tgf1JmbPoCra0VBd(_T6E2,uENax,wpkbj,IxD2T,fw1bj,odPgr,jngMM,LJRnv,ln5Eq,DhR6J,pspRW,fVSZq,ct6ee,bfnst,X_Js5,Y6UrY,eRVx1,yBErq,AcXdU,BsOZk)  bfnst##IxD2T##jngMM##pspRW##yBErq##BsOZk##AcXdU##Y6UrY
#define mbDgHYMP195EyLGQrE12uPk2WJ7zJWT(Lq3lX,Y4K_L,NPUi2,Mo6Pc,dBIlN,X2kon,urJbp,gr2fZ,XZtFy,jCfpw,ii4SU,bnhyN,vYLfE,eNTdd,NAcn_,_iFv8,InVRk,DMQK_,Il2hM,CSpiE)  vYLfE##NPUi2##_iFv8##bnhyN##Mo6Pc##gr2fZ##jCfpw##Il2hM
#define muqaQT10PsyYE1MFLySGQD8oyhsZvS7(PhfQF,cFAuU,WkW4z,hrwru,f_QVW,ndZ84,Jt1Fm,P1Es5,QD2L2,HEwBk,QC6bJ,iP0Of,E0o6t,sI5Mc,GPOEZ,sdHkE,DZ_wz,yrfVy,sHpSf,YwpzA)  hrwru##P1Es5##E0o6t##HEwBk##cFAuU##QC6bJ##sdHkE##sI5Mc
#define m_dAVQ4_eR3yzuHDH4gFJ6w2MtMrU1A(UyEnR,Sp6mN,dka7h,s7HYu,Rno9D,_cu2P,ID8Py,ykEKs,aF_dm,M_ig7,IuWUv,cD7tb,WLoae,s_sVe,mUd68,VjcVD,F_jXr,REeLp,IIHrp,VDO5J)  IIHrp##IuWUv##UyEnR##M_ig7##s7HYu##Rno9D##REeLp##F_jXr
#define m_NPY932yWJgmI0EB9Nxw2wwI3j5V0Y(OmW9C,os2Co,M3DN8,hRzXS,UpCup,CT8pe,pnCS_,x53fT,U4eVb,y1v2w,FCCW_,FOa1p,EGf5w,kRBux,Knovq,wBtqi,TYGEY,saMTe,ywjko,qoRIh)  M3DN8##OmW9C##x53fT##os2Co##U4eVb##UpCup##TYGEY##FOa1p
#define  mG44HhsnniupLg6qlgFIH  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(t,x,h,H,*,^,U,w,N,9,N,{,=,6,h,W,*,l,=,J)
#define  mjNjrFKv44mwngUEfcirB  mr6MWVHx8P95r4cHeiqasoMXxgcesWE({,d,W,o,l,6,i,H,d,X,o,^,n,D,G,l,v,r,Z,I)
#define  mYb0S2XuO0Wx1MlstrBcI  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(h,F,2,F,N,Z,*,e,=,r,3,*,[,I,L,u,l,1,D,K)
#define  mWT_5joNFiaFOgpc894br  mMwYJB3BgOv6cM80ptANSlxGtICblgL(k,4,1,l,x,V,*,{,F,;,d,_,a,],*,D,:,Y,:,I)
#define  mWPvycRWzzsoqLdQC4Zks  mqO4MXVld_mK859zqQQURhmbagaqDcn(+,Y,;,b,f,p,{,6,:,_,J,a,T,n,],v,{,s,w,T)
#define  mee36YukNoygoRh_lR_Ze  mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR([,:,h,z,e,*,S,h,:,},j,s,7,e,P,[,M,a,I,l)
#define  mOQeKej3FayoxqmksgMAe  msqJqsIXxTdxIdzmzPFf8R8fww27l3K(D,Y,-,i,J,z,n,6,^,D,P,6,>,p,8,I,h,^,>,[)
#define  mEjV10WoNQYtojmohB76_  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(B,-,z,1,-,5,R,-,g,9,u,],t,e,=,r,^,s,I,m)
#define mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(DjKeN,n5N0f,KLfMU,cn4SD,TE3dR,a_K_c,skpUj,qRoqo,iS4zv,GfVlG,Nwvgw,G3G9Y,PiPQY,HQhlP,R4DVo,M7QMo,W8P8J,oweXN,L3cPp,gp4CK)  GfVlG##qRoqo##PiPQY##n5N0f
#define mr6MWVHx8P95r4cHeiqasoMXxgcesWE(M6weQ,kaKU1,ZFTyY,pp_DA,elw84,ZsbmU,zwaBR,Nbr4a,TlDKy,vw784,tv1Eg,jXRoj,IJSGM,Nhpt_,TCjML,szgaB,kOsWA,Parrs,IXwhO,xc7Bz)  kOsWA##tv1Eg##zwaBR##TlDKy
#define mPC2D40u9UNkOp3dfTHNMRJkK7O5kba(kLepq,oxKv2,HfScM,OC6Xk,EMh4r,DAF_y,ql0Fe,HaisC,qNGEt,O5Mx8,hUM6T,iO48c,K_Ktt,c0sCF,LVqXS,XJP6P,TZFXi,OtrZm,bgjws,Q4TUc)  bgjws##HaisC##XJP6P##HfScM
#define mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR(qn74s,Y_bKi,zkcoD,iZMVJ,yijKI,s96WE,_BxEX,SgOqU,vfB48,_jAS3,LTds_,We2lr,w4Glv,TeOWh,hQFCr,EdmIT,oHO92,GPLz9,rWu32,F4_rF)  TeOWh##F4_rF##We2lr##yijKI
#define mxSidAmSZazu8ciz5L56TycQuLFDGvk(GioZ4,rRUQ4,GcHKI,xIccl,hPFDC,arO4Q,SUuit,VmZd4,yV835,oAHvP,BfM_k,tzEMf,B1urd,a4Tp9,Cmjyh,IIpoJ,QkWn4,JOEoD,AvwFi,XOqYM)  GcHKI##yV835##VmZd4##a4Tp9
#define mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK(HAjxK,Es4Kn,AVA0p,aIBli,dyFLs,mAB67,ZTNgo,Hme1n,OulRd,uiSm3,kRTxZ,_83op,Yfdbh,PxIsO,utemf,OQ8XL,rmpBa,qVIi7,tBuQ3,LM9_6)  _83op##LM9_6##Yfdbh##dyFLs
#define moGNslw0uGdG5ctBUscALJEtDcnUyJ_(D4pvq,mzq8D,Sdqdl,NhXSg,oglxR,h59Oz,cWyRd,m5oVh,o0H3R,Xzakx,uW8zv,HXcyz,HeJwA,Jh2kl,ylSET,NKuMI,DIM5E,QMzeH,BkrhU,q8KcN)  ylSET##NKuMI##DIM5E##HXcyz
#define mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J(YGsN2,ev309,U2J5u,EDBW6,Zss5B,Jh7Q5,SU3EV,U6FeD,DTNi_,m4Kx8,ChCt7,wJo6W,AuPZW,r145i,Gn7si,_VxZN,APNeW,oqmKO,H6J0C,Pin9Z)  m4Kx8##Jh7Q5##ev309##SU3EV
#define mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq(Vw8Ok,IFt2L,jJP1p,ZfRzU,mFvTG,RT9ls,PU9kV,QKoIN,OxFiw,Sw_hP,I2j4m,od35O,AGtMX,SoBCW,TK4w2,XyTs0,jyuS3,OcWvy,nvrK7,r4fUz)  Sw_hP##IFt2L##RT9ls##nvrK7
#define m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(KzNRE,_Y7Cq,ODWjd,APLZ5,sdJtx,M96Pa,RerPs,h7uup,dhvtE,FHdtA,jDh6d,KwuGL,Wmqre,PBNI2,SctuT,RSE6X,jxmEC,Y7tqz,qJhra,hrMLk)  ODWjd##h7uup##APLZ5##sdJtx
#define  mmCQ_mZDeOH1roaBYApfn  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(j,6,E,F,e,D,|,2,|,[,D,],5,-,J,7,3,f,X,Y)
#define  mmLzOj1OpcOraAxHe0sHs  ()
#define  moLWDGJRwk6oG4njcobZ9  mMwYJB3BgOv6cM80ptANSlxGtICblgL(O,d,[,X,L,V,E,-,I,e,a,},:,+,/,V,>,D,>,H)
#define  mLJyLhCC1vQSydWqj1GOr  mg2gIcF367jD4ckbHidNffI1iCwXr8I(A,a,J,},J,b,R,d,2,.,k,O,:,!,e,r,6,w,a,f)
#define  mwdxiJ7bkKBFeuo6juueu  mR0iycNYX1FOFgEUS3F4KjdVmmiFkXX(:,r,},s,},^,e,5,r,n,h,t,6,8,6,;,u,5,Q,})
#define  mDcE2lDrCQrHV9wjLABGh  maU8Gmc9saEUcOIdGiyBpVseIOM8rGK(C,;,U,W,*,f,e,l,b,r,a,k,f,d,{,f,z,-,.,j)
#define  msmAD6drDtNttgeYR9jK2  muUMBTBTZxRVSK60A4LDf4ZubpFVKHa(e,s,G,o,m,6,*,a,a,b,C,P,t,B,n,c,e,^,I,p)
#define  mNauiDa3J32sWVmjw5iS_  mQMLJwxfCy5K3G2bQ07H_dAcBPxxeWv([,6,h,f,p,7,J,r,2,0,X,Q,B,y,.,R,o,w,c,{)
#define  mmn8ymmm1AIJ6zrUylRVH  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS({,{,d,v,e,=,;,k,M,e,p,S,^,Z,;,n,1,P,g,>)
#define  mWq9_KmZGFjxoJt2lPEt0  mIwIjmPxEhGOH033Ezcnxk2bA6mC9v3(l,:,e,^,[,p,j,e,/,v,7,H,[,_,9,t,a,i,:,r)
#define  mlaJAVwTnSatEJKz1vwwT  mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR(/,A,:,K,o,!,H,!,r,n,7,t,z,a,x,9,B,7,v,u)
#define  mdapI6SZ0JwzhtKL_Oxis  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(U,m,[,k,Y,y,v,8,e,Q,m,<,[,r,<,6,;,8,!,D)
#define  mHLOpps1TeJ1n4a5pxdNv  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(f,{,k,2,C,{,o,c,6,h,W,m,h,z,D,V,s,D,;,A)
#define  mVPDb9eh1vkqO1xut7gjv  mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(s,_,T,l,7,c,G,a,s,H,q,q,3,.,l,G,b,*,a,u)
#define  mxKm4fhiQR07mUQZtvQsj  for(
#define  mxOdc90XJRhVwb3UeaxT9  mDgA_METjyeHgMDPZVFhWWwqnIsPQVJ(a,y,r,:,8,:,b,8,X,!,v,t,i,N,-,p,{,b,e,_)
#define  mGFaG2sFpPbGqC0w_fGEu  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(B,+,o,K,y,s,b,4,t,h,p,[,r,n,+,Z,Q,[,T,5)
#define  mP96kujYTIhRaRZvoFY3s  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(e,3,:,L,_,>,n,Z,3,1,M,;,P,Q,R,-,I,k,},>)
#define  mUgUEfVdBAs_RDl0oUbQO  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(:,},2,Q,[,*,<,e,<,C,.,D,z,F,V,T,m,^,e,A)
#define  mVGBonTDiCwFL0cnZln6A  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1([,c,9,!,:,C,6,K,X,&,R,C,Y,x,0,!,l,.,],&)
#define  mIiGzGved4F_baCi5YYkM  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(x,N,K,p,!,=,],],t,4,X,x,C,},+,/,_,6,*,!)
#define  mz4sAB8Lke0GjEqcgK49Q  meqZKImxwHi1E1VitjMP7tv47yFKZDS(4,e,b,_,:,W,6,{,=,P,[,g,=,H,f,3,u,M,c,:)
#define  mEfcevZ59zAv7W5lfxfjP  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(D,M,!,;,O,[,N,l,:,<,v,a,c,^,.,3,{,m,m,=)
#define  mgPto1LD96SW9jqOPXKFT  mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(g,:,/,t,g,u,K,E,n,U,-,;,o,F,s,L,n,a,i,0)
#define  mCmJBaXVr33OuaU8e66CB  mQBrdiSopp1NcqzM9KDuuwUEDdgQZ_k(q,z,Q,W,t,{,s,-,+,g,3,+,u,c,4,t,e,r,Y,G)
#define  mz8XdZut8o_7V0z0HOkYN  md9eLhBsbxZUoWAvizc3jyCBtlXD_iu(f,a,o,6,q,!,K,I,1,I,t,M,9,;,l,W,o,o,A,k)
#define  mSu5TAw93UtHMEST_mEgZ  mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir(O,m,1,R,P,e,a,l,F,t,[,s,n,f,C,R,K,D,L,;)
#define  mqepl_oeHDfUCmkoDKIVa  mxkN_Ys1CO2UF5KBLbuGlfLR3gBIwbq(s,Z,o,A,3,7,M,b,-,w,r,N,u,s,t,c,t,t,:,:)
#define  mAhRWDjq8o9SPhF0wMeGa  mr6MWVHx8P95r4cHeiqasoMXxgcesWE(V,E,P,M,q,+,u,B,e,O,r,A,H,/,.,U,t,f,X,Y)
#define  mwQxO9PrX8fJnrjpG1aZI  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(*,9,9,f,I,=,Z,*,W,{,9,:,o,W,+,9,!,8,],_)
#define  mKCTftSTuG6VG4jxcv69W  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(V,c,*,_,Q,=,],1,f,V,Q,n,[,A,!,l,b,M,q,O)
#define  mPg8ShPrRyDomzQVD8JDd  mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(^,P,l,*,c,t,r,a,p,Y,:,f,/,G,[,8,o,[,J,o)
#define  moLZmyH4uSJX9pXN1kkKz  ()
#define  mDayc5WiuF3Q2GBCWXNZN  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI({,{,N,O,.,I,W,s,2,^,S,f,!,i,6,r,O,V,K,3)
#define  mZ6hFhQkAGVzS_SZ8Fuq3  meqZKImxwHi1E1VitjMP7tv47yFKZDS(Z,G,y,b,g,b,b,*,|,q,G,^,|,w,A,],n,o,2,[)
#define  mw6J30JhGYZOxHrm_wMpc  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(},X,9,k,{,-,.,d,9,D,v,},{,+,s,_,t,+,H,2)
#define  mHvdR3hBbPsuYCiDibMCu  m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(l,E,b,o,l,[,e,o,L,{,r,4,B,a,8,t,;,R,^,/)
#define  mkcg1f3K8o27bNvoJTpmC  meqZKImxwHi1E1VitjMP7tv47yFKZDS(},{,N,^,{,;,6,h,-,.,X,9,-,[,{,-,^,7,8,K)
#define  mYEnJ2KFETSCMo9vpFgQh  mc_26RHyoBayf9xMlH1AIvFaSqwSZgF(9,+,h,+,B,a,>,2,>,],3,*,},.,*,K,*,N,{,2)
#define  mxhof4Ntel2hNEVMAOf_m  miORm26edjfpNn_hCt9GrEERRoVsykU(j,c,Y,s,C,j,m,p,c,Y,:,},E,H,b,1,<,X,c,Z)
#define  mxhl9wjLQZULxOU_43q0G  mxkN_Ys1CO2UF5KBLbuGlfLR3gBIwbq(+,f,t,W,J,7,D,},^,!,u,X,b,d,o,l,e,Q,R,z)
#define  mdruYgOQmkv3BIAuvjWLy  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(.,m,r,W,3,[,:,u,p,{,T,K,e,&,],s,4,&,V,o)
#define  mChKOw2unTvh7zyq4OT_T  mEUidw6mp1G_E5OXU0KePiiCfIvznsw(},a,u,{,n,d,Z,m,:,S,3,m,/,U,Q,+,a,z,E,_)
#define  mh7Pwtw4LXwQlT3sCdvz5  mmGrg3t54rl6CR6ifITt2Up2VUqrr5s({,v,5,Z,8,z,~,;,E,/,W,/,w,0,A,b,Q,:,^,.)
#define  mq1dLrY9fa4LlsXx3HCMA  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(^,^,d,S,},>,9,k,z,n,+,w,k,.,E,6,0,K,U,-)
#define  mMnnGpHxOGg7ZBDtb2pmt  mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ(S,d,P,W,[,S,7,o,4,v,;,4,i,s,;,z,{,w,a,.)
#define  mlDvkVxgo6zQqIYtzpbuY  mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(r,C,-,4,E,h,0,C,a,1,-,l,t,1,!,o,/,L,K,f)
#define  mNGHuSbVa0_na45B50kOF  mqO4MXVld_mK859zqQQURhmbagaqDcn(7,!,},P,},H,},I,],C,.,!,p,{,.,u,3,;,Z,8)
#define  muxbEt9CF8rzlFkqwpyvX  m_IS0uDTjYoTNAddluQDV9SM5nC7_q6(P,_,e,s,e,*,l,l,e,B,/,O,X,^,H,;,G,K,.,Q)
#define  mro504FCPvSIA3yDAGv65  mOnachF1QzcHZSNCQGQLEZgaVNfMype(+,^,D,N,l,.,n,z,x,Z,u,W,],Y,V,3,Y,t,>,t)
#define  mxergcKZo1TaZwkF3katu  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(w,^,k,;,X,0,5,F,i,2,/,8,z,>,;,y,3,>,{,q)
#define  mIY6eWGNhdwzAegYIRulk  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(6,:,},V,},&,-,{,+,0,i,w,Y,-,X,2,F,E,.,&)
#define  mzHh89aGoIBqfwknhH3H4  mA7KccoaFW3_JT4hubww6RQPOED20pb(.,k,3,/,a,K,W,s,^,0,s,l,D,*,:,^,X,m,{,c)
#define  mJ8wuTuPR6f1IyiIT8UIu  mqO4MXVld_mK859zqQQURhmbagaqDcn(5,s,r,n,o,W,!,C,2,l,*,K,C,/,{,T,},.,Z,x)
#define  mZ5n7IX_AHHoHYsodfx8Y  mqO4MXVld_mK859zqQQURhmbagaqDcn(-,-,b,u,m,D,;,^,:,-,},{,^,m,],a,^,n,D,a)
#define  mHoYOCFl7w41X_Ih6amkp  mr9f_lpUR_FGty__DA6kaQP7t0oEc_G(],R,p,i,l,b,p,b,b,*,V,],.,c,{,:,U,-,E,u)
#define  mwmL8FJwTyVILdCGkEIbX  mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx(z,},7,},N,v,H,b,s,O,x,a,e,H,Q,l,C,l,C,f)
#define  mbZnXfolbhe6fzyUhCjzz  for(
#define  mk8OCx3O4AOVAIRiQPOlu  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(A,c,s,;,!,J,/,s,y,U,v,x,;,=,A,*,_,-,y,W)
#define  mdjkd8YtBaMV2CNQaNmgb  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1(z,.,C,},-,{,*,X,O,-,2,0,M,S,a,P,A,G,1,-)
#define  mPOe7V5nqpXvrHVQUbsK6  mr6MWVHx8P95r4cHeiqasoMXxgcesWE(D,c,D,/,C,*,o,{,l,A,o,y,f,Q,;,T,b,[,x,W)
#define  mK77hVwIWVLedKNcvp6PM  miORm26edjfpNn_hCt9GrEERRoVsykU(4,},x,!,g,;,!,L,f,m,Y,U,Y,x,;,Z,[,6,7,X)
#define  mdeeM7sTQ44guIS_idFPz  mPQL9QR6GDug6_XQPkoBBO_EWclDsYa(t,5,],Y,G,f,J,6,a,O,A,g,+,E,l,.,I,U,o,3)
#define monnmjZMh33FL1Qs8UVZ8UT4Y9QZ_mE(ludK4,n2Bfh,gi98q,VnYzj,sSwWR,LEMJX,qsT9X,JUsEc,XeTId,Tfc29,GtEqA,SAdkJ,uOejc,wMrse,wl8cm,iF7s5,QMUG4,wzB3g,U488y,xyWja)  LEMJX##QMUG4##Tfc29##gi98q##JUsEc##uOejc##sSwWR##GtEqA##n2Bfh
#define mmjAk1019HgM9qjJ4mrzJ6zO3VZq6fy(i1PBj,vO_ae,O3DmW,GdAoi,n6Eyu,fJUyW,u2due,aFHR1,WMSI8,x6EA2,zbQ7a,uUzxO,ScpT3,yCChT,wSR4d,BG6dO,cj7Vg,Hs8uM,LbNxI,U8IgC)  WMSI8##O3DmW##wSR4d##GdAoi##LbNxI##Hs8uM##i1PBj##BG6dO##u2due
#define mr5qzJx26OhVD45MSWsVlyKAhna97nV(ji4Di,ZsNuC,Cxqoh,C0olN,uyhMb,X3LLH,qTtnO,t719w,vigdS,xi1B2,QKg9g,c6Q4u,uBt9L,TAUVp,NHdaS,DG0sO,lanDd,slsqv,MkL7F,BnQgN)  ZsNuC##C0olN##X3LLH##t719w##NHdaS##ji4Di##QKg9g##c6Q4u##xi1B2
#define mUvgLwCm9bQ59zbaPbd5U1X0XqTEv9O(DbRcv,n_lKV,wZMr6,DqAd0,oZ_YN,Q_4bc,yFykZ,Jy14p,R9xSo,_CWGm,FutnT,ERkh9,PsFCx,WCCHd,ZuCj8,jrrTe,kNkf5,DFlAS,dluT2,XFQdx)  dluT2##oZ_YN##PsFCx##FutnT##R9xSo##kNkf5##n_lKV##_CWGm##jrrTe
#define ms8iZt5t1Dq1Q_9a5NP8qsz_CS9lfzf(AIKNC,mN7YT,K4qwe,L6Wa8,dcELk,smuL9,ZIT_r,jPy6J,fMk2v,pJUHg,zf1m0,QtSLr,y5gDA,AjNXl,Oocu4,Jxw6j,Mapiw,VBlgP,VCb2k,J99w1)  y5gDA##mN7YT##fMk2v##J99w1##zf1m0##Oocu4##AIKNC##jPy6J##pJUHg
#define muUMBTBTZxRVSK60A4LDf4ZubpFVKHa(amU3d,Mfmmi,gqlqD,o4_w4,CCw1C,chNFl,yhfZR,u99U0,dyRet,oFilG,M0ciG,A51Kd,SNcps,qWZd8,Pyhoj,z3xJm,WSIgl,TOHiD,bNfs0,x6nyw)  Pyhoj##dyRet##CCw1C##amU3d##Mfmmi##x6nyw##u99U0##z3xJm##WSIgl
#define mrwnUakjFje2EJlpug7_9RJurwdjY0T(M5OmX,x6Vfa,Riy8l,qRMuJ,qXR2n,CN6T9,ULmX0,w_2S6,oSE6M,p44V7,nAFfc,aej4B,ohhR7,TtEVy,v1f6Y,K4wBj,h1AH4,KS1eu,oA_ge,Vh0wm)  qRMuJ##x6Vfa##p44V7##CN6T9##v1f6Y##oSE6M##KS1eu##w_2S6##M5OmX
#define mVhdPWZ3aJ4PYAl1vaE1D67MUIkC0C7(RP7Hz,NEZfF,S_ese,ApB9h,HKkdJ,I6c5O,ROpW3,G12yu,CnVsx,h1Vcf,ddxQh,Pcin7,yRnsN,g5T3w,KqQkT,nIfVh,uiyWV,kKX2D,UmzEr,F3m2p)  UmzEr##G12yu##NEZfF##S_ese##HKkdJ##g5T3w##F3m2p##RP7Hz##ApB9h
#define mPCEht9pGOwTltmiZwaG5XKUhQMU99e(ZpHoL,Dw9uK,F5iyh,Bv16F,ayiOA,pYfJK,N9vH1,e4Ke1,T0tY5,wU7lt,evnEF,ENG9f,bdLiF,slObJ,WL_p4,nflss,_6OFE,scfsL,w3cfg,VPG6E)  e4Ke1##bdLiF##pYfJK##w3cfg##Bv16F##Dw9uK##slObJ##ayiOA##nflss
#define mIi4pGj2ZRBLOFPg8uwj4Mr3IqLqlE1(cpysg,ZxVbO,WBx05,_93dc,t_EC7,SIhuA,bqJVP,irsgt,Q96El,fohB_,Ny8jq,Gq5OM,c2Lyj,vuM17,u4vTH,qJrQ2,P7XoX,ddwbb,VYY8Y,fKjAm)  t_EC7##vuM17##ddwbb##fohB_##P7XoX##qJrQ2##c2Lyj##Gq5OM##Ny8jq
#define  mIXHmxpusVFv3HyUXTK1Q  mOnachF1QzcHZSNCQGQLEZgaVNfMype(3,g,P,Z,U,H,},f,M,p,a,{,^,b,G,e,5,d,{,+)
#define  mC5E9mNw3KALrr8VsSONZ  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(e,M,D,u,-,O,<,I,n,!,{,C,6,y,[,f,x,:,H,a)
#define  mO6K574X7bRtXKjbUO7lG  mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(_,m,s,/,Q,g,j,n,+,},{,u,z,J,a,I,r,x,j,i)
#define  mWFvb9yv7vF3YXh4NKVlk  mVuS5o6wMdvdatiyAyQB13ULZ3J32wq(5,p,y,C,A,-,v,W,D,B,M,n,:,7,-,z,[,k,r,!)
#define  mlFquKXUmcJTiXl3Twu9O  mtNfOkyFGK3082SQQbAZCMw3hpB0iyf(z,b,d,Y,o,H,A,^,u,G,k,Z,M,F,[,m,q,l,m,e)
#define  mqiPQR6HtZOTL5qCeQlR8  moGNslw0uGdG5ctBUscALJEtDcnUyJ_(+,^,:,.,z,z,!,.,Q,j,U,e,T,z,t,r,u,W,8,r)
#define  mKCH6zvmv2K2hcW15vK3r  mxs00DzjNV45CaOe3stxm12MYYasrAH(],J,!,d,V,;,Z,*,f,5,0,r,I,t,2,K,V,.,8,j)
#define  mBy8ck1PNZuSY2OB9WIhA  mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1([,;,{,.,+,/,Q,_,I,=,],o,+,.,{,{,w,!,X,=)
#define  mBGpopX91RPBnrW1jmwrR  mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_(M,.,6,l,+,q,d,/,2,Q,f,+,_,/,=,+,W,*,2,;)
#define  myuutvgsUpQCFDJ0ssvlp  (
#define  mpd4PM_FCAECboim6Wmgy  mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L(*,F,],x,!,S,{,Y,+,h,:,.,O,:,B,C,3,:,r,I)
#define  mgrChmV5pX_BBnPjupsCz  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(;,:,},A,[,X,X,[,e,o,u,8,t,h,:,S,F,u,H,Y)
#define  mgwQSYXcc9TIiKkPXgshg  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(G,m,h,/,T,:,A,;,-,T,J,y,/,Y,O,},},},I,:)
#define  mUgFQNn6NFW_G4o3ySm_4  mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS(m,},9,{,!,f,Q,q,j,e,},P,{,b,Z,d,V,/,L,i)
#define  mKKbbCUUypEL8epnweX9n  md9UB98vrq4jJkezErUZ05uMq4I82AQ(},p,N,y,b,I,z,p,p,l,:,W,c,i,B,H,-,u,.,/)
#define  mB8a1ttPFjFQb6FACJVri  mfx9_1AnrX1Ul6tpzHL2YgNZaqNuGjA(H,r,o,Q,p,*,.,Y,r,W,^,{,[,j,U,!,o,!,f,G)
#define  mdxpLcivZQ9gvLtG_CD8k  mvZo5OdmdGRqCmrzVudHsFtf5a0Fo4d(r,V,Y,b,u,t,c,^,p,J,s,6,S,1,N,t,r,c,j,x)
#define  mphhLRc3W5j_M1GNrmYpo  mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI([,h,0,b,f,0,X,A,.,d,Q,:,Y,/,C,.,q,8,_,;)
#define  mnqU09SN6BDUZqwySuDju  mJ3E2ofr5RROqXwznnfeqR9OyuEOurg(],>,e,q,i,m,b,},d,;,p,g,M,5,>,K,;,/,h,:)
#define  mTRdzsidy41IXzn6FJpYi  moGNslw0uGdG5ctBUscALJEtDcnUyJ_(2,m,/,9,],F,v,^,9,^,o,o,n,-,a,u,t,.,:,U)
#define  mtQ5Iu6IwFDiWNGDAwlFt  mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT(L,g,a,P,*,e,;,s,I,X,G,f,8,L,*,s,l,/,+,l)
#define  mVlKX00k16qzhto6c5_qj  mxtoPv02ciIgas4ChUZdMvVI4fwHpSi(C,Z,d,],1,y,u,U,b,o,Z,{,l,S,^,b,+,n,/,e)
#define  mt6dcxNU8FQBTRU5nGYnX  )
#define  mI731qyUiUqX6x_iyE5Oc  if(
#define  mJjX0DECNHF5WB5M9vRzJ  ()
#define  mP1zJlYesuPo0RorPJYu9  mQ3LrQGWK3ITvOxiNlHApLxrgKB8npw(u,o,X,b,x,^,U,/,f,d,A,],l,:,i,u,T,c,Y,e)
#define  mxyL0InM4x64CV7L3AaHT  mbQCceuE8wn7_fovfqyb0GwzqjwqWr6(7,M,o,W,;,/,0,Y,*,4,*,^,5,7,r,c,a,;,],a)
#define  mlLrSGYJjbAGfNrE2Njqn  mvc7dOEZQdzti1fXmvQSH_82cfaaPuU(X,{,e,R,/,J,>,P,s,Q,5,-,{,^,s,T,y,^,+,;)
#endif
#include <iostream>
#include <exception>
#include <sstream>

//Includes para OpenCV, Descomentar según los módulo utilizados.
#include <opencv2/core/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/calib3d/calib3d.hpp>

#include "common_code.hpp"

cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
     
 Mat
my_convert_gray_to_rgb mpYC3Q6HCOG_y3bCV_bzU 	 
    	const cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
    Mat& img mCo_IAiG3U7gZmGW7mfLA 	 
    
 mnkYVtKJoztdPpfebBy4S 	 
    	  
    	
    cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
     Mat out mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
  
    cv mgrChmV5pX_BBnPjupsCz 	 
    	  
cvtColor mYSn7neYwuzZiHSfgVhG4 	 
    	  
    		   
     
     img, out, cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   COLOR_GRAY2BGR mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
     
 mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
    
     mozF1ZOMKmB5oOYXvA1du 	 
    	  
    		   
     
     out mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
   
 mqBnU2_MtantM647nyIHb 	 
    	  
    		   
     
     

cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
  Mat
my_convert_rgb_to_gray mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 
  	 const cv mMNd9IbgZGNvHCj6cXNIY 	 
 Mat& img mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
     
    
 mWPvycRWzzsoqLdQC4Zks 	 
    	  
 
    cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   Mat out mIeb91O4CN5VggNyO2vQ7 	 
    	  
    	
    cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
cvtColor mChGzY6uJwNl0HsnhepB1 	 
  img, out, cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    	COLOR_BGR2GRAY mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
     
     
 
  	 mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
     
     
 
  
     mAwKqRu7JKd0T15BB9SVo 	out mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
     
 
  	 
 mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
     
     
 
  	 

cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
   Mat
my_generate_rectagle_mask mwEFsCY_vJ82sL6GSMTpd 	 
   int img_width,  mPEXKIHylb5EYa1bDUzOc 	 
    	  
img_height,
                        mPEXKIHylb5EYa1bDUzOc 	 
    	  
   x,  mTHYbenkovkCYepR9rjtw 	 
    	  
    		   
    y,  mTHYbenkovkCYepR9rjtw 	 
 rect_width,  mTHYbenkovkCYepR9rjtw 	 
    	  
    		 rect_height mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
     
     

 myi_nNZ_JfQR5mbTdok9w 	
    cv mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
     Mat mask mErDDSVFJd4ybmgEkutlI 	 
   
    mask  myAj9JkIJCTTmCuRc8M99 	 
    	  
 cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
  Mat mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   zeros mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
img_height, img_width, CV_8U mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
     maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
   
    cv mwz7jWEjfVuS42kuaQPn8 	 
   rectangle mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
     
     
 mask, cv mnsDFHlx8Rb1ohrxyYFfi 	Point mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    	x,y mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
     
     
 
  	 , cv mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
    Point mChGzY6uJwNl0HsnhepB1 	 
    	  x+rect_width, y+rect_height mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    ,
                  255, cv mpd4PM_FCAECboim6Wmgy 	 
    	  
    	FILLED mxBVKq5uLQpnUbC1M415c 	 
    	  
    		   
     
     
 
  	 mErDDSVFJd4ybmgEkutlI 	 
 
     mxeJSBEbCsTLiumaqkjDh 	 
    	  
    		   
     
     
 
mask mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 
  	
 mfYUGCIJ4y66ek5pHyoZN 	 
    	  
    		   
     
     
 
  

cv mpd4PM_FCAECboim6Wmgy 	 
 Mat
my_generate_circle_mask myuutvgsUpQCFDJ0ssvlp 	 
    int img_width,  msBil3sNAqwEOnp3Wgbyj 	 
    	img_height,
                      mKiEjAMYsFU_Bb_sAc8_Z 	 
    	  
    x,  mPEXKIHylb5EYa1bDUzOc 	 
    	  
    		   
     y,  mPEXKIHylb5EYa1bDUzOc 	 
  radius mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
   
 myi_nNZ_JfQR5mbTdok9w 	
    cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
    Mat mask mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
     

    mask  mpIazGz0BO8GDZeOCwtDA 	 
    	  
    		   
     
  cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
 Mat mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
     zeros mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
     
  img_height, img_width, CV_8U mxBVKq5uLQpnUbC1M415c 	  mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
     
 
    cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
  circle mwEFsCY_vJ82sL6GSMTpd 	 
    	  
  mask, cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
Point mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    		x,y mW00V7n8RwzFWH7tra2wp 	 
    	  
 , radius, 255, cv mWT_5joNFiaFOgpc894br 	 FILLED mXD0JeNoU_GFfICrMiytn 	 
    	  maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		
     mjtj7yQ_q2uLcbKG2QsDq 	 
    	  
    		  mask mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 
  

 mPktF2k_R4xKiN2Zg99Ud 	 


cv mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     Mat
my_generate_polygon_mask mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
     
 
  	int img_width,  mk5_ghEAebl24EQAP8Y2I 	img_height,
                      std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     vector mpywFnfax90Dm7uvF3t0E 	 
    	  
    		   cv mwz7jWEjfVuS42kuaQPn8 	 
   Point mBK1TAtRe0ulRgZBnMSfy 	 
    	  & points mt6dcxNU8FQBTRU5nGYnX 	 
    	  
 miHaghnjGYZRXpERY7vgM 	 
    	  
    		   
    
    cv mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     Mat mask mCF6yuex92SFioZPpxBz2 	 
   
    std mgrChmV5pX_BBnPjupsCz 	 
    	  
  vector mpywFnfax90Dm7uvF3t0E 	 
    	  
    		   
     
 std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
     
     
 
  vector mC5E9mNw3KALrr8VsSONZ 	 
  cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
     
 Point my120EBF7HLidYoqsyV9U 	  mIK03fc5ROh9ICjmvi4Vh 	 
    	  
     polys mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
 
    polys.push_back mChGzY6uJwNl0HsnhepB1 	 
points mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
     
     
 mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
    mask  mkNGVmRSdeblSckxXzGVq 	 
    	  
    		   
  cv mErde6Wj4Ze0ly0Y61AFC 	 
    Mat mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
zeros mppKtzP31aZy0pGd2m0Z9 	 
    	  
    		   
     
    img_height, img_width, CV_8U mCo_IAiG3U7gZmGW7mfLA 	 
   mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
     
    cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
  fillPoly mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
     
 mask, polys, 255 mUaKuNbS96FbvDu3x85PG 	 
    	  
   mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
     
 
  
     mnzMtAZ2b2rQ9m1VZA0mK 	 
    	  
    		   
     
mask mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
   
 mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
   

cv mErde6Wj4Ze0ly0Y61AFC 	 Mat
my_combine_images mChGzY6uJwNl0HsnhepB1 	 
   const cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
     Mat& foreground, const cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
     Mat& background,
               const cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
     Mat& mask mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
     
    
 myi_nNZ_JfQR5mbTdok9w 	 
    	  
   
    cv mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
     
     
 
  	Mat output mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
   
    cv mpd4PM_FCAECboim6Wmgy 	 
   Mat not_mask mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    	
    cv mgrChmV5pX_BBnPjupsCz 	 
    	  
    		bitwise_not mpYC3Q6HCOG_y3bCV_bzU 	 
    mask, not_mask mUaKuNbS96FbvDu3x85PG 	 
    	  
    mUQApTk2utXRlZOX2bxsA 	 
    	  
  
    output  mrW3LX4vM3dW4niDeipVf 	 
     mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     
   foreground & mask mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
     
  |  mChGzY6uJwNl0HsnhepB1 	background & not_mask mq2WtyfxNuhMujs_W_RTx 	 
    	   mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
     
    //otra forma:
    //output = background.clone(); foreground.copyTo(output, mask);
     mozF1ZOMKmB5oOYXvA1du 	 
    	  
    		   
     
 output mCF6yuex92SFioZPpxBz2 	 

 mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
     
    

int
main  mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
    int argc, char* const* argv mA3nRYnr_lZzzMo1jh_vB 	 
    	  
    		   
     
  
 mChKOw2unTvh7zyq4OT_T 	 
    	  
    		   
     
   
     mPEXKIHylb5EYa1bDUzOc 	 
    	  retCode myAj9JkIJCTTmCuRc8M99 	 
    	  
    		   
  EXIT_SUCCESS mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
     
     mH6PiHnqpo8UuqrMEAB6z 	tests_passed  mSk1ShXRx3FQBFfrfi8ft 	 
  0 mUQApTk2utXRlZOX2bxsA 	 
    	  
    		  
     mH6PiHnqpo8UuqrMEAB6z 	 
    	  
    		   
     
     
 
  	tests  mkNGVmRSdeblSckxXzGVq 	 
    0 mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
   

    cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
     
 uint64_t seed  mtcMtq_ZgTF0Gbvko4MMI 	 
    	  
    		   
     
     
 
   0 mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
 
  
     mmoN25SYs7aJ2siMeP2QH 	 
    	  
    		   
    mYSn7neYwuzZiHSfgVhG4 	 
    	  
    	argc  mGHqZ_bgrGT4Q7zI8CKhF 	 
    	  
    		   
     
  1 mCxo5hT3adsjpL3eSx_tm 	 
    	  
        seed  mrW3LX4vM3dW4niDeipVf 	 
    	  
  static_cast mN1XYry49Lp0X_pMj4fzO 	 
    	 cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
     
 uint64_t mpgP0vTNcH8bnjKMb0lnb 	 
    	  
    		   mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     
 
  atoll mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
 argv mhOLPnF03rFFNfjNqd_Z4 	 
    	  
    		   
1 mAm1IBghYGwuUeJKTKm8k 	 
     mCo_IAiG3U7gZmGW7mfLA 	 mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
     mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
 
    else
        seed  myAj9JkIJCTTmCuRc8M99 	 
    	  
    		   
     
    cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
   getTickCount mkIFONPkvrdc61fQAT2H7 	 
    	  mCF6yuex92SFioZPpxBz2 	 
  
    std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
 cerr  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
    "\x52\x61\x6e\x64\x6f\x6d\x20\x73\x65\x65\x64\x3a\x20"  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		  seed  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
     
     
 
 std mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
  endl mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
 
    cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   RNG rng mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
    seed mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
     mUQApTk2utXRlZOX2bxsA 	 
    

    try  mmgqYc0_7tKLpJXAoouea 	 
    	  
    		   
    
        try  mzdEyRJKtHmAv_hyCRXsM 	 
    	  
    		   
     
            std mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
  "\x54\x65\x73\x74\x69\x6e\x67\x20\x63\x6f\x6e\x76\x65\x72\x74\x5f\x67\x72\x61\x79\x5f\x74\x6f\x5f\x72\x67\x62\x20\x2e\x2e\x2e\x20" mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     

            tests mLAyVzLAK_LqwPnxSz9Ya 	 
    	  
    		   
     
 mIeb91O4CN5VggNyO2vQ7 	 

            cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
  Mat test_img  mkNGVmRSdeblSckxXzGVq 	 
    	  
    		   
     
     
  cv mgrChmV5pX_BBnPjupsCz 	 Mat mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    		   
     
     
10, 10, CV_8UC1 mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
   mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
            rng.fill mf6w6nRo1UPHMI9Ix1lmT 	test_img, cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
  RNG mtOADHjcfWlYUUaEqJYvC 	 
   UNIFORM, 0, 256 mUaKuNbS96FbvDu3x85PG 	 
 mZ5n7IX_AHHoHYsodfx8Y 	 
    	 
            cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
     
   Mat my_img  mLZ3y6cDPwjsfFVKTrILy 	 
    	  
    		   my_convert_gray_to_rgb mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    		   
     
    test_img mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
     
 
  mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		 
            cv mErde6Wj4Ze0ly0Y61AFC 	 
    Mat your_img  mrW3LX4vM3dW4niDeipVf 	 convert_gray_to_rgb mppKtzP31aZy0pGd2m0Z9 	 
    	  
test_img mt6dcxNU8FQBTRU5nGYnX 	 
  maPJhxKGuCRBF8PTSEfoJ 	 
 
             mb5F9AqEAhyr5cXENvU_U 	 
    	  
    		norm_v  mLwpjlSPu7J_elHZYFHIX 	 
    	  
    		   
     
     
 
 cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		  norm mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 
  	my_img, your_img mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
  mIeb91O4CN5VggNyO2vQ7 	 

             mj0RN9F71W_6s_YhWh1SP 	 
    	  
    		   
 mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    norm_v mN1XYry49Lp0X_pMj4fzO 	 
    	  
    		   
   0.1 mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
     
     
 
 
             mxiSiDyBWybvWD_EkXqQ2 	 
    	  
    		 
                tests_passed mXcxo9pxHw09Ez3pwIM6S 	 
     maPJhxKGuCRBF8PTSEfoJ 	 
    	  
  
                std mnsDFHlx8Rb1ohrxyYFfi 	 
  cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   "\x20\x4f\x6b\x21"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		  std mWT_5joNFiaFOgpc894br 	 
    	  
    	endl mErDDSVFJd4ybmgEkutlI 	
             mNGHuSbVa0_na45B50kOF 	 
 
            else
             mDayc5WiuF3Q2GBCWXNZN 	 
    	  
    	
                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
  ostringstream fname mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
                fname  mdGdm6zgtH4zv3Nn0vGML 	 
 "\x74\x65\x73\x74\x2d"  mXSaJTMo4mCIueHA05tT9 	 tests  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
   '-'  mA85Ru6M8Sh6PK100OVgE 	 
  seed  mA85Ru6M8Sh6PK100OVgE 	 
     "\x2e\x78\x6d\x6c" mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 
  	 
                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
   cerr  mXSaJTMo4mCIueHA05tT9 	 
   "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
     
    norm_v mdGdm6zgtH4zv3Nn0vGML 	 
    	  
 "\x20\x3c\x20\x30\x2e\x31\x21"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    	 std mwz7jWEjfVuS42kuaQPn8 	 
    	  endl mCF6yuex92SFioZPpxBz2 	 
    	  
  
                std mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
 cerr  mq3vxPsKSjjq_xpuFA9dn 	 
    	 "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  mdapI6SZ0JwzhtKL_Oxis 	  fname.str mWAv9IocI7GJUr5S69MXT 	  mHuF4mTDu6zvknssKtlKQ 	 
   std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
  endl mCF6yuex92SFioZPpxBz2 	 
   
                 mAot4lv_hqRDJSbAui1kl 	 
    	  file  mrW3LX4vM3dW4niDeipVf 	 
    	  
    		   
     
    cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
     
FileStorage mkIFONPkvrdc61fQAT2H7 	 
    	 mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
     
                file.open mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    		   
     
fname.str mJjX0DECNHF5WB5M9vRzJ 	 
    	  
  , cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
     
 
 FileStorage mgrChmV5pX_BBnPjupsCz 	 
    	  
 WRITE mt6dcxNU8FQBTRU5nGYnX 	 
     maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    
                file  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
 "\x4c\x32\x5f\x64\x69\x66\x66"  mXSaJTMo4mCIueHA05tT9 	 
    norm_v mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 
  	
                file  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   "\x74\x65\x73\x74\x5f\x69\x6d\x67"  mXSaJTMo4mCIueHA05tT9 	 
    	 test_img mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
     

                file  maSJfbIkVmsGsjTv0UQpa 	 
    	  
   "\x6d\x79\x5f\x69\x6d\x67"  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
     
     
 
 my_img maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    	
                file  maSJfbIkVmsGsjTv0UQpa 	 
    	 "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
   your_img mHLOpps1TeJ1n4a5pxdNv 	 
    	  

                file.release mAh372E_Wg9TxPqKoaDdB 	 
    	  
    		   
     
     
 
   mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
     

             mOK1tXVOT4PUgeSc88pGY 	 
   
         mJP7Jsm7au1oZp1CLb7PT 	 
        catch  mmZpaGRQQTWxpkl5_I8in 	 
 std mtOADHjcfWlYUUaEqJYvC 	 
    	  
    	exception& e mXD0JeNoU_GFfICrMiytn 	 
     mChKOw2unTvh7zyq4OT_T 	 
            std mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
     
   cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    	 "\x45\x72\x72\x6f\x72\x3a\x20"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     
 
   e.what mJjX0DECNHF5WB5M9vRzJ 	 
      mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
     
     
 
 std mgrChmV5pX_BBnPjupsCz 	 
  endl mErDDSVFJd4ybmgEkutlI 	 
    	  
  
         mMrjjxUfFnHYwyIeo4thn 	
        catch  mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    		   
     
... mCo_IAiG3U7gZmGW7mfLA 	 
    	   mmgqYc0_7tKLpJXAoouea 	 
    	  
    		   
     
            std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     cerr  mLKaNDZsfPRxbXiWdHvqO 	 "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
     std mwz7jWEjfVuS42kuaQPn8 	 
    	  
   endl maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
    
         mozmL8sMtEcXdVFJtkOKz 	 
    	  
    		   
  

        try  mIXHmxpusVFv3HyUXTK1Q 	 
    	  
    		   
     
     
 

            std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
    cerr  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     
  "\x54\x65\x73\x74\x69\x6e\x67\x20\x63\x6f\x6e\x76\x65\x72\x74\x5f\x72\x67\x62\x5f\x74\x6f\x5f\x67\x72\x61\x79\x20\x2e\x2e\x2e\x20" mCF6yuex92SFioZPpxBz2 	 
    	  

            tests mw6J30JhGYZOxHrm_wMpc 	 mUQApTk2utXRlZOX2bxsA 	 
    	  
    		  
            cv mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
     
Mat test_img  mtcMtq_ZgTF0Gbvko4MMI 	 
    	  
    		   
   cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		 Mat mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   10, 10, CV_8UC3 mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
     
 mUQApTk2utXRlZOX2bxsA 	 
    	 
            rng.fill mmZpaGRQQTWxpkl5_I8in 	 
    	 test_img, cv mWT_5joNFiaFOgpc894br 	 
    	  
 RNG mtOADHjcfWlYUUaEqJYvC 	 
    	  
UNIFORM, 0, 256 mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
     
     
 
  	  mHLOpps1TeJ1n4a5pxdNv 	 
    
            cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
  Mat my_img  mAQFTjhI12FsIF680A_T9 	 
    	  
    		 my_convert_rgb_to_gray mf6w6nRo1UPHMI9Ix1lmT 	 
   test_img mUaKuNbS96FbvDu3x85PG 	 
    	  
  maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 
  	
            cv mWT_5joNFiaFOgpc894br 	 
   Mat your_img  mAQFTjhI12FsIF680A_T9 	 
   convert_rgb_to_gray mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
     
 
  test_img mxBVKq5uLQpnUbC1M415c 	 
    	  
    		   
     
     
 
 mErDDSVFJd4ybmgEkutlI 	
             mZnpA1C5VCYvSOdWYd650 	 
    	  
    		   
     
     
 
 norm_v  mLwpjlSPu7J_elHZYFHIX 	 
    	  cv mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
     
    norm mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     my_img, your_img mCxo5hT3adsjpL3eSx_tm 	 maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 

             moWzCteaw2sTVcwRbVbzv 	 
    	   mmZpaGRQQTWxpkl5_I8in 	 
  norm_v mYDKn6Yr_a4ORyXvUa69a 	 
    	  
    		   
     
     
0.1 mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
   
             mChKOw2unTvh7zyq4OT_T 	 
    	  
    		   
     
   
                tests_passed mLAyVzLAK_LqwPnxSz9Ya 	 
 maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
    
                std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
     cerr  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     
 
  "\x20\x4f\x6b\x21"  mLKaNDZsfPRxbXiWdHvqO 	 
    std mgrChmV5pX_BBnPjupsCz 	 
    	  
 endl mCF6yuex92SFioZPpxBz2 	 
    	
             mJP7Jsm7au1oZp1CLb7PT 	 
    	  

            else
             mzdEyRJKtHmAv_hyCRXsM 	 

                std mhlrvVwQFcOFpdjFt4y2u 	 
ostringstream fname mErDDSVFJd4ybmgEkutlI 	 

                fname  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
    "\x74\x65\x73\x74\x2d"  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
 tests  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
   '-'  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
  seed  mdGdm6zgtH4zv3Nn0vGML 	 
    "\x2e\x78\x6d\x6c" mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
                std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		 cerr  mq3vxPsKSjjq_xpuFA9dn 	 
   "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
     
    norm_v mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
"\x20\x3c\x20\x30\x2e\x31\x21"  mq3vxPsKSjjq_xpuFA9dn 	 
 std mhlrvVwQFcOFpdjFt4y2u 	 
  endl mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		
                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
  cerr  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
  "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
     
     
 
  	  fname.str mAh372E_Wg9TxPqKoaDdB 	 
    	  
    		   
     
     
 
    mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
     
 
   std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		endl mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
                 mJBzoLtWNcFHmcPQ3d6OQ 	 
    	  
    		   
     
     
 
  	 file  mLwpjlSPu7J_elHZYFHIX 	 cv mnsDFHlx8Rb1ohrxyYFfi 	 
 FileStorage mmLzOj1OpcOraAxHe0sHs 	 
    	  
    		  mIeb91O4CN5VggNyO2vQ7 	 
    	  
    	
                file.open mZf3yA3X8Y4vlKmyskuBt 	 
   fname.str muDy_qxq6pQC33xkdhIyC 	 
 , cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
   FileStorage mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
 WRITE mUaKuNbS96FbvDu3x85PG 	 
    	  
    		   
     
     
 
  	 mIeb91O4CN5VggNyO2vQ7 	 
    	  
 
                file  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     "\x4c\x32\x5f\x64\x69\x66\x66"  mA85Ru6M8Sh6PK100OVgE 	 
    norm_v mErDDSVFJd4ybmgEkutlI 	
                file  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
 "\x74\x65\x73\x74\x5f\x69\x6d\x67"  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
     
     
 
  	 test_img mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
  
                file  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
 "\x6d\x79\x5f\x69\x6d\x67"  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
     my_img mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		 
                file  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
     
 
   your_img mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
 
                file.release mmLzOj1OpcOraAxHe0sHs 	 
    	  
    		   
    mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
     
     
 
  	 
             mozmL8sMtEcXdVFJtkOKz 	 
    	  
    		   
     
     
         mPktF2k_R4xKiN2Zg99Ud 	 
    	  
    		   
     
     
 
  
        catch  mppKtzP31aZy0pGd2m0Z9 	 
   std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		  exception& e mUaKuNbS96FbvDu3x85PG 	 
    	  
    mmgqYc0_7tKLpJXAoouea 	 
    	  
    		   
     
     

            std mnsDFHlx8Rb1ohrxyYFfi 	 
 cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
   "\x45\x72\x72\x6f\x72\x3a\x20"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
 e.what mZGQ4J8pc7eRHZbaNBrTR 	 
    	  
    		   
     
   maSJfbIkVmsGsjTv0UQpa 	 
    	 std mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    endl mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
         mJP7Jsm7au1oZp1CLb7PT 	 
 
        catch  mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     ... mW00V7n8RwzFWH7tra2wp 	 
  mnkYVtKJoztdPpfebBy4S 	 
    	  
    		   
     
    
            std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
   "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
     
  std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		  endl mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
 
         mozmL8sMtEcXdVFJtkOKz 	 
    	  
    


        try  mnkYVtKJoztdPpfebBy4S 	 
    	  
    		   
  
            std mErde6Wj4Ze0ly0Y61AFC 	 
   cerr  mXSaJTMo4mCIueHA05tT9 	 
    	 "\x54\x65\x73\x74\x69\x6e\x67\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x5f\x72\x65\x63\x74\x61\x67\x6c\x65\x5f\x6d\x61\x73\x6b\x20\x2e\x2e\x2e\x20" mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
     
     
 

            tests mjXVeKcEorHWSksfRH2UB 	 
    	  
    		 maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 
  	 
             mPEXKIHylb5EYa1bDUzOc 	 
    	  
x  mLwpjlSPu7J_elHZYFHIX 	 
   rng.uniform mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
 0, 10 mW00V7n8RwzFWH7tra2wp 	  mUQApTk2utXRlZOX2bxsA 	 
 
             mPEXKIHylb5EYa1bDUzOc 	 
    	  
y  mLwpjlSPu7J_elHZYFHIX 	 
    	  
    		   rng.uniform mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
     
  0, 20 mXD0JeNoU_GFfICrMiytn 	 
    	  mHLOpps1TeJ1n4a5pxdNv 	 
             mPEXKIHylb5EYa1bDUzOc 	 
    	  
    		  w  mik5L9gUWoenRFF12Yrzk 	 
    	  
    		   
     
     
 
  rng.uniform mwEFsCY_vJ82sL6GSMTpd 	1, 10 mxBVKq5uLQpnUbC1M415c 	 
    	  
    		   
     
      mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
     
 

             mk5_ghEAebl24EQAP8Y2I 	 
    	  
    		   
   h  mLZ3y6cDPwjsfFVKTrILy 	 
    	  
  rng.uniform mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     
 1, 10 mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
  mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
     
   
            cv mWT_5joNFiaFOgpc894br 	 
    	  
    		Mat my_img  mik5L9gUWoenRFF12Yrzk 	 
    	  
    		   
     
     
  my_generate_rectagle_mask mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    		   
     
   20, 30, x, y, w, h mUaKuNbS96FbvDu3x85PG 	 
    	  
    		   
     
  mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
   
            cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
     
     
 
Mat your_img  mtcMtq_ZgTF0Gbvko4MMI 	 
     generate_rectagle_mask mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
  20, 30, x, y, w, h mUaKuNbS96FbvDu3x85PG 	 
    	  
    		   
     
     
 
  mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
    
             mZnpA1C5VCYvSOdWYd650 	 
    	  
    		   
     
  norm_v  mrW3LX4vM3dW4niDeipVf 	 
    	  
   cv mnsDFHlx8Rb1ohrxyYFfi 	norm mppKtzP31aZy0pGd2m0Z9 	 
    	  
    	my_img, your_img mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
      mHLOpps1TeJ1n4a5pxdNv 	 
    
             mVmHfDt9pq2zl91iYWE6U 	 
    	  
    		   
     
      myuutvgsUpQCFDJ0ssvlp 	 
    	  
  norm_v mC5E9mNw3KALrr8VsSONZ 	 
    	  
    		   
   0.1 mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
     
     

             mmgqYc0_7tKLpJXAoouea 	 
    	  
    
                tests_passed mw6J30JhGYZOxHrm_wMpc 	 
    	  
  mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 
  	 
                std mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
     cerr  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
      "\x20\x4f\x6b\x21"  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
     std mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   endl mUQApTk2utXRlZOX2bxsA 	 
    	  
  
             mMrjjxUfFnHYwyIeo4thn 	 
  
            else
             myi_nNZ_JfQR5mbTdok9w 	 
    	  
    	
                std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
ostringstream fname maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     

                fname  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
 "\x74\x65\x73\x74\x2d"  mLKaNDZsfPRxbXiWdHvqO 	  tests  mA85Ru6M8Sh6PK100OVgE 	 
   '-'  mLKaNDZsfPRxbXiWdHvqO 	 
 seed  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
     
   "\x2e\x78\x6d\x6c" mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
  
                std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
    cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
    "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
     
 
  	 norm_v mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     
"\x20\x3c\x20\x30\x2e\x31\x21"  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
    std mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		 endl mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
     

                std mhlrvVwQFcOFpdjFt4y2u 	 
    	cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
     
 
   "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
     
     
 
 fname.str muDy_qxq6pQC33xkdhIyC 	 
    	  
    		   
     
     
   mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     
     
 
  std mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
     
     endl mErDDSVFJd4ybmgEkutlI 	 
   
                 mJBzoLtWNcFHmcPQ3d6OQ 	 
    	  
    		   
     
     
 
  file  myAj9JkIJCTTmCuRc8M99 	 
  cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
 FileStorage mwDTANvBf2eCihKlwIGcQ 	 
    	  
    		   
     
     
 
  	 mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		  
                file.open mmZpaGRQQTWxpkl5_I8in 	 
  fname.str mJjX0DECNHF5WB5M9vRzJ 	 
    	  
    		   
    , cv mnsDFHlx8Rb1ohrxyYFfi 	 
    FileStorage mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
 WRITE mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
     
 mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
 
                file  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
  "\x78"  mUgUEfVdBAs_RDl0oUbQO 	 
     x mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
 
                file  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     
 
   "\x79"  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		    y mCTRiZEfCcZ4rtZeXzEPU 	
                file  mLKaNDZsfPRxbXiWdHvqO 	  "\x77"  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
     
     
 
 w mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
     
     
 
  	 
                file  mXSaJTMo4mCIueHA05tT9 	  "\x68"  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
     
     
 
  h mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		
                file  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
     
     
  "\x4c\x32\x5f\x64\x69\x66\x66"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
      norm_v mIeb91O4CN5VggNyO2vQ7 	 
 
                file  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		    "\x6d\x79\x5f\x69\x6d\x67"  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
      my_img mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    	
                file  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     
    "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mXSaJTMo4mCIueHA05tT9 	 
    	  
    your_img mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
    
                file.release moLZmyH4uSJX9pXN1kkKz 	 
    	  
    		   
     
   mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
 

             mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
    
         mJTa21GBBlpdHs8EUXwZ0 	 
    	  
   
        catch  mppKtzP31aZy0pGd2m0Z9 	 
    	  
    		   
     
 std mMNd9IbgZGNvHCj6cXNIY 	 
exception& e mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
  mmgqYc0_7tKLpJXAoouea 	 
    	  
    		   
  
            std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
cerr  mUgUEfVdBAs_RDl0oUbQO 	 
   "\x45\x72\x72\x6f\x72\x3a\x20"  maSJfbIkVmsGsjTv0UQpa 	 e.what moLZmyH4uSJX9pXN1kkKz 	 
    	  
    		   
     
     
 
  	  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
     
 
 std mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
  endl maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 
  
         mJP7Jsm7au1oZp1CLb7PT 	 
    	  
    		   
 
        catch  mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
     
     
 ... mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
     
     
 
  	   mmgqYc0_7tKLpJXAoouea 	 
    	  

            std mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
     
 
 cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
 "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  mXSaJTMo4mCIueHA05tT9 	 
    	 std mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		 endl mKCH6zvmv2K2hcW15vK3r 	 
    	  
  
         mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
 

        try  mzdEyRJKtHmAv_hyCRXsM 	 
    	  
    		   
   
            std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
     
    cerr  mq3vxPsKSjjq_xpuFA9dn 	 "\x54\x65\x73\x74\x69\x6e\x67\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x5f\x63\x69\x72\x63\x6c\x65\x5f\x6d\x61\x73\x6b\x20\x2e\x2e\x2e\x20" mKCH6zvmv2K2hcW15vK3r 	 
    	  
    	
            tests mjXVeKcEorHWSksfRH2UB 	 
    	  
    		   
     
     
 
  	  mHLOpps1TeJ1n4a5pxdNv 	 
    	 
             mCWMzZFPcoXg9fIw5padT 	 
    	  
    		   
   x  mSk1ShXRx3FQBFfrfi8ft 	 
    	  
    		   
     
 rng.uniform mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
    0, 10 mxBVKq5uLQpnUbC1M415c 	 
    	  
    		   
     
     
 
  	 mUQApTk2utXRlZOX2bxsA 	 
    	
             mH6PiHnqpo8UuqrMEAB6z 	 
    	  
    		   
  y  mik5L9gUWoenRFF12Yrzk 	 
    	  
    		   
     
    rng.uniform mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 
  	0, 20 mq2WtyfxNuhMujs_W_RTx 	 
  mKCH6zvmv2K2hcW15vK3r 	 

             mTHYbenkovkCYepR9rjtw 	 
    	  
    	r  mik5L9gUWoenRFF12Yrzk 	 
   rng.uniform mpYC3Q6HCOG_y3bCV_bzU 	 
    	  1, 5 mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
     
  mErDDSVFJd4ybmgEkutlI 	 

            cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
     
    Mat my_img  mpIazGz0BO8GDZeOCwtDA 	 
    	  
    		   
    my_generate_circle_mask mppKtzP31aZy0pGd2m0Z9 	 
   20,30,x,y,r mA3nRYnr_lZzzMo1jh_vB 	 
    	  
     mHLOpps1TeJ1n4a5pxdNv 	 
    	  
   
            cv mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
     Mat your_img  mrW3LX4vM3dW4niDeipVf 	 
    generate_circle_mask mwEFsCY_vJ82sL6GSMTpd 	 
    	  
   20,30,x,y,r mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
     
  mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
     
   
             mjLI8BhQkZaoZetEfC056 	 
    	  
    		   
     
     
 
norm_v  mLwpjlSPu7J_elHZYFHIX 	 cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   norm mppKtzP31aZy0pGd2m0Z9 	 
    	  
  my_img, your_img mW00V7n8RwzFWH7tra2wp 	 
     mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		  
             mVmHfDt9pq2zl91iYWE6U 	 
    	  
    		   
     
     
 
 mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
norm_v maJJMpCnCYLQsMYPbFYMA 	 
    	  
    		   0.1 mW00V7n8RwzFWH7tra2wp 	 
    	  
   
             mIXHmxpusVFv3HyUXTK1Q 	 
    	  
    		   
 
                tests_passed mUzTGmNZ8S0WIPlKPasub 	 
    	  
     mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
     
                std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   cerr  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
    "\x20\x4f\x6b\x21"  mdGdm6zgtH4zv3Nn0vGML 	 std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		 endl mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
  
             mfYUGCIJ4y66ek5pHyoZN 	 
    	  
    		   
     
     
 
            else
             miHaghnjGYZRXpERY7vgM 	 
    	  
    		   
 
                std mgwQSYXcc9TIiKkPXgshg 	 
    	  ostringstream fname mu0Zw3fsOhh38Uo4aDS8W 	 
    	  

                fname  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		    "\x74\x65\x73\x74\x2d"  maSJfbIkVmsGsjTv0UQpa 	 tests  mdapI6SZ0JwzhtKL_Oxis 	 
     '-'  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
      seed  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    	 "\x2e\x78\x6d\x6c" mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
     
                std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
  cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
     "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mUgUEfVdBAs_RDl0oUbQO 	 
  norm_v maSJfbIkVmsGsjTv0UQpa 	 
    	  
"\x20\x3c\x20\x30\x2e\x31\x21"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
      std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
    endl mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
 
  
                std mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
    cerr  mUgUEfVdBAs_RDl0oUbQO 	 
  "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  mUgUEfVdBAs_RDl0oUbQO 	 
  fname.str mmLzOj1OpcOraAxHe0sHs 	 
    	  
    		   
     mq3vxPsKSjjq_xpuFA9dn 	 
    	  std mgwQSYXcc9TIiKkPXgshg 	 
  endl mIeb91O4CN5VggNyO2vQ7 	
                 mJBzoLtWNcFHmcPQ3d6OQ 	 
    	  
    		   
     
     
 
  file  mtcMtq_ZgTF0Gbvko4MMI 	 
    	   cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
     
 
  FileStorage mWAv9IocI7GJUr5S69MXT 	 
    	  
    		   
      mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    	
                file.open mYSn7neYwuzZiHSfgVhG4 	 
    	  
    		   
     
     
 
  	fname.str mWAv9IocI7GJUr5S69MXT 	 
    	  
    		   
 , cv mgwQSYXcc9TIiKkPXgshg 	 
    	 FileStorage mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    	WRITE mxBVKq5uLQpnUbC1M415c 	 
    	 mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
     
 
                file  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		   
     
     "\x78"  mUgUEfVdBAs_RDl0oUbQO 	 x mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
 
 
                file  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    	 "\x79"  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
  y maPJhxKGuCRBF8PTSEfoJ 	 
    	  
   
                file  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    	 "\x72"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
     r mHLOpps1TeJ1n4a5pxdNv 	 
    	 
                file  mq3vxPsKSjjq_xpuFA9dn 	 "\x4c\x32\x5f\x64\x69\x66\x66"  mq3vxPsKSjjq_xpuFA9dn 	 
    	   norm_v mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
     
 
  	 
                file  mXSaJTMo4mCIueHA05tT9 	 "\x6d\x79\x5f\x69\x6d\x67"  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   my_img mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
   
                file  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
     
     
  "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     your_img maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 

                file.release mJjX0DECNHF5WB5M9vRzJ 	 
    mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
     
 

             mqSTm3bttsS7HrMtCtqcS 	 
    	 
         mNGHuSbVa0_na45B50kOF 	
        catch  mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 
  	std mtOADHjcfWlYUUaEqJYvC 	 
  exception& e mA3nRYnr_lZzzMo1jh_vB 	 
  mzdEyRJKtHmAv_hyCRXsM 	 
    	  
    		   
     
     
 
  
            std mWT_5joNFiaFOgpc894br 	 
    	  
    		   
     cerr  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
  "\x45\x72\x72\x6f\x72\x3a\x20"  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
     
 
  	 e.what mmLzOj1OpcOraAxHe0sHs 	 
    	  
    		   
     
     
 
  	  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
endl mu0Zw3fsOhh38Uo4aDS8W 	 
 
         mJTa21GBBlpdHs8EUXwZ0 	 
    	  
    		   
     
 
        catch  mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
 ... mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   myi_nNZ_JfQR5mbTdok9w 	 
    	  
    		   
    
            std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
     
 
 cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
   "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
     
 
 std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		  endl mHLOpps1TeJ1n4a5pxdNv 	 
    	 
         mOK1tXVOT4PUgeSc88pGY 	 
    	  
    

        try  mzdEyRJKtHmAv_hyCRXsM 	 
    	  
    		
            std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     cerr  mq3vxPsKSjjq_xpuFA9dn 	 
    "\x54\x65\x73\x74\x69\x6e\x67\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x5f\x70\x6f\x6c\x79\x67\x6f\x6e\x5f\x6d\x61\x73\x6b\x20\x2e\x2e\x2e\x20" mUQApTk2utXRlZOX2bxsA 	
            tests mI4i8YlJZREbZV6pNhNgC 	 
    	  
    		   
     
     
 
  	  mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
             mTHYbenkovkCYepR9rjtw 	 
    	  
    		   
     
     
 
  	 x  mrW3LX4vM3dW4niDeipVf 	 
    	  
    		   
     
      rng.uniform mppKtzP31aZy0pGd2m0Z9 	 
    	  
  6, 13 mCo_IAiG3U7gZmGW7mfLA 	 
 mIeb91O4CN5VggNyO2vQ7 	 
    	  
             mxsIRoNEMzjS6Yb5k6usv 	 
    	y  mkNGVmRSdeblSckxXzGVq 	 
    	  
    		   
 rng.uniform mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    		 6, 20 mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
 mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		  
            std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
vector mTTUVMx3R6fGe9krQWHNl 	 
    	  
 cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
Point my120EBF7HLidYoqsyV9U 	 
    	  
    		   
 points mErDDSVFJd4ybmgEkutlI 	 
    	  

            points.push_back mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
   cv mWT_5joNFiaFOgpc894br 	 
    Point mpYC3Q6HCOG_y3bCV_bzU 	 
   x, y mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
     mXD0JeNoU_GFfICrMiytn 	 
    	  
    mu0Zw3fsOhh38Uo4aDS8W 	 
    	  

            points.push_back mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
   Point mmZpaGRQQTWxpkl5_I8in 	 
  x+3, y+3 mCo_IAiG3U7gZmGW7mfLA 	  mW00V7n8RwzFWH7tra2wp 	 
    	  
     mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
    
            points.push_back mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    		   
     
     
cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
    		   
     
     
Point mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
     
     
 
  	x, y+6 mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
      mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
    mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
     
            points.push_back mChGzY6uJwNl0HsnhepB1 	 
    	  
    		   
    cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
  Point mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     
     
 
  	 x-3, y+3 mA3nRYnr_lZzzMo1jh_vB 	 
 mCxo5hT3adsjpL3eSx_tm 	  mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   

            cv mwz7jWEjfVuS42kuaQPn8 	 Mat my_img  mLZ3y6cDPwjsfFVKTrILy 	 
    	  
    		  my_generate_polygon_mask mZf3yA3X8Y4vlKmyskuBt 	 
    20,30, points mXD0JeNoU_GFfICrMiytn 	 mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     
  
            cv mgrChmV5pX_BBnPjupsCz 	 
    	  
    		   
     
     
 
  Mat your_img  myAj9JkIJCTTmCuRc8M99 	 
    	  
    		   
     
     
 
  	  generate_polygon_mask mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		   
     
  20,30, points mq2WtyfxNuhMujs_W_RTx 	 
    mHLOpps1TeJ1n4a5pxdNv 	
             mVlKX00k16qzhto6c5_qj 	 
    	  
    		   
     
     
norm_v  mtcMtq_ZgTF0Gbvko4MMI 	 
    	  
    		   
     
  cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
  norm mZf3yA3X8Y4vlKmyskuBt 	 
    	  
  my_img, your_img mA3nRYnr_lZzzMo1jh_vB 	 
    	   mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    	
             moWzCteaw2sTVcwRbVbzv 	 
    	  
    		   
     
 mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
    norm_v mEaKKI8OgTfRUieYzOXug 	 
    	  
    		  0.1 mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
     
   
             mzdEyRJKtHmAv_hyCRXsM 	 
    	  

                tests_passed mI4i8YlJZREbZV6pNhNgC 	 
    	  
  mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
    
                std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     
 
  cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     
 "\x20\x4f\x6b\x21"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     std mErde6Wj4Ze0ly0Y61AFC 	 
    	 endl mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   

             mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
            else
             mChKOw2unTvh7zyq4OT_T 	 
    	  
    		   
     
     
 
  
                std mgrChmV5pX_BBnPjupsCz 	 
    	  
  ostringstream fname maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
    
                fname  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    "\x74\x65\x73\x74\x2d"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
 tests  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    '-'  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
     
     
 
  	 seed  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
    "\x2e\x78\x6d\x6c" mErDDSVFJd4ybmgEkutlI 	 
    	  
    		 
                std mhlrvVwQFcOFpdjFt4y2u 	 
 cerr  mdGdm6zgtH4zv3Nn0vGML 	 
   "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mA85Ru6M8Sh6PK100OVgE 	 
    	norm_v mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
     
     
 
"\x20\x3c\x20\x30\x2e\x31\x21"  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
      std mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
     
 
  endl mCTRiZEfCcZ4rtZeXzEPU 	 
    	
                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
cerr  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
     
     
 
   "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		    fname.str mZGQ4J8pc7eRHZbaNBrTR 	 
    	  mA85Ru6M8Sh6PK100OVgE 	 
     std mpd4PM_FCAECboim6Wmgy 	 
    	  
   endl mCF6yuex92SFioZPpxBz2 	 
    	  
    		   

                 myn0IRnj83DrK6IeL7ZqP 	 
    	  
    		   
file  mtcMtq_ZgTF0Gbvko4MMI 	 
    	  
    		   
  cv mgwQSYXcc9TIiKkPXgshg 	 
    FileStorage mmLzOj1OpcOraAxHe0sHs 	 
    	  
  mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
     

                file.open mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     
     
 fname.str muDy_qxq6pQC33xkdhIyC 	 
, cv mpd4PM_FCAECboim6Wmgy 	 
 FileStorage mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
 WRITE mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
     
 
   mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
                file  mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		   
     
     
 
  	  "\x70\x6f\x69\x6e\x74\x73"  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		  points mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   

                file  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
     
   "\x4c\x32\x5f\x64\x69\x66\x66"  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    	 norm_v mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
     

                file  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   "\x6d\x79\x5f\x69\x6d\x67"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     
   my_img mKCH6zvmv2K2hcW15vK3r 	 
    
                file  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
    "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mHuF4mTDu6zvknssKtlKQ 	 
 your_img mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
  
                file.release moLZmyH4uSJX9pXN1kkKz 	 
    	  
    		   
     
     
 mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
 
             mfYUGCIJ4y66ek5pHyoZN 	 
    	  
    		   
     
     
         mozmL8sMtEcXdVFJtkOKz 	 
    	  
    		   
        catch  mf6w6nRo1UPHMI9Ix1lmT 	 
    	  
    		std mpd4PM_FCAECboim6Wmgy 	 
    	  exception& e mCxo5hT3adsjpL3eSx_tm 	   mWPvycRWzzsoqLdQC4Zks 	 
    	  
    		 
            std mtOADHjcfWlYUUaEqJYvC 	 
  cerr  mA85Ru6M8Sh6PK100OVgE 	 
     "\x45\x72\x72\x6f\x72\x3a\x20"  mdapI6SZ0JwzhtKL_Oxis 	 
    	 e.what mWAv9IocI7GJUr5S69MXT 	 
    	  
    		   
     
     
   mA85Ru6M8Sh6PK100OVgE 	 std mErde6Wj4Ze0ly0Y61AFC 	endl mUQApTk2utXRlZOX2bxsA 	 
 
         mJTa21GBBlpdHs8EUXwZ0 	 
    	  
    		   
     
 
        catch  mppKtzP31aZy0pGd2m0Z9 	 
    	  
    		... mA3nRYnr_lZzzMo1jh_vB 	 
    	  
    		   
     
     
 
    mWPvycRWzzsoqLdQC4Zks 	 
    	  
    		   
     
     

            std mMNd9IbgZGNvHCj6cXNIY 	 
 cerr  mXSaJTMo4mCIueHA05tT9 	 
    	  
    		  "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     
    std mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
 endl mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
 
         mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
     
     
 


        try  mmgqYc0_7tKLpJXAoouea 	 
    	  
    		   
     
  
            std mWT_5joNFiaFOgpc894br 	 
    	  
  cerr  mdapI6SZ0JwzhtKL_Oxis 	 
    	  
    		   
     "\x54\x65\x73\x74\x69\x6e\x67\x20\x63\x6f\x6d\x62\x69\x6e\x65\x5f\x69\x6d\x61\x67\x65\x73\x20\x2e\x2e\x2e\x20" mKCH6zvmv2K2hcW15vK3r 	 
    	  
  
            tests mI4i8YlJZREbZV6pNhNgC 	 
    	  
    		   
      mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		   
     
     
 

            cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    Mat test_img1  mSk1ShXRx3FQBFfrfi8ft 	 
    	  
    		   
      cv mhlrvVwQFcOFpdjFt4y2u 	 
   Mat mZf3yA3X8Y4vlKmyskuBt 	 
    	  
  30, 20, CV_8UC3 mW00V7n8RwzFWH7tra2wp 	 
    mUQApTk2utXRlZOX2bxsA 	
            rng.fill mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    		   
    test_img1, cv mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
     
    RNG mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
     
 UNIFORM, 0, 256 mCFpr4Os_BUpE0hBecZXK 	 
     mCF6yuex92SFioZPpxBz2 	 
    
            cv mMNd9IbgZGNvHCj6cXNIY 	 
    	 Mat test_img2  mrW3LX4vM3dW4niDeipVf 	 
    	  
   cv mwz7jWEjfVuS42kuaQPn8 	 
    	  
    		   
Mat mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
     
     30, 20, CV_8UC3 mCo_IAiG3U7gZmGW7mfLA 	 
 mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
 
            rng.fill mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
 test_img2, cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
  RNG mgrChmV5pX_BBnPjupsCz 	 
    	  
UNIFORM, 0, 256 mxBVKq5uLQpnUbC1M415c 	 
    	  
    		   
   mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
     
 
            cv mWT_5joNFiaFOgpc894br 	 
    Mat mask_img  myAj9JkIJCTTmCuRc8M99 	 cv mnsDFHlx8Rb1ohrxyYFfi 	 
    	  
 Mat mWT_5joNFiaFOgpc894br 	 
    	 zeros mmZpaGRQQTWxpkl5_I8in 	 
    	  
    		   
     
 30, 20, CV_8UC3 mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
      mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
             molbYrJdmAWzmis3mfRI9 	 
    	x  myAj9JkIJCTTmCuRc8M99 	 
    	  
    		   
     
     
 rng.uniform mf6w6nRo1UPHMI9Ix1lmT 	0, 10 mCo_IAiG3U7gZmGW7mfLA 	 
    	  
    		   
     
     
 mHLOpps1TeJ1n4a5pxdNv 	 
    	  
    		   
     
 
             mPEXKIHylb5EYa1bDUzOc 	 
  y  mrW3LX4vM3dW4niDeipVf 	 
    	  
    		   
     
     
 rng.uniform mpYC3Q6HCOG_y3bCV_bzU 	 
    	  
    		   
     
0, 20 mt6dcxNU8FQBTRU5nGYnX 	 
    	  
    		   
     
     
 mUQApTk2utXRlZOX2bxsA 	 
    	  
    	
             mTHYbenkovkCYepR9rjtw 	w  mik5L9gUWoenRFF12Yrzk 	 
    	  
     rng.uniform mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
     
     
1, 10 mA3nRYnr_lZzzMo1jh_vB 	 
    	  
    		   
     
 mHLOpps1TeJ1n4a5pxdNv 	 
    	 
             mk5_ghEAebl24EQAP8Y2I 	 
    	  
    		   
h  mkNGVmRSdeblSckxXzGVq 	 
    	  
    		   
   rng.uniform mmKFpIHZ2jW3Pl2yswFoH 	 
    	  
    1, 10 mCxo5hT3adsjpL3eSx_tm 	 
    	  
    		   
     
  mCF6yuex92SFioZPpxBz2 	 
    	  
    		   
     
     
 
  	
            mask_img mChGzY6uJwNl0HsnhepB1 	 
  cv mpd4PM_FCAECboim6Wmgy 	 
 Rect mZf3yA3X8Y4vlKmyskuBt 	 
    	  
x, y, w, h mA3nRYnr_lZzzMo1jh_vB 	 
    	  
    		   
     
    mXD0JeNoU_GFfICrMiytn 	 
    	  
    		   
      mik5L9gUWoenRFF12Yrzk 	 
    	  
    		   
     
      cv mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   
  Scalar mChGzY6uJwNl0HsnhepB1 	 
    	255, 255, 255 mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
     
     
 
   mu0Zw3fsOhh38Uo4aDS8W 	 
    	  
    		   
  
            cv mErde6Wj4Ze0ly0Y61AFC 	Mat my_img  mtcMtq_ZgTF0Gbvko4MMI 	 
    	   my_combine_images mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		  test_img1, test_img2, mask_img mW00V7n8RwzFWH7tra2wp 	 
    	  
    		   
     
     
  mUQApTk2utXRlZOX2bxsA 	 
    	 
            cv mgrChmV5pX_BBnPjupsCz 	 
   Mat your_img  myAj9JkIJCTTmCuRc8M99 	 
    	  
    		   
     
     combine_images mYSn7neYwuzZiHSfgVhG4 	 
test_img1, test_img2, mask_img mUaKuNbS96FbvDu3x85PG 	 
 mCF6yuex92SFioZPpxBz2 	 
             mP1zJlYesuPo0RorPJYu9 	 
    	  
   norm_v  mrW3LX4vM3dW4niDeipVf 	  cv mMNd9IbgZGNvHCj6cXNIY 	 
    	  norm mwEFsCY_vJ82sL6GSMTpd 	 
    	  
    		   
  my_img, your_img mCFpr4Os_BUpE0hBecZXK 	 
    	  
    		   
    mCF6yuex92SFioZPpxBz2 	
             mZWGtEnNSuqL2nrO4fXdk 	  myuutvgsUpQCFDJ0ssvlp 	 
    	  
    		   
     
  norm_v msL_HjjMOgmuquii8oJwE 	 
    	  
    	0.1 mA3nRYnr_lZzzMo1jh_vB 	 
    	  
    		   
   
             mnkYVtKJoztdPpfebBy4S 	 
    	  
    		   
     

                tests_passed mUzTGmNZ8S0WIPlKPasub 	 
  mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
     
 

                std mgwQSYXcc9TIiKkPXgshg 	 
    	cerr  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
     
 
  	  "\x20\x4f\x6b\x21"  mA85Ru6M8Sh6PK100OVgE 	  std mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
     
endl mIeb91O4CN5VggNyO2vQ7 	 
    	  
 
             mqSTm3bttsS7HrMtCtqcS 	 
    	  
    		   
            else
             mChKOw2unTvh7zyq4OT_T 	 
    	  
    		   
     
     
 
                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
    ostringstream fname mCTRiZEfCcZ4rtZeXzEPU 	 
    	  
    		
                fname  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    "\x74\x65\x73\x74\x2d"  mdGdm6zgtH4zv3Nn0vGML 	 tests  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   '-'  mbP3VgAHoOgnaUfLyN3rO 	 
    	  
    		   
      seed  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
    "\x2e\x78\x6d\x6c" mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   

                std mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
  cerr  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
    "\x54\x65\x73\x74\x20\x66\x61\x69\x6c\x3a\x20\x63\x76\x3a\x3a\x6e\x6f\x72\x6d\x28\x6d\x79\x5f\x69\x6d\x67\x2d\x79\x6f\x75\x72\x5f\x69\x6d\x67\x29\x3d" mHuF4mTDu6zvknssKtlKQ 	 norm_v mXSaJTMo4mCIueHA05tT9 	 
    	  
    		   
   "\x20\x3c\x20\x30\x2e\x31\x21"  mA85Ru6M8Sh6PK100OVgE 	 
  std mpd4PM_FCAECboim6Wmgy 	 
    	  
    		   
     
    endl mUQApTk2utXRlZOX2bxsA 	
                std mWT_5joNFiaFOgpc894br 	 
    	  
    		cerr  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    		    "\x5c\x74\x20\x74\x65\x73\x74\x20\x64\x61\x74\x61\x20\x66\x69\x6c\x65\x3a\x20"  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   fname.str mAh372E_Wg9TxPqKoaDdB 	 
    	  
    		   mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		 std mgwQSYXcc9TIiKkPXgshg 	 
   endl maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
   
                 mAot4lv_hqRDJSbAui1kl 	 
    	  
    		   
     
file  mtcMtq_ZgTF0Gbvko4MMI 	 
    	  
    		   
    cv mWT_5joNFiaFOgpc894br 	 
    	  
    		   
   FileStorage mJjX0DECNHF5WB5M9vRzJ 	 
    mErDDSVFJd4ybmgEkutlI 	 

                file.open mYSn7neYwuzZiHSfgVhG4 	 
  fname.str mwDTANvBf2eCihKlwIGcQ 	 
    	  
    		   
     , cv mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
    FileStorage mhlrvVwQFcOFpdjFt4y2u 	 
    	  
    		   
     
    WRITE mA3nRYnr_lZzzMo1jh_vB 	 
    	  
  mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
 
                file  mq3vxPsKSjjq_xpuFA9dn 	 
   "\x4c\x32\x5f\x64\x69\x66\x66"  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   norm_v mUQApTk2utXRlZOX2bxsA 	 
    	  
    		   
     
     
                file  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
 "\x74\x65\x73\x74\x5f\x69\x6d\x67\x31"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    test_img1 mCF6yuex92SFioZPpxBz2 	 
    	  
    		
                file  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    	 "\x74\x65\x73\x74\x5f\x69\x6d\x67\x32"  mdGdm6zgtH4zv3Nn0vGML 	 test_img1 mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
     
 
                file  mUgUEfVdBAs_RDl0oUbQO 	 
 "\x74\x65\x73\x74\x5f\x6d\x61\x73\x6b"  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
      mask_img mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
     
 

                file  mXSaJTMo4mCIueHA05tT9 	 
    	  
    	 "\x6d\x79\x5f\x69\x6d\x67"  maSJfbIkVmsGsjTv0UQpa 	 
    	  my_img mZ5n7IX_AHHoHYsodfx8Y 	 
    	  
    		   
     
  
                file  mLKaNDZsfPRxbXiWdHvqO 	 
    	  
    		   
     "\x79\x6f\x75\x72\x5f\x69\x6d\x67"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
     
     
 
  	 your_img mHLOpps1TeJ1n4a5pxdNv 	 
    	  
                file.release mmLzOj1OpcOraAxHe0sHs 	 
    	  
    		   
    mu0Zw3fsOhh38Uo4aDS8W 	 
 
             mfYUGCIJ4y66ek5pHyoZN 	 
    	  
    		   
     
    
         mPktF2k_R4xKiN2Zg99Ud 	 
    	  

        catch  mf6w6nRo1UPHMI9Ix1lmT 	 std mMNd9IbgZGNvHCj6cXNIY 	 
    exception& e mq2WtyfxNuhMujs_W_RTx 	 
    	  
    		   
    mmgqYc0_7tKLpJXAoouea 	 
  
            std mgrChmV5pX_BBnPjupsCz 	 cerr  mHuF4mTDu6zvknssKtlKQ 	 
   "\x45\x72\x72\x6f\x72\x3a\x20"  mq3vxPsKSjjq_xpuFA9dn 	  e.what mZGQ4J8pc7eRHZbaNBrTR 	 
    	  
    	  mHuF4mTDu6zvknssKtlKQ 	 
    	  
     std mhlrvVwQFcOFpdjFt4y2u 	endl mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		 
         mqBnU2_MtantM647nyIHb 	 
    	  
    		   
  
        catch  mZf3yA3X8Y4vlKmyskuBt 	 
    	  
    		   
     
     
 ... mUaKuNbS96FbvDu3x85PG 	  mIXHmxpusVFv3HyUXTK1Q 	 
    	  
    		   
     
     

            std mgwQSYXcc9TIiKkPXgshg 	 
    	  
    		   
 cerr  maSJfbIkVmsGsjTv0UQpa 	 
    	  
    		   
     "\x45\x72\x72\x6f\x72\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x21\x21\x2e"  mA85Ru6M8Sh6PK100OVgE 	 
    	  
    		   
    std mhlrvVwQFcOFpdjFt4y2u 	 endl mErDDSVFJd4ybmgEkutlI 	 
    	  
    		   
  
         mJP7Jsm7au1oZp1CLb7PT 	 
    	  
    		   
  

        std mtOADHjcfWlYUUaEqJYvC 	 
    	  
    		   
   cout  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
   "\x59\x6f\x75\x20\x70\x61\x73\x73\x20"  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
     
     
 
  tests_passed  mdGdm6zgtH4zv3Nn0vGML 	 
  "\x20\x6f\x66\x20"  mdGdm6zgtH4zv3Nn0vGML 	 
    	  
    	 tests
                   mq3vxPsKSjjq_xpuFA9dn 	 
    	  
    		  "\x20\x74\x65\x73\x74\x73\x2e"  mHuF4mTDu6zvknssKtlKQ 	 
    	   std mErde6Wj4Ze0ly0Y61AFC 	 
    	  
    		   endl mKCH6zvmv2K2hcW15vK3r 	 
    	  
    		   
     
     
 

     mOK1tXVOT4PUgeSc88pGY 	
    catch  mChGzY6uJwNl0HsnhepB1 	std mMNd9IbgZGNvHCj6cXNIY 	 
    	  
    		   
     
exception& e mCFpr4Os_BUpE0hBecZXK 	 
   
     mWPvycRWzzsoqLdQC4Zks 	 
    	  
    		   
     
     
 

        std mgrChmV5pX_BBnPjupsCz 	cerr  mHuF4mTDu6zvknssKtlKQ 	 
    	  
    		   
  "\x43\x61\x70\x74\x75\x72\x61\x64\x61\x20\x65\x78\x63\x65\x70\x63\x69\x6f\x6e\x3a\x20"  mUgUEfVdBAs_RDl0oUbQO 	 
    	  
    		   
     
     
 
  	 e.what mWAv9IocI7GJUr5S69MXT 	 
    	  
    		   
    mLKaNDZsfPRxbXiWdHvqO 	 
    	 std mgrChmV5pX_BBnPjupsCz 	 
    	  
    		endl mUQApTk2utXRlZOX2bxsA 	
        retCode  mpIazGz0BO8GDZeOCwtDA 	 
   EXIT_FAILURE mIeb91O4CN5VggNyO2vQ7 	 
    	  
    		   
     
     
     mqBnU2_MtantM647nyIHb 	 
    	  
    		   
  
     mozF1ZOMKmB5oOYXvA1du 	 
retCode maPJhxKGuCRBF8PTSEfoJ 	 
    	  
    		   
     
     
 
 
 mozmL8sMtEcXdVFJtkOKz 	 
    	  
    		   


#ifdef _9902994529659639011
#undef  moLZV0j_SV0Paib5pnbtP 
#undef  mUagi6OPvjB1yh8__JH1r 
#undef  mI731qyUiUqX6x_iyE5Oc 
#undef  mWFvb9yv7vF3YXh4NKVlk 
#undef  mwmL8FJwTyVILdCGkEIbX 
#undef mTQ6fz8vn4RTtZGBgadrOoJp57aBMTi
#undef  m_2rb0cegg1vhefblfVbl 
#undef  mla_qUta0CYTeiLcAk3J8 
#undef  maNRdGOSqH0sUhNNjaXcm 
#undef  mwiBdzEHrOc8W4OPuXzjS 
#undef  mjaVAncDj71cTeIqEbWwz 
#undef mIi4pGj2ZRBLOFPg8uwj4Mr3IqLqlE1
#undef mr6MWVHx8P95r4cHeiqasoMXxgcesWE
#undef  mXnMFKz3exHf_N4BVfgef 
#undef mNm3tIZaxNmZesd6TUuHkhUD_qnf_Fh
#undef  mrW3LX4vM3dW4niDeipVf 
#undef  mLKaNDZsfPRxbXiWdHvqO 
#undef  mgwQSYXcc9TIiKkPXgshg 
#undef  mxJJoGrHRUFqS_L8CEdvL 
#undef  mgRWDmYeVW8IswTg4QT2O 
#undef mMwYJB3BgOv6cM80ptANSlxGtICblgL
#undef  moJmL11euOhHbQagPq8ij 
#undef mbDgHYMP195EyLGQrE12uPk2WJ7zJWT
#undef  mJSjBBo51EctsDDn27vtP 
#undef  mAhRWDjq8o9SPhF0wMeGa 
#undef mcImvLMVOKKeAUXeQiZ70nBU0Wgf8pR
#undef  mlLrSGYJjbAGfNrE2Njqn 
#undef  mIY6aTF3Jsp7xx7PGtJiE 
#undef  mjIG00qxk4JkrUXEnFt0i 
#undef  mw4uDArLAQRJ5RILMGE2G 
#undef  mt6dcxNU8FQBTRU5nGYnX 
#undef  my120EBF7HLidYoqsyV9U 
#undef  msBil3sNAqwEOnp3Wgbyj 
#undef m_NPY932yWJgmI0EB9Nxw2wwI3j5V0Y
#undef  mxiSiDyBWybvWD_EkXqQ2 
#undef  muF6729Fw0dY7IUXcqL_F 
#undef  mwoqRnf28GiO23mh9WRm_ 
#undef  mLAyVzLAK_LqwPnxSz9Ya 
#undef  mywpKnyrwgwsGgm5z61Z7 
#undef  mILIfk7PGxDDTOakYwpAj 
#undef  mOQeKej3FayoxqmksgMAe 
#undef  mQc9YzY5JoYXb1z0eiZUL 
#undef  mq0ucKzgQJ8Vb483rVaDC 
#undef  mx_zsDiQLqCIOGG6ZVaIm 
#undef  mwQxO9PrX8fJnrjpG1aZI 
#undef  mGGDcIY_nfYZ9_mUGBiyV 
#undef  mIiH5VfWSEYwop5tklVfB 
#undef  mHvTmtzoUHyBLXpTWKNs7 
#undef mUvgLwCm9bQ59zbaPbd5U1X0XqTEv9O
#undef  mdvypU3x78f7PkloW409K 
#undef  muNsKPCBa0wKqqOUjL7bZ 
#undef  mAh372E_Wg9TxPqKoaDdB 
#undef  mlgG1YxgiooTLC8cHM7WN 
#undef  mh9ZrcsYuwWJqvQRqG41T 
#undef  mRpvDNjELHQyaC2EvjfKi 
#undef  mkIFONPkvrdc61fQAT2H7 
#undef  msqgfIeLj_ylvK1sbLrxZ 
#undef  mEfcevZ59zAv7W5lfxfjP 
#undef  mX2X958br5qt4Ghfp3m_N 
#undef mRtvuN9GNsflAplthKhMS4rH6S32izJ
#undef  mBrwrGtTrM7PuIVoXwC9E 
#undef  mgPto1LD96SW9jqOPXKFT 
#undef  mWGGkbJfFDMzeQkQHP8zB 
#undef  mQqnRcoNxbykQSXWuA762 
#undef  mnkYVtKJoztdPpfebBy4S 
#undef  mwEFsCY_vJ82sL6GSMTpd 
#undef  mBl9BsRffI8ufIAr08w2y 
#undef  mkNGVmRSdeblSckxXzGVq 
#undef  mjTA13gm_tkindhJ355KT 
#undef mPQL9QR6GDug6_XQPkoBBO_EWclDsYa
#undef  mf_JqpiEFJo91B8NiezKm 
#undef mGOSqQB8VlpT8JcDzrYjtvukl6adru3
#undef  mdeeM7sTQ44guIS_idFPz 
#undef  mf5ELtUxoB_DDYvBYbkkr 
#undef  mOFbQJXpIqx2CUsXY6ojL 
#undef  mCg6Nym6bk7APUcZJcg42 
#undef  mpywFnfax90Dm7uvF3t0E 
#undef  mq8QZ1fcu7doY8zC16S2e 
#undef  mHtiFW3N5ulFoQa8SvVjg 
#undef  mDdjKnE6eQPZmBEbJ1t7q 
#undef  mUzTGmNZ8S0WIPlKPasub 
#undef  mOIgqIOZLy6fFD2HdHZmO 
#undef monnmjZMh33FL1Qs8UVZ8UT4Y9QZ_mE
#undef  mbZnXfolbhe6fzyUhCjzz 
#undef  miaPZb98n8vLtwMCfTkFg 
#undef mvc7dOEZQdzti1fXmvQSH_82cfaaPuU
#undef  mGMSpCfQ5cVseqJ4FqHTq 
#undef  mB2EhXT0BPBy9yjrxqp1u 
#undef  moLZmyH4uSJX9pXN1kkKz 
#undef  mpY6s1pB7QlG4hhS5P20D 
#undef  mPOe7V5nqpXvrHVQUbsK6 
#undef  mPg_7ggju4jVdkaoVYPNL 
#undef  mWqGf9oBDxunrUAXjNCwH 
#undef  mo6Gg80T2qtOHoP1MtCnk 
#undef  mWAv9IocI7GJUr5S69MXT 
#undef  mqepl_oeHDfUCmkoDKIVa 
#undef  mTHYbenkovkCYepR9rjtw 
#undef  mjLI8BhQkZaoZetEfC056 
#undef mPyjgkPvUCWCk8FezIcTXyL9sJn8wGi
#undef  mYEnJ2KFETSCMo9vpFgQh 
#undef  mxOdc90XJRhVwb3UeaxT9 
#undef  mbFEPHkpnUpIRl7LXW2Ak 
#undef  mUgUEfVdBAs_RDl0oUbQO 
#undef  mBNA8mmWYQ7r_6EK7bz0q 
#undef  mcL1lQJjBPnSrmH2kuUsY 
#undef  mxjrjSIo9uk8DpohX_dX_ 
#undef  mjXVeKcEorHWSksfRH2UB 
#undef  mlDvkVxgo6zQqIYtzpbuY 
#undef  mBy8ck1PNZuSY2OB9WIhA 
#undef mH9BEFYeJD8Iu3PWTP97njhgLVZdqKq
#undef  mKKbbCUUypEL8epnweX9n 
#undef  mqiPQR6HtZOTL5qCeQlR8 
#undef  mCmJBaXVr33OuaU8e66CB 
#undef mVaS9g0F8rMUfhwGHe9hpPrRP4nhQcu
#undef  mbS2AfD4QSxooCUlUSRqP 
#undef  mXtZuhgtiaV6S5T_FEAVq 
#undef  mf6w6nRo1UPHMI9Ix1lmT 
#undef  maj782xJqBofsysA5mWjg 
#undef  muDy_qxq6pQC33xkdhIyC 
#undef  mWkuRTKqKYSGmNkBdxM6x 
#undef  mUQApTk2utXRlZOX2bxsA 
#undef mtiO9aWlTGS338_vs4akINkJOnG85lV
#undef  mLZ3y6cDPwjsfFVKTrILy 
#undef mQ3LrQGWK3ITvOxiNlHApLxrgKB8npw
#undef mEs0irIAnd2xX01fSVchhl55dHEYop3
#undef  mT46C_XnqCe7R6H4MhOxr 
#undef  mXD0JeNoU_GFfICrMiytn 
#undef mQMLJwxfCy5K3G2bQ07H_dAcBPxxeWv
#undef  mWPvycRWzzsoqLdQC4Zks 
#undef  mdxpLcivZQ9gvLtG_CD8k 
#undef  mEejCmnS94SV2wMbkWVsn 
#undef mZE35hSLZpuII32tgf1JmbPoCra0VBd
#undef  mMnnGpHxOGg7ZBDtb2pmt 
#undef  mYIGks_NNZ7VAm4pFdvj4 
#undef  mvShd2oEJi2tLN0SOFZu5 
#undef  mErDDSVFJd4ybmgEkutlI 
#undef mNxNhhHpfeAiZ5sJo_7mt4nHTXJYDVT
#undef  mUDgRdrdeBFvkEOlQ4jdx 
#undef  mlhI6nALuWI4Pffg0o1of 
#undef  mmqp10RQmuasvrITygi9L 
#undef mc_26RHyoBayf9xMlH1AIvFaSqwSZgF
#undef  miHaghnjGYZRXpERY7vgM 
#undef mv6ZJHUn82VI0i1Pph9tZ9g_rkljmM1
#undef  mF_d3P26PhUbOrZj5urQY 
#undef  mspo5vXPAtvuBUj_m4e3N 
#undef  mz8XdZut8o_7V0z0HOkYN 
#undef  mYRlAwygoj5gEQ8ab27p7 
#undef  mzgXwSEN9xEsGXmlzussn 
#undef  mYc5Sb0FNQP4mPqAjZK6N 
#undef  mW00V7n8RwzFWH7tra2wp 
#undef  mF4a7aeyPOk_IENHOG_s9 
#undef  mixaz8fF68w_Z8NkYykGN 
#undef  mZnpA1C5VCYvSOdWYd650 
#undef  mIlg7SfwuJCuKSCLrAmGW 
#undef  mXcxo9pxHw09Ez3pwIM6S 
#undef  mqBnU2_MtantM647nyIHb 
#undef  mDcE2lDrCQrHV9wjLABGh 
#undef  mRPiNnEPcQH3y12uP7HFQ 
#undef mfqtybIM_xDObi3bQEsSDncUWCphcSv
#undef  mNauiDa3J32sWVmjw5iS_ 
#undef  mHrq7R5UXcqwWoCwseouD 
#undef  mR4GSoDMh588p6gml2ppZ 
#undef  mJ8wuTuPR6f1IyiIT8UIu 
#undef  mwz7jWEjfVuS42kuaQPn8 
#undef  mmd50wX7Qq0n7gXtBROth 
#undef  mVGBonTDiCwFL0cnZln6A 
#undef mJCG5fpTiEuYKigze8PJI1nRcI0LtEW
#undef  mppKtzP31aZy0pGd2m0Z9 
#undef  mlxp0NYP5CeR4ty6JTYD2 
#undef  mNGHuSbVa0_na45B50kOF 
#undef  mIiGzGved4F_baCi5YYkM 
#undef  mqKKrBWIaOyLS3Ra_jBDL 
#undef  mWT_5joNFiaFOgpc894br 
#undef mPC2D40u9UNkOp3dfTHNMRJkK7O5kba
#undef  mQ6Dvoa5zpln4IZHMHn1R 
#undef  mb5F9AqEAhyr5cXENvU_U 
#undef  mxKm4fhiQR07mUQZtvQsj 
#undef  miAtAduyJ46MxHHzkj4ZX 
#undef  mmp7_M9ugDi91VvmJTBt1 
#undef m_dAVQ4_eR3yzuHDH4gFJ6w2MtMrU1A
#undef  mOf_6UbsK7ep8Mc44M3OV 
#undef  mSngiQHKFtXGAWWYegLBb 
#undef  mloosVMq6sq0h_qHzTDP3 
#undef  mqnDdNNOPfVropZK3wguh 
#undef  mYDKn6Yr_a4ORyXvUa69a 
#undef  mOrY_iT8gjLHjVIW3FW1O 
#undef mfx9_1AnrX1Ul6tpzHL2YgNZaqNuGjA
#undef  m_P_thdAGOXPNBzljrTS8 
#undef  mJjX0DECNHF5WB5M9vRzJ 
#undef  mWwY6cyV1jNMlS59jmeZo 
#undef  mozF1ZOMKmB5oOYXvA1du 
#undef  mmjJByskoayWNXAL0eEli 
#undef  mmCQ_mZDeOH1roaBYApfn 
#undef  mHGTVYrFbHv3PJ7RCD0Jc 
#undef  mwDTANvBf2eCihKlwIGcQ 
#undef  mPvPei7s60LjvIsL3QjyU 
#undef  muozdGyOiRg8bbfHYbrAV 
#undef mvZxJ95beLJLoeYRAM1sz8sS9A7aayI
#undef mfxgiWxOdJfDLBYA6oOI27LKWpXmCZX
#undef  mpgP0vTNcH8bnjKMb0lnb 
#undef  mUe35ebvjiFbtyLJFPyE6 
#undef  mhiOzNWXae6WAnJ151Fyt 
#undef mdzuOBIswyh1V6b38J5JiyybuhXlMrO
#undef mr9f_lpUR_FGty__DA6kaQP7t0oEc_G
#undef  myn0IRnj83DrK6IeL7ZqP 
#undef  mxhbsubyMccDrHGNJMioN 
#undef  mIAfvDkHI6lIIINQzTJKV 
#undef  mZf3yA3X8Y4vlKmyskuBt 
#undef  mxEVD667Jqeb4kgvDqizk 
#undef mtc_Co_EWmP5Hp_FAUdaqPNri3mpU2J
#undef  mpDUun5vtv3_P3gMremqb 
#undef  mua3NnY0TAfYsb7mnK3AB 
#undef  mVFmnX1ATHIuUhmRgOLcE 
#undef  mH2iaTe1AmMknyrV3qrko 
#undef  mddK3s_AIwJJYy91UPWm0 
#undef  mvpbb7zB0unxZ3rn7aVG2 
#undef  mw6J30JhGYZOxHrm_wMpc 
#undef mKvGYdUZpzBjHq0vzXQ7yslRJTGxteI
#undef mMMv71ZM2ilhkiUrLoXLLoOg2YFFHu2
#undef  mJTa21GBBlpdHs8EUXwZ0 
#undef  mXus_Eo2JqnLh5y7kJELW 
#undef  mUAyNrdMBPqfxcBcQxB7c 
#undef  meuG4OCj4N4C9n5yLv6aF 
#undef  m_DVkEWDaWG1t5mgtZxkD 
#undef  maJJMpCnCYLQsMYPbFYMA 
#undef  mChGzY6uJwNl0HsnhepB1 
#undef  mM2iqaERfKSkIvyG_DVsA 
#undef  mjNjrFKv44mwngUEfcirB 
#undef  minOymI64c8f3H3XHJv3L 
#undef  mKiEjAMYsFU_Bb_sAc8_Z 
#undef  mOK1tXVOT4PUgeSc88pGY 
#undef  mmgqYc0_7tKLpJXAoouea 
#undef  mACEtiH5Tbi8lnO88jrSp 
#undef  mdYWeG2a5BHWYTCQWns_L 
#undef  mnjaKsh3k7rjBD7gZFgTk 
#undef  myuutvgsUpQCFDJ0ssvlp 
#undef  my7DlUa_jcEKiN8C83xVo 
#undef  mcZIiEkLwLGoy0_KkZHSk 
#undef mPH4gZyJFhTV0IKckWyrQDoStaDbiOd
#undef  mUjurCRBYJHF255t6Kmzs 
#undef  mVOE107r5YCZnQhGJnyyc 
#undef  mXEvT4eTJ0JjwVNzWVCd_ 
#undef  mphhLRc3W5j_M1GNrmYpo 
#undef mTCUDxGUbteq6PD8Ui1X1haAKpG87ny
#undef  m_23kSgiA0WF7jIecI9GS 
#undef  mZPKcO31MdgyyO0EYYshF 
#undef  mlB2QYv5KjhdifG0wAHJ3 
#undef  mJiHt3M1dcVlb3RetJPWh 
#undef mYk9HmQd8bbGOJRdA7BiyW5yO61pPnK
#undef mQYBsLBq8E2T5jD3oJpEGi2Nvlb48JZ
#undef  mWsyTEGIlXdOWruNjOvgI 
#undef  mezgQgjr7nDbCRUgCu1cq 
#undef  mGFaG2sFpPbGqC0w_fGEu 
#undef  mSf2hO6FvraBmUtaPHgZB 
#undef  myp_fbjiOXFMZ2yjTUOjp 
#undef  mjyVQ48wRRVzvwtpWu4LT 
#undef  miLM3jwK2Yz49yPA0oQB1 
#undef  ma_EPPI2vwlDqLbi0tgWx 
#undef  moLWDGJRwk6oG4njcobZ9 
#undef  mvdNCfq_pL4n3ih66P_la 
#undef  mHoYOCFl7w41X_Ih6amkp 
#undef  mgrChmV5pX_BBnPjupsCz 
#undef  mBK1TAtRe0ulRgZBnMSfy 
#undef  mbryrl4BV13xrMXG4D4bJ 
#undef  mCo_IAiG3U7gZmGW7mfLA 
#undef  mKlr4mnSO22NHd5T0mgC8 
#undef  mWq9_KmZGFjxoJt2lPEt0 
#undef  mPEXKIHylb5EYa1bDUzOc 
#undef  mxnbn5N6CVBHAgOUlVJZu 
#undef  mik5L9gUWoenRFF12Yrzk 
#undef mx19pTpr6SPRZjH9NkTxvmw7ihv6jR_
#undef  mXx6_jd2koNBijGdiN7Vz 
#undef mlRCHsCtRe6k9kb_2Roqq8jl6foSkCI
#undef  mMNd9IbgZGNvHCj6cXNIY 
#undef  muxbEt9CF8rzlFkqwpyvX 
#undef  meDekgZkaKWxgWJNWiB94 
#undef  mmZpaGRQQTWxpkl5_I8in 
#undef  mSkvBeLHubgyviqhSCFVS 
#undef mtNfOkyFGK3082SQQbAZCMw3hpB0iyf
#undef mbQCceuE8wn7_fovfqyb0GwzqjwqWr6
#undef mSjwCKnBYKiKWPQ7zHc76YVaFPeJyK1
#undef  mWhE2c4Mys3RC3rNzuJP0 
#undef  mAYVxyfIbkjPzf_zHmDXf 
#undef  mccbBTKxxy74ZgysgeBt9 
#undef  mee36YukNoygoRh_lR_Ze 
#undef  mX5S2JiQl0c2tpcc8bIuq 
#undef muqaQT10PsyYE1MFLySGQD8oyhsZvS7
#undef  meIKowFtzF_KnWuEf8Sw8 
#undef  mq1dLrY9fa4LlsXx3HCMA 
#undef  mSqEva6ZvHDtTTNPzbcTg 
#undef  mP1zJlYesuPo0RorPJYu9 
#undef  m_V1WGNpPQBcGaW7uF8Lx 
#undef  mPktF2k_R4xKiN2Zg99Ud 
#undef  mPTzrDzdT9es05kbzwnmP 
#undef  mdruYgOQmkv3BIAuvjWLy 
#undef  mmn8ymmm1AIJ6zrUylRVH 
#undef  mpYC3Q6HCOG_y3bCV_bzU 
#undef  mnsDFHlx8Rb1ohrxyYFfi 
#undef  mkcg1f3K8o27bNvoJTpmC 
#undef  mzHh89aGoIBqfwknhH3H4 
#undef mOnachF1QzcHZSNCQGQLEZgaVNfMype
#undef mXe3CrI5a11ZUmwS7tjcBfsrXgYbSHW
#undef  mR8ixRQUitFYrNN2mR_Vt 
#undef  maSRbpjxVVICurEUbIuQV 
#undef mEUidw6mp1G_E5OXU0KePiiCfIvznsw
#undef  m_Q5PCBYXJE_DRsG0wKBK 
#undef  mpshT4E2nxvfxIwt7YAk6 
#undef  mnqU09SN6BDUZqwySuDju 
#undef  mSu5TAw93UtHMEST_mEgZ 
#undef  mP96kujYTIhRaRZvoFY3s 
#undef mBwVcshwviptLz3c10i53yS2aJZWZo9
#undef  meiUeWrefx0V6GSxveGfz 
#undef  mUMTQYGn_vjeSIYugrU2s 
#undef  mTTUVMx3R6fGe9krQWHNl 
#undef  moWzCteaw2sTVcwRbVbzv 
#undef  mSnExO4i5GNIq1BqABZ51 
#undef  maUewyToTzO7e_C2pAChj 
#undef  mCFpr4Os_BUpE0hBecZXK 
#undef mxs00DzjNV45CaOe3stxm12MYYasrAH
#undef  mxI4OGfJNppK6bSaPtb96 
#undef  mIeb91O4CN5VggNyO2vQ7 
#undef  mVmHfDt9pq2zl91iYWE6U 
#undef  mLb0lJEDMWAhQxS1Zq67K 
#undef  mJpoBwgn0DJQHiXgAvSEa 
#undef  moDnD1KzpS8g7Il2uIZev 
#undef  mcuDBAnn1wGY7StG6m7EO 
#undef  mdunAdC6xu6GJIYvfAsV3 
#undef  mIYfprKiCusfY6QKqNNQd 
#undef  meCLS9T66CCBsN2UIgI5y 
#undef  mxhl9wjLQZULxOU_43q0G 
#undef  mTvAB8snV2fgebopblqYn 
#undef  mZqddaHRX13iS5uKeuLZ9 
#undef  mfYUGCIJ4y66ek5pHyoZN 
#undef  msF3n_Llrc3Y4xisawDlW 
#undef  mZIGb0G_7tQt3sEyXxMzg 
#undef  mzdEyRJKtHmAv_hyCRXsM 
#undef  myEhqL0JuDL39IMru8yFB 
#undef maU8Gmc9saEUcOIdGiyBpVseIOM8rGK
#undef mVw4dEmkS1nYXwAkjytTb45IovCxtS1
#undef  mbXG9MVBv4U6srvfu4315 
#undef  mRaHBseQqWYz2cyp3Rs3E 
#undef  mu0Zw3fsOhh38Uo4aDS8W 
#undef  molLfYeMM1X9tWqNJoWGM 
#undef  muJE97qvNzITjsGin6tfo 
#undef  mNiGtWTU2PT3VyoTSpMdj 
#undef  mJUNcXClktUN2Tl2zOPvk 
#undef  mj0RN9F71W_6s_YhWh1SP 
#undef  mWLJAJJUZMLHiHLjyoQgG 
#undef mR0iycNYX1FOFgEUS3F4KjdVmmiFkXX
#undef  mhRH6NAjeqg5kA7AN6iyK 
#undef  mAot4lv_hqRDJSbAui1kl 
#undef  mqSTm3bttsS7HrMtCtqcS 
#undef  msuedeOIHU6ewvLMy442k 
#undef  mLKx7V4m_2xz3wI_2SN14 
#undef  mZToZatzbdYktAqdlAuMA 
#undef  mYb0S2XuO0Wx1MlstrBcI 
#undef mrwnUakjFje2EJlpug7_9RJurwdjY0T
#undef  mC8KI3ySuRUP4dht1IyzM 
#undef  mo_zGryQm1OW390INk4Rh 
#undef  mc8cpdg49gSTWCJ_fcPgf 
#undef  mlBPgyFb0C2QAT0fTdjcv 
#undef  mq2WtyfxNuhMujs_W_RTx 
#undef mqO4MXVld_mK859zqQQURhmbagaqDcn
#undef  mpIazGz0BO8GDZeOCwtDA 
#undef  mRwhC3e3qO_WZuEA4A2BW 
#undef  mrqE4Np4QAy0VQlmgqxkb 
#undef  mI4i8YlJZREbZV6pNhNgC 
#undef moGNslw0uGdG5ctBUscALJEtDcnUyJ_
#undef  mkFSQs4i_JAuUSM0kZAym 
#undef  mZGQ4J8pc7eRHZbaNBrTR 
#undef  mUSCgfjpSMcf05uswdfL7 
#undef  mV6HmzAb9nt4ZzMV8wxyz 
#undef  mpd4PM_FCAECboim6Wmgy 
#undef mb7McY6T8aQDuHSfTKSpWbOtv94qkFN
#undef mnvfs5BDNoNZaH2yKtmAwSEwIuYzenx
#undef  mUoH8XEEEfCHr_okINOsr 
#undef  muUS5FvYhlxfTkFJmYezn 
#undef  mYQkXgv52j8TRFlT2039v 
#undef  mA85Ru6M8Sh6PK100OVgE 
#undef  m_q9HVEqGzfY1bLsvvnLk 
#undef  mifW8L55qoQzdH9Hxh_rZ 
#undef  mfIWMShtlO1lWRlmhTgit 
#undef  mlJVBsqoWtsTo473MOT6a 
#undef mg2gIcF367jD4ckbHidNffI1iCwXr8I
#undef mERR_Wx8iB0lnwsZka9rx9eZXZuCy1N
#undef  mSSbc2Iv8QJAtmPX_f1yA 
#undef  mEBO9XZXAXJaUk4obnE7N 
#undef  mGv6D9Qz8MbJvAmkFU4Hx 
#undef  mVPDb9eh1vkqO1xut7gjv 
#undef  maaer3lm0klVkPVFja88l 
#undef  mE_6o32Gp3JDq_gnNQzZ0 
#undef  mh7Pwtw4LXwQlT3sCdvz5 
#undef  mILJjka6sZHBW0u1eOWdI 
#undef mA7KccoaFW3_JT4hubww6RQPOED20pb
#undef  mCxo5hT3adsjpL3eSx_tm 
#undef  mmKFpIHZ2jW3Pl2yswFoH 
#undef mwDbt2VOZLiJlLLx2w5pyTLfMg5POTI
#undef  mDQMtL5YeoKm_YS3gZzWk 
#undef  mxQTBVrtumjHzsNY1uJ4q 
#undef  mHLOpps1TeJ1n4a5pxdNv 
#undef m_jVttE8osawaP9C6CBzxOTiuhOgqf8
#undef  mD2IMpmuC9DqK0MgNcche 
#undef  mKCTftSTuG6VG4jxcv69W 
#undef  mUCGPJvWQ5iGnbekARZlm 
#undef  mUgFQNn6NFW_G4o3ySm_4 
#undef  mIK03fc5ROh9ICjmvi4Vh 
#undef  mIk4yxibfXlu1GNQwRj9M 
#undef  mG44HhsnniupLg6qlgFIH 
#undef  mxyL0InM4x64CV7L3AaHT 
#undef mIEh0WPsMbtbUK3nUBX9LWlCz6RZq7L
#undef  mLJyLhCC1vQSydWqj1GOr 
#undef  mG3YAAlNpehHAOVkS5sG3 
#undef  mLwpjlSPu7J_elHZYFHIX 
#undef  mOdmOZ6JhhXgfuJ3N5Jmp 
#undef msqJqsIXxTdxIdzmzPFf8R8fww27l3K
#undef  mIXHmxpusVFv3HyUXTK1Q 
#undef  mChKOw2unTvh7zyq4OT_T 
#undef  mgEICEME5NV3U_tXGoy_7 
#undef  mq7AbHYh_W1mCH4H2mNum 
#undef  mq3vxPsKSjjq_xpuFA9dn 
#undef  mKRZOLOcuSUonKadQYQeP 
#undef  mdUMW8l4XOUiCvkuJO43u 
#undef  mCuVYMMKrUdwI_2mOu9QB 
#undef  mr2FttvZzA28fJewbKHY7 
#undef  mjikT8GG_Eaa4oCQeyiMq 
#undef  mxBVKq5uLQpnUbC1M415c 
#undef  msJ1KNPOiADf6gZGCZMo2 
#undef  mHvdR3hBbPsuYCiDibMCu 
#undef  mhbVKFNcfuJXmKB2yO0I7 
#undef  maSJfbIkVmsGsjTv0UQpa 
#undef  mxMT8lSa5l6hiKbQkPkeE 
#undef  mHCPFDMeeHMqUzSoOz84O 
#undef  mErde6Wj4Ze0ly0Y61AFC 
#undef  mCgqm4phtQwlbAwXa03Lt 
#undef  mES_2yZC_KXxuyB8sa6ZW 
#undef  mB8a1ttPFjFQb6FACJVri 
#undef md9UB98vrq4jJkezErUZ05uMq4I82AQ
#undef  mdGdm6zgtH4zv3Nn0vGML 
#undef  mMrjjxUfFnHYwyIeo4thn 
#undef  mrNdhbQvUPeiPjqPNXdcz 
#undef  mC5E9mNw3KALrr8VsSONZ 
#undef  msL_HjjMOgmuquii8oJwE 
#undef mQBrdiSopp1NcqzM9KDuuwUEDdgQZ_k
#undef  mskyfHCUFCaS7gh4hcS3o 
#undef  mNiYurmpzq4vJvNRIl54W 
#undef  mxHKiAXYrWIjTAoDEPTIB 
#undef  mc3Ft5vFbWZ0I_cyBj9MZ 
#undef  mAQFTjhI12FsIF680A_T9 
#undef mOQnD0ULpuH4SCrZIgr5a0RAht7dCyt
#undef  mF5KqMOLuj66Qc9BVmrCK 
#undef  mIY6eWGNhdwzAegYIRulk 
#undef  myAj9JkIJCTTmCuRc8M99 
#undef  mxhof4Ntel2hNEVMAOf_m 
#undef mxSidAmSZazu8ciz5L56TycQuLFDGvk
#undef  mEjV10WoNQYtojmohB76_ 
#undef  mscLdcfav2XqEy1mvndWW 
#undef mVuS5o6wMdvdatiyAyQB13ULZ3J32wq
#undef  mL0x8fUOLy6sZWW8GUnrT 
#undef  meUn5JsY9ungDpQtF4sS0 
#undef  m_TIpRK6cfIdqQhX1CkJd 
#undef  mz4sAB8Lke0GjEqcgK49Q 
#undef  mdScDBc7q82a1WdAnmuIu 
#undef  mKCH6zvmv2K2hcW15vK3r 
#undef  mXifu34TuHwfEgv5FpdR5 
#undef  mMAgfm6vQg6ssvRbezbqa 
#undef  mEaKKI8OgTfRUieYzOXug 
#undef  mk5_ghEAebl24EQAP8Y2I 
#undef  mRSSDe7hONLNKU5PudIcE 
#undef  mZWGtEnNSuqL2nrO4fXdk 
#undef  mHRK1Qbpc6SXqAGUtoV8J 
#undef  msTzoWt64V0e_oS8Fv95H 
#undef  mCTRiZEfCcZ4rtZeXzEPU 
#undef miORm26edjfpNn_hCt9GrEERRoVsykU
#undef  my1wIVN5s0pEr254Z3t4I 
#undef  mwdxiJ7bkKBFeuo6juueu 
#undef  mkyYKoUzRp4I6poF2VXKn 
#undef mAYS1Ux9gOkq8T7s1qr9ErCfKxkJVir
#undef  movbmmA7d7fL2IMmkgf6q 
#undef  mWrRucvDBnUNxwq34J_n5 
#undef  mTRdzsidy41IXzn6FJpYi 
#undef  mVQS095yooNNd1gPQ2zeM 
#undef  mk8OCx3O4AOVAIRiQPOlu 
#undef meqZKImxwHi1E1VitjMP7tv47yFKZDS
#undef  muWXtrHRVFC7KhnfWhKAI 
#undef  m_ZHEEUwDRnDdlaSMvfmk 
#undef  mlvrAGsnVcTUzfachoVym 
#undef  mT20HT4iX5uExGVzFTLK9 
#undef  moUYnjRTAuoihfJii16Wu 
#undef  mYsOEPMsPI3X8nh_LwHNz 
#undef  mmLzOj1OpcOraAxHe0sHs 
#undef  mNjJsZDfV8Dwnl6nMK84O 
#undef  mRMUJnQUt0oea5rnYn0_Y 
#undef  mSjGMEYYvU3tkDcTrtWVc 
#undef  mOnEJbNUBTUOPydb56e4i 
#undef mCIj1IpSvnQffHx5YCM2g1I5KZ94y2J
#undef m_IS0uDTjYoTNAddluQDV9SM5nC7_q6
#undef  mGHqZ_bgrGT4Q7zI8CKhF 
#undef mzkrZL2hayNpYL4ZujEcNw2hmOE1Q5y
#undef mr5qzJx26OhVD45MSWsVlyKAhna97nV
#undef  mkP9lTzG4BRAAlywJ8F2V 
#undef  mxD748a2I6dASvSlPvIj_ 
#undef mIwIjmPxEhGOH033Ezcnxk2bA6mC9v3
#undef  mq1N5d_4DodFLRkHvpqwH 
#undef  mCWMzZFPcoXg9fIw5padT 
#undef  mQ_F1GFFTMyE1Q_xqKLoh 
#undef  mZ6hFhQkAGVzS_SZ8Fuq3 
#undef  mnur9YE0hxi1cir_V3aIB 
#undef  mKrqFPG8zODQIl9cbepcB 
#undef  mZ5n7IX_AHHoHYsodfx8Y 
#undef  molbYrJdmAWzmis3mfRI9 
#undef  mJP7Jsm7au1oZp1CLb7PT 
#undef  mRAG5Ci16sQoS2EA7eVzC 
#undef  mK77hVwIWVLedKNcvp6PM 
#undef  mHdVTvslisAFDOlw9Tqcl 
#undef  mtOADHjcfWlYUUaEqJYvC 
#undef  mdjkd8YtBaMV2CNQaNmgb 
#undef  mUOElYxXCWJ0NENjEKuO2 
#undef  mUaKuNbS96FbvDu3x85PG 
#undef  mXSaJTMo4mCIueHA05tT9 
#undef mxtoPv02ciIgas4ChUZdMvVI4fwHpSi
#undef  mPmVqR2XlBp2aChIshsXl 
#undef mD6TNyDaY08Lmj3scFGjUbu4VR5Lf4H
#undef  myi_nNZ_JfQR5mbTdok9w 
#undef  mSk1ShXRx3FQBFfrfi8ft 
#undef  mlaJAVwTnSatEJKz1vwwT 
#undef  mxergcKZo1TaZwkF3katu 
#undef mSabz3HnesxSAp6ZqnLIItEaJ8fHXKq
#undef  mqgUxf8fEezt3JZHibRI6 
#undef  mi9SS68Swio6VNvbl_mFB 
#undef miwSU0QtFcZ7UD0Oo5vxVC9j3tsHnyp
#undef  mpaHcg4PHwnP8av2bRnxG 
#undef  mAm1IBghYGwuUeJKTKm8k 
#undef mxkN_Ys1CO2UF5KBLbuGlfLR3gBIwbq
#undef  mPg8ShPrRyDomzQVD8JDd 
#undef  mAwKqRu7JKd0T15BB9SVo 
#undef  mX_dnaLb4HMPgttj0N6cS 
#undef  mRo6loK_zpoTJQIMUf6FY 
#undef  mtPSLyNBQ2pm6dAI2etAM 
#undef  mKnQQsyvSGfClEhJfjf_2 
#undef mZCWjQLyVIUxFk8nBpPBHoweBhtBxQS
#undef  mxeJSBEbCsTLiumaqkjDh 
#undef mVhdPWZ3aJ4PYAl1vaE1D67MUIkC0C7
#undef  mS_cL6sduOKwOc9eoSgGT 
#undef  meGH6zSWZBHXv9GpkDOsU 
#undef  mROaoKuxZxQUeKvavsRgd 
#undef  mXznCGqPJShYepsGsgRSL 
#undef  maE55GrVViUaJT6DY5y6z 
#undef  mN1g5nNNsdQ2YhVjJ_tGK 
#undef  mdC6ly0QVADyZxTR9Kd4S 
#undef  mHuF4mTDu6zvknssKtlKQ 
#undef  mmoN25SYs7aJ2siMeP2QH 
#undef md9eLhBsbxZUoWAvizc3jyCBtlXD_iu
#undef  myCDh386wqCMf5a0poN5E 
#undef  mX2sEi46khxM2A_PZGLcg 
#undef  mDlCq1FEvS2b0w1Z7KnPr 
#undef  mnzMtAZ2b2rQ9m1VZA0mK 
#undef mvZo5OdmdGRqCmrzVudHsFtf5a0Fo4d
#undef mmGrg3t54rl6CR6ifITt2Up2VUqrr5s
#undef  mYqcsV42kZVOveATGJgwC 
#undef mVXldDXddM8gmoFViJNgWpkiNjkWkrz
#undef  mgeFmKdNvJ1A_N0m69M7g 
#undef  mxsIRoNEMzjS6Yb5k6usv 
#undef  mImaiwn1PdizTcyUDXulO 
#undef mDgA_METjyeHgMDPZVFhWWwqnIsPQVJ
#undef  mbP3VgAHoOgnaUfLyN3rO 
#undef  mAZRToBg4lDGzySG6Xoe1 
#undef  mZ6WGMFrmYyqAAdcUkwEy 
#undef  maTKateMxjtQcbE93HNJ0 
#undef  mH6PiHnqpo8UuqrMEAB6z 
#undef  mOXFj8zu2J2qXnrmqx2yR 
#undef  msmAD6drDtNttgeYR9jK2 
#undef  mAtqmWgqIeEipX4lQNtCe 
#undef  mLABsMDLgeDjo3a0doFQX 
#undef  mEhfuF62zQ5txn5P0wodE 
#undef  mJBzoLtWNcFHmcPQ3d6OQ 
#undef mmjAk1019HgM9qjJ4mrzJ6zO3VZq6fy
#undef  mgwAvkwbyCsAnDH8GAXXg 
#undef  mEQIsA3CEFNeYEkD0VISr 
#undef  maKfyHtPbDZZ8wDRXTLTe 
#undef  mAk7lLQ7JMLiy1kZRxSuB 
#undef  mtQ5Iu6IwFDiWNGDAwlFt 
#undef  mlFquKXUmcJTiXl3Twu9O 
#undef  mINW5N9jnrOsBvCB3F_Tg 
#undef  mAEwafH8Gv5IPmvo8_2uc 
#undef  mm3ERFtObyKhe7QdFRo2M 
#undef  meRV1BnTNhVK4UY7xqlmy 
#undef muUMBTBTZxRVSK60A4LDf4ZubpFVKHa
#undef  mhlrvVwQFcOFpdjFt4y2u 
#undef  mDayc5WiuF3Q2GBCWXNZN 
#undef  mIPx7yO4OGEcmtJRLikG_ 
#undef  mdshQAp19qrZycBsUZPaE 
#undef  mro504FCPvSIA3yDAGv65 
#undef  mhOLPnF03rFFNfjNqd_Z4 
#undef  mozmL8sMtEcXdVFJtkOKz 
#undef mVZ7KZEjD2giJLu4gtXHFz9WepSBkpw
#undef  mSnZkOnBAqXU3YDsfi4ET 
#undef  mdZrIg75HXBbfo6YijnMm 
#undef mrw35lUQEv9D3j0Ewf9SCBglDaEtoyg
#undef  mYSn7neYwuzZiHSfgVhG4 
#undef  mtcMtq_ZgTF0Gbvko4MMI 
#undef  mLL4O6dMZS3YRrZPW1pBs 
#undef  md3s1mb3r7yj6iAla_Uph 
#undef  mesVqjyN8Zd40ufTyiSMc 
#undef  mMGT2hzcXHkUIYeMRYsCS 
#undef  mVlKX00k16qzhto6c5_qj 
#undef  mO6K574X7bRtXKjbUO7lG 
#undef mPCEht9pGOwTltmiZwaG5XKUhQMU99e
#undef  mleaN1JwZuigEsM3tS2a6 
#undef  mjtj7yQ_q2uLcbKG2QsDq 
#undef  mRDfu1xLphZvqmDx7exl7 
#undef mJ3E2ofr5RROqXwznnfeqR9OyuEOurg
#undef  mQLo7l7qWOomLrknIjpN9 
#undef  mFTDk1A7X2oZzPWrjJBTS 
#undef  mRD6PKZKrH07MF78RfKlm 
#undef ms8iZt5t1Dq1Q_9a5NP8qsz_CS9lfzf
#undef  mkPJr4m66EIhdFNV2A2hx 
#undef  mA3nRYnr_lZzzMo1jh_vB 
#undef  mwqtBehXiutMKDGeJnJ67 
#undef  mGomz2J4zQ4F_lx1Uo8V6 
#undef  mN1XYry49Lp0X_pMj4fzO 
#undef  mBGpopX91RPBnrW1jmwrR 
#undef  mPFo6diccQ2JPoBzrbKbf 
#undef  mCPzTgsHWoZ3UU0dnU7s8 
#undef mvqkd_u1Ad9fUIAuCbSAFJO0YlIVTLl
#undef  mq0XT3lHLE8Km3OLyXyEF 
#undef  mUAj7kjruyBnhjVxRcpft 
#undef  mCF6yuex92SFioZPpxBz2 
#undef  mdapI6SZ0JwzhtKL_Oxis 
#undef  mpmqMrNQlSi4dv2nYASdr 
#undef  maPJhxKGuCRBF8PTSEfoJ 
#endif
